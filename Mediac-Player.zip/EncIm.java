import java.awt.image.BufferedImage;
import java.awt.*;

import java.io.*;
import javax.imageio.ImageIO;

 public class EncIm{
 
 public static int total = 0;
 
   public static void main(String []args)throws Exception{
   int x = Integer.parseInt(args[0]);
   int p = Integer.parseInt(args[2]);
   int y = Integer.parseInt(args[1])*p;
   byte[] datas = new byte[x*y/p];
   int length = datas.length;
   BufferedInputStream buffer = new BufferedInputStream(new FileInputStream(args[3]),4096);
   while(true){
   int read = buffer.read(datas,0,length);
   if(read == -1) break;
   save(datas,x,y,p);
   }
   
   }
   
   public static void save(byte datas[],int x, int y, int p)throws Exception{
   if(datas.length != (x*y/p))
   return;
   int n = 0;
   int d = 0;
   int rgb = 0;
   BufferedImage img = new BufferedImage(x,y,BufferedImage.TYPE_BYTE_BINARY);
   for(int i = 0; i < x; i++){
	    for(int j = 0; j < y; j++){
		      if(n <= datas[d]){
			  rgb = ((0xFF) << 24) |
                ((255 & 0xFF) << 16) |
                ((255 & 0xFF) << 8)  |
                ((255 & 0xFF) << 0);
				img.setRGB(i,j,rgb);
			  }
			   else{
			   rgb = ((0xFF) << 24)|
                ((0 & 0xFF) << 16) |
                ((0 & 0xFF) << 8)  |
                ((0 & 0xFF) << 0);
				img.setRGB(i,j,rgb);
			   }
			    if(n == (p-1)){
				n = 0;
				d++;
				}
		          else{
				  n++;
				  }   
		}
   }
   ImageIO.write(img,"gif",new File("sort" + total +".gif"));
   System.exit(0);
   total++;
   }
   
   
   /**
   public static void main(String []args)throws Exception{
   
   int x = Integer.parseInt(args[0]);
   int p = Integer.parseInt(args[2]);
   int y = Integer.parseInt(args[1])*p;
   byte[] datas = new byte[x*y/p];
   int n = 0;
   int d = 0;
   int rgb = 0;
   
   BufferedImage img = new BufferedImage(x,y,BufferedImage.TYPE_BYTE_BINARY);
   for(int i = 0; i < x; i++){
	    for(int j = 0; j < y; j++){
		      if(n <= datas[d]){
			  rgb = ((0xFF) << 24) |
                ((0 & 0xFF) << 16) |
                ((0 & 0xFF) << 8)  |
                ((0 & 0xFF) << 0);
				img.setRGB(i,j,rgb);
			  }
			   else{
			   rgb = ((0xFF) << 24)|
                ((255 & 0xFF) << 16) |
                ((255 & 0xFF) << 8)  |
                ((255 & 0xFF) << 0);
				img.setRGB(i,j,rgb);
			   }
			    if(n == (p-1)){
				n = 0;
				d++;
				}
		          else{
				  n++;
				  }   
		}

   }
   ImageIO.write(img,"gif",new File("compresse.gif"));
   }
   **/
   
 }