import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class Animation2 extends JComponent {

    final int N;
    int currentCompositeStart = 0;
    final AlphaComposite[] composites;
	int count = 0;

    final Image image;
    
    public Animation2(ImageIcon icon,int n) {
        if (icon!=null) {
            this.image=icon.getImage();
            setPreferredSize(new Dimension(icon.getIconWidth(),icon.getIconHeight()));
        } else {
            image=null;
            setPreferredSize(new Dimension(100,100));
        }
        if (n<=0) {
            throw new IllegalArgumentException("n must be >0");
        }
        N=n;
        composites = new AlphaComposite[N];
        for (int i = 0; i < N; i++) {
            composites[i] = AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, 1 - ((float) i / (float) N));
        }
        new Timer(1000/N, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentCompositeStart = (currentCompositeStart + 1) % N;
                paintImmediately(0, 0, getWidth(), getHeight());
            }
        }).start();
    }

    @Override
    protected void paintComponent(Graphics g) {
	  
        Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width=getWidth();
        int height=getHeight();
        if (image==null) {
            if (isOpaque()) {
                g2.setColor(Color.WHITE);
                g2.fillRect(0,0,width,height);
            }
        } else {
		    g2.setColor(Color.BLACK);
                g2.fillRect(0,0,width,height);
            //g2.drawImage(image,0,0,width,height,null);
        }
        int xCenter = width / 2;
        int yCenter = height / 2;
        int radius=(int)((width<height)?width/2.6:height/2.6);
        int size=radius/3;
        g2.setColor(Color.RED);
        AffineTransform old = g2.getTransform();
		if(count == 10){
		for (int i = 0; i < N; i++) {
            g2.setComposite(composites[(currentCompositeStart + i) % N]);
            g2.translate(xCenter,yCenter);
			g2.setPaint(new RadialGradientPaint(getWidth()/2,getHeight()/2,getWidth()/4,new float[]{0.4f,0.6f},new Color[]{Color.BLUE,Color.BLACK}));
            //g2.rotate(2 * Math.PI * i / N);
			//g2.setColor(Color.WHITE);
            //g2.fillRect(radius-size,-size, size, size);
			//g2.setColor(Color.RED);
			g2.fillOval(0,0, size, size);
            g2.setTransform(old);
        }
		 }else{
        for (int i = 0; i < N; i++) {
            g2.setComposite(composites[(currentCompositeStart + i) % N]);
            g2.translate(xCenter,yCenter);
            g2.rotate(2 * Math.PI * i / N);
			//g2.setColor(Color.WHITE);
            //g2.fillRect(radius-size,-size, size, size);
			g2.setColor(Color.RED);
			g2.setPaint(new RadialGradientPaint(getWidth()/2,getHeight()/2,getWidth()/4,new float[]{0.4f,0.6f},new Color[]{Color.BLUE,Color.RED}));
			g2.fillOval(radius-size/2,-size/2, size, size);
            g2.setTransform(old);
        }}
		count ++;
    }

    public static void main(String[] args) {
        JFrame f = new JFrame("Round waiter");
        f.setDefaultCloseOperation(args.length == 0 ? JFrame.EXIT_ON_CLOSE : WindowConstants.DISPOSE_ON_CLOSE);
        Animation2 waiter = new Animation2(new ImageIcon(Animation2.class.getResource("mediac/src/img/P8.jpg")),8);
        f.getContentPane().add(waiter);
        f.pack();
        f.setVisible(true);
    }

}
