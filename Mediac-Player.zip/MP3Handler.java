import javazoom.jlgui.basicplayer.*;
import java.util.*;
import java.net.URL;
import java.io.*;
//import java.nio.charset.*;

public class MP3Handler {
 BasicPlayer player;
 protected int statut = 0;
 
 public MP3Handler(final String path){
  File file = new File(path);
  
  String valid = new String(file.toURI().toASCIIString().substring(6));
  System.out.println("" + valid);
  File vf = new File(valid);
  
  
  player = new BasicPlayer();
  player.addBasicPlayerListener(new PlayerListener());
  init(vf);
 }
  
  
         private class PlayerListener implements BasicPlayerListener{
		 
		        public void opened(Object obj, Map map){
				
				
				
				}

                public void progress(int i, long l, byte abyte0[], Map map){
				 if(map.containsKey("duration")){
				  System.out.println("duration");
				 }
				
				
				}

                public void stateUpdated(BasicPlayerEvent basicplayerevent){
				
				
				
				}

                public void setController(BasicController basiccontroller){
				
				
				}
		 
		 }
		
		 public static void main(String[]args){
		 new MP3Handler(args[0]);
		 }
        
		 public void init(File file){
		   try{
		       FileInputStream input = new FileInputStream(file);
		       player.open(input);
			   player.play();
			   statut = 1;
		      }
		      catch(Exception e){
			  statut = -1;
			  System.out.println("PB");
			  }
		 }



} 