import javax.swing.*;
import java.awt.*;

public class PlayList extends JList{

	public PlayList(){
	super();
	setDragEnabled(true);

	}







}