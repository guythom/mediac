
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class Hilbert {

    //Point de localisation
	Point location;
    //Tableau de couleurs
    Color colorWheel[];
    //Indice du tableau de couleur
    int colorIdx;
    //Repr�sente le nombre de fois que l'on rep�te les formules d' Hilbert
    int iteration;
    
    public Hilbert () {
    	//Instancie le tableau de 1024 couleurs et instancie l'indice � 0
    	colorWheel = new Color[1024];
    	colorIdx = 0;
    }
 
    public void hilbert(Graphics g, int iteration, int largeur, int hauteur)
    {
        //La  localisation est � null
    	location = null;
        //On appelle la fonction de dessous
        hilbert(g, iteration, 0, 0, largeur, hauteur, 0, 225);
    }
    
    public void hilbert(Graphics g, int ite, int j, int k, int larg, int haut, int j1, int k1)
    {
       //La largeur et la hauteur sont divis� par 2
    	int largDiv = larg / 2;
        int hautDiv = haut / 2;
        
        if(ite == 0)
        {
            if(location != null)
            {
            	//D�finition de la couleur fix�e par le tableau de couleur et son indice
            	g.setColor(colorWheel[colorIdx]);
            	
            	//Dessine une ligne avec 2 points d�finis par les coordonn�es 
            	//(location.x, location.y) et (j+largDiv, k+hautDiv)
                g.drawLine(location.x, location.y, j + largDiv, k + hautDiv);
                
                //Permet de d�finir l'indice du tableau de couleur pour cr�er un d�grad� de couleur
                if(++colorIdx >= 1024)
                {
                    colorIdx = 0;
                }
            }
            //D�finition de la localisation 
            location = new Point(j + largDiv, k + hautDiv);
            return;
        }
        //En fonction de la valeur de j1 et k1, on fait des appels recursifs de la fonction
        //Donc j1 et k1 peuvent changer � chaque r�cursivit�
        switch(j1)
        {
        default:
            break;

        case 0: 
            if(k1 == 225)
            {
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 90, 225);
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 0, 225);
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 0, 225);
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 270, 45);
                
            }
            if(k1 == 135)
            {
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 270, 135);
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 0, 135);
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 0, 135);
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 90, 315);
                
            }
            break;

        case 90: 
            if(k1 == 315)
            {
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 180, 315);
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 90, 315);
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 90, 315);
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 0, 135);
                
            }
            if(k1 == 225)
            {
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 0, 225);
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 90, 225);
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 90, 225);
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 180, 45);
                
            }
            break;

        case 180: 
            if(k1 == 45)
            {
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 270, 45);
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 180, 45);
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 180, 45);
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 90, 225);
                
            }
            if(k1 == 315)
            {
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 90, 315);
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 180, 315);
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 180, 315);
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 270, 135);
                
            }
            break;

        case 270: 
            if(k1 == 45)
            {
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 180, 45);
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 270, 45);
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 270, 45);
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 0, 225);
               
            }
            if(k1 == 135)
            {
                hilbert(g, ite - 1, j + largDiv, k + hautDiv, largDiv, hautDiv, 0, 135);
                hilbert(g, ite - 1, j, k + hautDiv, largDiv, hautDiv, 270, 135);
                hilbert(g, ite - 1, j, k, largDiv, hautDiv, 270, 135);
                hilbert(g, ite - 1, j + largDiv, k, largDiv, hautDiv, 180, 315);
               
            }
            break;
        }
    }
    
  //Permet de modifier l'attribut it�ration
    public void setIteration(int it)
    {
    	this.iteration = it;
    }
}
