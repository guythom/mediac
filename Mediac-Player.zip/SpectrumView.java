import javax.swing.Timer;
import javax.swing.JComponent;
import java.awt.Font;
import java.awt.Color;
import java.awt.AWTEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.AlphaComposite;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.geom.AffineTransform;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

import java.io.File;
import java.util.Arrays;
import javax.imageio.ImageIO;

public class SpectrumView extends JComponent implements MouseListener,MouseMotionListener{

	public final static long serialVersionUID = 0323421234L;
	
	protected boolean stop = true;
	protected boolean pause = false;
	protected boolean standardMode = false;
	
	protected int type = 0;
	protected float[] frames;
	
	protected Timer timer;
	protected AudioPlayer player;
	
	protected BufferedImage fond = null;
	protected GradientPaint gradient = null;
	protected Color color = new Color(150,150,150);
	
	/**
	gradient = new GradientPaint(width_r / 2, 10, red, (width_r) / 2, 10 + width_r,green);
	**/
	
    public SpectrumView(AudioPlayer player){
	
		this.player = player;
		enableEvents(AWTEvent.FOCUS_EVENT_MASK);
		enableEvents(AWTEvent.KEY_EVENT_MASK);
		enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		setRequestFocusEnabled(true);
		setFocusable(true);
		setOpaque(false);
		init();
		
	}
	
	public void init(){
		timer = new Timer(25,new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				if(!pause && !standardMode){
					//frames = player.getFrames();
					repaint();
				}
			}
		});
		timer.setRepeats(true);
	}

    public void start(){
		timer.start();
		stop = false;
	}
	 
	public void stop(){
		stop = true;
		repaint();
		pause = false;
		timer.stop();
	}
	
	@Override
	public void paintComponent(Graphics g){
	    int width = getWidth();
	    int height = getHeight();
	    Graphics2D g2d = (Graphics2D)g;
		g2d.setColor(Color.WHITE);
		//g2d.fillRect(0,0,getWidth(),height);
		//g2d.setColor(color);
		switch(type){
	        case 1 :
				spectre(g2d,width,height,1);
		    break;
			
			default:
				noView(g2d,width,height);
			break;
	    }
	}
	
	
	public void spectre(Graphics2D g2d,int width,int height,int type){
	/**int x = 0;
	int x0 = (width - 280);
	int y = height - 10;
	int h = 0;
		for(int i = 0; i < 32; i++){
			x = (i == 0)?x0:(x + 8);
			h = (int)(frames[i] * 300.0f);
			
			g2d.fillRect(x,y,5,h);
		}**/
	int x1 = 10;
	 int y0 = height - 10;
	 int ly1 = y0;
	 int lx1 = 0;
	 int x = 5;
	 int y = 0;
	 int j = 0;
	 
	   for(int i = 0; i < frames.length; i++){
	   if(type == 0)
		x = (x >= width)?10:x;// vu metre infini
	      
		  if(i == (frames.length - 1)) 
		    j = i;
		    else if(i == 0){
			j = 0;
			int yn = (int)(y0 - (frames[i] * height));
			ly1 = yn;
			} else j = i+1;
		  
		   float val = (frames[j] < 0)? (0 - frames[i]):frames[i];
		   y = (int)(y0 - (val * height));
		   x1 = x+1;
		   g2d.drawLine(lx1,ly1,x1,y);
		   lx1 = x1;
		   ly1 = y;
		   x += 1;
	   }
	}
	
	public void noView(Graphics2D g2d,int width,int height){
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
		if(fond != null)
			g2d.drawImage(fond, 0, 0, width, height, null);
		else{
			g2d.setColor(Color.BLACK);
			g2d.fillRect(0,0,width, height);
		}
		standardMode = true;
	}
	
	public void paintArtWork(BufferedImage artworkImage){
		if(artworkImage != null)
		fond = artworkImage;
		repaint();
	}
	
    public synchronized void setAnimatedType(int type){
		this.type = (type == 1)?type:0;
		if(this.type != 0)
			standardMode = false;
	}
	public synchronized int getAnimatedType(){
		return type;
	}
	 
	public synchronized void pause(boolean st){
		pause = st;
	}
	 
	public boolean isRunning(){
		if(!stop) 
			return true;
	    else 
			return false;
	}
	
		public void process(int[] samples){
		int mod =  samples.length % 64;
		int len = samples.length - mod;
		int div = len/64;
		float max = (65536.0f * ((float)(div + 1))); 
		float ech = 0.0f;
		int sample = 0;
		int j1 = 0;
		int j2 = 0;
		int i1 = 0;
		int i2 = 0;
		boolean parTest = false;
	
		int [] tL = new int[32];
		int [] tR = new int[32];
		float [] tempL = new float[32];
		float [] tempR = new float[32];
		
		for(int i = 0; i < len; i++){
			sample = samples[i] + 32768;
			parTest = (i%2 == 0)?true:false;
			
			if(parTest){
				if(j1 == div){
					ech = (float)tL[i1];
					tempL[i1] = ech/max ;
					i1++;
					j1 = 0;
				}
				else{
					tL[i1] += sample;
					j1++;
				}
			}	
			else{
				if(j2 == div){
					ech = (float)tR[i2];
					tempR[i2] = ech/max ;
					i2++;
					j2 = 0;
				}
				else{
					tR[i2] += sample;
					j2++;
				}	
			}
			
		}
		
		for(int i = 0; i < 32; i++)
		frames[i] = (tempL[i] + tempR[i])/2.0f;
	}
	 
	public void mouseClicked(MouseEvent e){}
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
	public void mouseDragged(MouseEvent e){}
    public void mouseMoved(MouseEvent e){}
	 
}