import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.GradientPaint;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class TimerBasedAnimation extends JPanel implements ActionListener {
  private Ellipse2D.Float ellipse = new Ellipse2D.Float();
  int colors[][] = new int[][]{ {255,120,200},
                                {0,0,50},
								{145,10,0},
								{233,220,44},
								{55,70,200},
								{120,200,255},
								{100,10,200},
								{50,255,100},
								{200,100,255},
								{100,100,100},
								{200,10,255},
								{220,0,50},
								{0,0,0},
								{150,50,150},
								{0,200,200},
								{200,100,0}
							 };
  private double esize;
  int i = 0;
  int rate = 1;

  private double maxSize = 0;
  AudioPlayer player;
  private boolean initialize = true;

  Timer timer;

  ActionListener updateProBar;

  public TimerBasedAnimation(AudioPlayer player) {
    setXY(20 * Math.random(), 200, 200);
    setBackground(Color.BLACK);
	this.player = player;
    timer = new Timer(10, this);
    timer.setInitialDelay(190);
    timer.start();
  }

  public void setXY(double size, int w, int h) {
    esize = size;
    ellipse.setFrame(10, 10, size, size);
  }

  public void reset(int w, int h) {
    if(rate == 0 ) rate = 10;
    maxSize = w/rate;
    setXY(maxSize * Math.random(), w, h);
  }

  public void step(int w, int h) {
  float demux = player.getMediaPlayer().getMediaStatistics().f_demux_bitrate*1000.0f;
						   int rel = (int)demux;
						   float dec = demux - rel;
						   int rate = (int)((dec < 0)?(0 - dec)*10.0f: dec * 10.0f);
						   if(rate == 0 ) rate = 10;
    maxSize = w/rate;
    esize++;
    if (esize > maxSize) {
      setXY(1, w, h);
    } else {
      ellipse.setFrame(ellipse.getX(), ellipse.getY(), esize, esize);
    }
  }

  public void render(int w, int h, Graphics2D g2){					   
    int [] color = colors[i];
    g2.setColor(new Color(20,20,255));
	g2.setPaint(new GradientPaint(10,0,new Color(50,50,255),w/2,h,new Color(color[0],color[1],color[2])));
    g2.fill(ellipse);
	i = (i == 15)?0:i++;
  }

  public void paint(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;

    RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);

    rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

    g2.setRenderingHints(rh);
    Dimension size = getSize();

    if (initialize) {
      reset(size.width, size.height);
      initialize = false;
    }
    this.step(size.width, size.height);
    render(size.width, size.height, g2);
  }

  public void actionPerformed(ActionEvent e) {
    repaint();
  }
  
}

   
    