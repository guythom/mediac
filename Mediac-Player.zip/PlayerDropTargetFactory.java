import java.awt.dnd.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.Component;
import java.util.List;
import java.util.Iterator;
import java.io.IOException;
import java.io.File;

public class PlayerDropTargetFactory{

	private static DataFlavor fileListData = DataFlavor.javaFileListFlavor;
	
	public static DropTarget newDropTargetInstance(Component component,Player player){
	if(component == null || player == null)return null;
	DropTarget dropTarget = null;
	try{
		dropTarget = new DropTarget(component,new PlayerDropListerner(player));
	}
	catch(Exception e){}
	return dropTarget;
	}
	
	private static class PlayerDropListerner implements DropTargetListener{
		Player player;
		private Transferable transData = null;
		
		public PlayerDropListerner(Player player){
		this.player = player;
		}
		
		public void dropActionChanged(DropTargetDragEvent e){
		
		}
		public void dragEnter(DropTargetDragEvent e){
		if(e.isDataFlavorSupported(fileListData)){
			e.acceptDrag(DnDConstants.ACTION_MOVE);
			try{
				transData = e.getTransferable();
			}
			catch(Exception ex){
			
			}
		}
		else e.rejectDrag();
		}
		public void dragOver(DropTargetDragEvent e){
		
		}
		public void dragExit(DropTargetEvent e){
		
		}
		
		public void drop(DropTargetDropEvent event){
		try{
			List fileList = (List)
			//event.getTransferable().getTransferData(fileListData);
			transData.getTransferData(fileListData);
			if(fileList == null) System.exit(0);
			int j = 0;
			for(Iterator i = fileList.iterator();i.hasNext();){
				File file = (File)i.next();
				System.out.println(file.getName());
				player.playerNameList.add
				(player.playList.getSelectedIndex() + 1 + j,file.getName());
				player.playerPathList.add
				(player.playList.getSelectedIndex() + 1 + j,player.getWinEncodedPath(file));
				j++;
			}
			player.playList.setListData(player.playerNameList.toArray());
			player.listPane.updateUI();
				
        } catch (Exception e){
			e.printStackTrace();
			} 
		}
	
	}
	
}