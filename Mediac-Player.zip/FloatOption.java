/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
import javax.swing.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.*;
import java.awt.*;
import com.sun.awt.AWTUtilities;
//import mediac.gui.MFrame;

public class FloatOption extends JDialog{

 JFrame frame;
 boolean view;
 
 public FloatOption(JFrame frame){
 super(frame,false);
 this.frame = frame;
 setUndecorated(true);
 view = false;
 setSize(new Dimension(550,159));
  }
    
	public void view(){
	    int y = 0;
		int x = 0;
	    Dimension dim = frame.getSize();
        Point location = frame.getLocation();
		y = location.y + 3*dim.height/5 - 35;
		x = location.x + dim.width/2;
		
          setLocation(x,y);
		  if(!view){
		  view = true;
		  setOpacity(0.5f);
		  Shape shape = new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20);
          AWTUtilities.setWindowShape(this, shape); 
		  }
	      setVisible(true);
	}
	
}