// QuentinC Sound API
// Copyright � 2010, QuentinC http://quentinc.net/
// LGPL license
//
// This is a simple demo which show some of the features contained in this library
// just run it as usual : java Demo

import java.io.*;
import java.util.*;
import quentinc.audio.*;
import quentinc.geom.Vector;

public class Demo {
static int count = 0;
public static void main (String[] args) throws Exception {
final AudioManager mgr = new AudioManager(); // Create a new audio manager with default settings
final Sample ding = mgr.loadSample(new File( "ding.wav" )); // Load our ding sample in memory
final Random rnd = new Random(); 
final int[] notes = { -19, -19, -12, -9, -7, -5, -2, 0, 0, 0, 3, 5, 7, 10, 12, 12, 15, 17 }; // Explanations later about these values
final int tempo = 500;

mgr.setListenerPosition( new Vector(0,0,0) ) // Set the listener position to the position 0;0;0
.setListenerOrientation( new Vector(0,1,0) ) // The listener is facing strate away. By convention, x=horizontal, y=forward and z=upward, but you can freely make the opposite in your programs if you want to
.setListenerUpwards( new Vector(0,0,1) ) // In our coordinate system, the up direction is the Z axis
.addDSP( new Flanger(mgr,0.4f,0.9f,0.75f,0.8f,0.0008f,0.0008f,0.1f))//
.addDSP( new Echo( mgr, 0.2f, 0.6f )); // Add an echo effect applied to all sounds played by the manager. The echo has a delay of 225ms and a intensity of 60%

// Let's prepare the thread in charge for playing the sounds !

Thread thr = new Thread(new Runnable(){
public void run(){
try { while (true) {

double angle = 2*Math.PI;//rnd.nextDouble() * 2 * Math.PI; // Choose a random angle in radians from 0 to 2pi
double distance = 2.0;//rnd.nextDouble() * 2; // Choose a random distance between 0 and 2.
int note = -1;//notes[ rnd.nextInt(notes.length) ]; // Choose a random value ammong those defined in the notes array 
int sleepTime = tempo * (rnd.nextInt( 5 ) +1 ); // Choose a random waiting time til the next note, always multiple of tempo miliseconds
double posX = distance*Math.cos(angle), posY = distance*Math.sin(angle); // Compute the position of the point corresponding to the random angle and distance chosen
double pitch = Math.pow(2, note/12.0); // Compute the pitch of the sound. This formula and the notes array above are made so that the result sounds like an interesting small music.

// Let's play our sound and set the parameters computed above
mgr.play(ding) 
.set3DPosition( new Vector(posX, posY, 0) )
.setPitch( (float)pitch );

mgr.update3D(); // Update the 3D engine. This method should be called each time there are changes in the 3D world. For a game, it should be called once per frame in the game loop.

Thread.currentThread().sleep( sleepTime ); // Sleep, waiting for the next note to play
System.out.println(""+count);
count++;
}} catch (InterruptedException e) {}
}});
thr.start(); // Let's go !
System.out.println("Press enter to quit.");
System.in.read(); // Return when pressing enter
thr.interrupt(); // Stop the thread 
ding.close(); // Free the memory used by our sample
mgr.close(); // Free the resources associated with the manager
}}
