	
import java.io.*;
import java.util.*;

public class DataBase implements Serializable{
	
		public static final long serialVersionUID = -1239220405231L;
		protected ArrayList<String> dbName = new ArrayList<String>();
		protected ArrayList<String> dbPath = new ArrayList<String>();
		
		public DataBase(){
			
		}
		
		public void add(String name,String path){
			if(!dbPath.contains(path)){
				dbName.add(name);
				dbPath.add(path);
			}
		}
		
		public void remove(String name){
			int i = dbName.indexOf(name);
			if(i != -1){
				dbName.remove(i);
				dbPath.remove(i);
			}
		}
		
		public String getPath(String name){
			int i = dbName.indexOf(name);
			return (i != -1)?dbPath.get(i):null;
		}
		
}