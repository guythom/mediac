import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.File;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Iterator;

public class FileManip{

 PrintWriter writer;
 Scanner scanner;
 
  public FileManip(){
  
  }
  
  public void writeToFile(ArrayList<String> word_list){
     for(Iterator<String> i = word_list.iterator();i.hasNext();){
        writeLine(i.next());
     }
  }
  
  public void writeToFile(String[] word_list){
     for(int i = 0; i < word_list.length; i++){
        writeLine(word_list[i]);
     }
  }
  
  public void initWriteFile(String file){
    try{
     writer = new PrintWriter(new FileOutputStream(new File(file)));
     }
	  catch(Exception e){}
  }

  public void writeLine(String str){
     try{
      writer.println(str);
	  writer.flush();
     }
      catch(Exception e){}
  }
  
  public void initReadFile(String file){
  try{
     scanner = new Scanner(new FileInputStream(new File(file)));
     }
	  catch(Exception e){}
  }
  
  public String readLine(){
  String ret = "";
     try{
      ret = scanner.next();
      }
      catch(Exception e){}
	  return ret;
  }
  
  public ArrayList<String> getListWord(){
  ArrayList<String> list = new ArrayList<String>();
    while(scanner.hasNext()){
	String read = scanner.nextLine();
	list.add(read);
    }
    return list;
  }
  
  public static void main(String[]args){
  FileManip file = new FileManip();
  file.initReadFile(args[0]);
  file.initWriteFile(args[1]);
  file.writeToFile(file.getListWord());
  }
  

}