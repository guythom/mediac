import uk.co.caprica.vlcj.binding.internal.libvlc_media_t;
import uk.co.caprica.vlcj.binding.LibVlc;
import uk.co.caprica.vlcj.player.MediaPlayer;
import uk.co.caprica.vlcj.player.MediaPlayerEventListener;
import uk.co.caprica.vlcj.player.MediaPlayerFactory;
import uk.co.caprica.vlcj.player.directaudio.AudioCallback;
import uk.co.caprica.vlcj.player.directaudio.AudioCallbackAdapter;
import uk.co.caprica.vlcj.player.embedded.videosurface.CanvasVideoSurface;
import uk.co.caprica.vlcj.player.directaudio.DirectAudioPlayer;
import davaguine.jeq.spi.EqualizerInputStream;
import com.sun.jna.Pointer;

import java.awt.Canvas;
import java.awt.Font;
import java.awt.Panel;
import java.awt.Color;
import java.awt.Point;
// import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.AlphaComposite;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class MediacPlayer implements MediaPlayerEventListener, AudioCallback {

    protected static final String[] DEFAULT_FACTORY_ARGUMENTS = {
	    "--video-title=Mediac Player",
		"--no-snapshot-preview",
        "--quiet",
        "--quiet-synchro",
        "--intf=dummy",
		"--sub-filter=logo:marq"
    };
    
	protected int audioDatas[] = null;
	protected AudioVisualiser visualiser;
	protected BufferedImage fond;
	//protected BufferedImage fond_g;
	public final CanvasVideoSurface cvs;
	private final Canvas canvas;
	public final PlayerPane panel;
    private final MediaPlayerFactory mediaPlayerFactory;
    private final DirectAudioPlayer mediaPlayer;
	
	protected int playerId = -1;
	
	
	protected Color g_base = new Color(0,0,51);
	protected Color g_add = new Color(0,0,0);
	
    public MediacPlayer(String format, int rate, int channels) {
        mediaPlayerFactory = onGetMediaPlayerFactory();
		mediaPlayerFactory.setUserAgent("Mediac Player");
		//mediaPlayerFactory.setApplicationId("nkot.mediac.player","2.0","mediac/src/img/i48.png");
        mediaPlayer = mediaPlayerFactory.newDirectAudioPlayer(format, rate, channels, onGetAudioCallback());
		
		try{
			fond = ImageIO.read(new File("fos.png"));
			//fond_g = ImageIO.read(new File("fog.png"));
			
		}	catch(Exception e){fond = null;}
		
        canvas = new Canvas(){
			@Override
			public void paint(Graphics g){
				//int wsize = Toolkit.getDefaultToolkit().getScreenSize().width;
				
				Graphics2D g2d = (Graphics2D) g;
				g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
				
				GradientPaint back_gradient = new GradientPaint(0, getHeight(),g_base, getWidth(), 50,g_add);
				g2d.setPaint(back_gradient);
				g2d.fillRect(0, 0, getWidth(), getHeight());
				//g2d.setColor(Color.WHITE);
				g2d.setColor(g_base);
				g2d.drawRect(0,0,getWidth(), getHeight());
				
				if(fond != null){
					int xb = (getWidth() > fond.getWidth())?((getWidth() - fond.getWidth())/2):0;
					int yb = (getHeight() > fond.getHeight())?((getHeight() - fond.getHeight())/2):0;
					
					int bw = (getWidth() > fond.getWidth())?fond.getWidth():getWidth();
					int bh = (getHeight() > fond.getHeight())?fond.getHeight():getHeight();
					
					g2d.drawImage(fond, xb, yb, bw, bh, null);
				}
				/**else{
					g2d.setColor(Color.BLACK);
					g2d.fillRect(0,0,getWidth(), getHeight());
				}**/
			
			}
		};
		
		cvs = mediaPlayerFactory.newVideoSurface(canvas);//.
		panel = new PlayerPane(canvas);
		panel.repaint();
        mediaPlayer.addMediaPlayerEventListener(this);
		mediaPlayer.setPlaySubItems(true);
		visualiser = new AudioVisualiser(this);
		//startVisualiser();
		
    }
	/** seulement si le canvas est visible**/
	public void attach(){
		cvs.attach(mediaPlayerFactory.libvlc,mediaPlayer);
	}
  
   public void setEnableMouseInputHandling(boolean enable){
	mediaPlayerFactory.libvlc.libvlc_video_set_mouse_input(getMediaPlayer().mediaPlayerInstance(), enable ? 1 : 0);
   }
   
   public void setPlayerId(int playerId){
   this.playerId = playerId;
   }
   
   public void setEnableKeyInputHandling(boolean enable){
   mediaPlayerFactory.libvlc.libvlc_video_set_key_input(getMediaPlayer().mediaPlayerInstance(), enable ? 1 : 0);
   }
   
	public synchronized void setAudioDatas(byte[]datas,final EqualizerInputStream eq,boolean equalize){
		audioDatas = ((equalize)?eq.getInt():eq.getInteger(datas));
	}
	
	public synchronized int[] getAudioDatas(){
		return audioDatas;
	}
  
   public PlayerPane getCanvas(){
      return panel;
   }
   
    public final MediaPlayerFactory getMediaPlayerFactory() {
        return mediaPlayerFactory;
    }

  
    public final DirectAudioPlayer getMediaPlayer() {
        return mediaPlayer;
    }

	private final LibVlc getLibVlc(){
	return mediaPlayerFactory.libvlc;
	}
    public final void release() {
        onBeforeRelease();
        mediaPlayer.release();
        onAfterRelease();
    }

    public final void release(boolean releaseFactory) {
        release();
        if(releaseFactory) {
            mediaPlayerFactory.release();
        }
    }

 
    protected MediaPlayerFactory onGetMediaPlayerFactory() {
        return new MediaPlayerFactory(onGetMediaPlayerFactoryArgs());
    }

    protected String[] onGetMediaPlayerFactoryArgs() {
        return DEFAULT_FACTORY_ARGUMENTS;
    }

    protected AudioCallback onGetAudioCallback() {
        return this;
    }

    protected void onAfterConstruct() {
    }

 
    protected void onBeforeRelease() {
    }

    protected void onAfterRelease() {
    }

    // === MediaPlayerEventListener =============================================

    @Override
    public void mediaChanged(MediaPlayer mediaPlayer, libvlc_media_t media, String mrl) {
    }

    @Override
    public void opening(MediaPlayer mediaPlayer) {
    }

    @Override
    public void buffering(MediaPlayer mediaPlayer, float newCache) {
    }

    @Override
    public void playing(MediaPlayer mediaPlayer) {
    }

    @Override
    public void paused(MediaPlayer mediaPlayer) {
		
    }

    @Override
    public void stopped(MediaPlayer mediaPlayer) {
    }

    @Override
    public void forward(MediaPlayer mediaPlayer) {
    }

    @Override
    public void backward(MediaPlayer mediaPlayer) {
    }

    @Override
    public void finished(MediaPlayer mediaPlayer) {
    }

    @Override
    public void timeChanged(MediaPlayer mediaPlayer, long newTime) {
    }

    @Override
    public void positionChanged(MediaPlayer mediaPlayer, float newPosition) {
    }

    @Override
    public void seekableChanged(MediaPlayer mediaPlayer, int newSeekable) {
    }

    @Override
    public void pausableChanged(MediaPlayer mediaPlayer, int newPausable) {
    }

    @Override
    public void titleChanged(MediaPlayer mediaPlayer, int newTitle) {
    }

    @Override
    public void snapshotTaken(MediaPlayer mediaPlayer, String filename) {
    }

    @Override
    public void lengthChanged(MediaPlayer mediaPlayer, long newLength) {
    }

    @Override
    public void videoOutput(MediaPlayer mediaPlayer, int newCount) {
    }

    @Override
    public void error(MediaPlayer mediaPlayer) {
    }

    @Override
    public void mediaMetaChanged(MediaPlayer mediaPlayer, int metaType) {
    }

    @Override
    public void mediaSubItemAdded(MediaPlayer mediaPlayer, libvlc_media_t subItem) {
    }

    @Override
    public void mediaDurationChanged(MediaPlayer mediaPlayer, long newDuration) {
    }

    @Override
    public void mediaParsedChanged(MediaPlayer mediaPlayer, int newStatus) {
    }

    @Override
    public void mediaFreed(MediaPlayer mediaPlayer) {
    }

    @Override
    public void mediaStateChanged(MediaPlayer mediaPlayer, int newState) {
    }

    @Override
    public void newMedia(MediaPlayer mediaPlayer) {
    }

    @Override
    public void subItemPlayed(MediaPlayer mediaPlayer, int subItemIndex) {
    }

    @Override
    public void subItemFinished(MediaPlayer mediaPlayer, int subItemIndex) {
    }

    @Override
    public void endOfSubItems(MediaPlayer mediaPlayer) {
    }

    // === RenderCallback =======================================================

    @Override
    public void play(DirectAudioPlayer mediaPlayer, Pointer samples, int sampleCount, long pts) {
    }

    @Override
    public void pause(DirectAudioPlayer mediaPlayer, long pts) {
    }

    @Override
    public void resume(DirectAudioPlayer mediaPlayer, long pts) {
    }

    @Override
    public void flush(DirectAudioPlayer mediaPlayer, long pts) {
    }

    @Override
    public void drain(DirectAudioPlayer mediaPlayer) {
    }
	/***** visualiseur**/
	public void startVisualiser(){
		panel.add(java.awt.BorderLayout.SOUTH,visualiser);
		visualiser.start();
	}
	public void pauseVisualiser(){
		visualiser.pause();
	}
	public void resumeVisualiser(){
		if(visualiser.stoped()) panel.add(java.awt.BorderLayout.SOUTH,visualiser);
		visualiser.resume();
	}
	public void stopVisualiser(){
		panel.remove(visualiser);
		visualiser.stop();
	}
	
	public class PlayerPane extends Panel{
		private Canvas canvas;
		protected boolean mouseOver = false;
		Point p = null;
		
	    public PlayerPane(Canvas canvas){
			this.canvas = canvas;
			setLayout(new java.awt.BorderLayout());
			add(java.awt.BorderLayout.CENTER,canvas);
			canvas.setBackground(Color.BLACK);
			this.canvas.addMouseListener(new MouseAdapter(){
				public void mouseEntered(MouseEvent e){
					mouseOver = true;
				}
				public void mouseExited(MouseEvent e){
					mouseOver = false;
				}
				public void mouseReleased(MouseEvent e){
				
				}
			});
			
		}
		
		public Canvas getPlayerPane(){
			return  canvas;
		}
		
		public void request(){
			requestFocus();
		}
		
		public int getPlayerId(){
			return playerId;
		}
		
		public boolean isMouseOver(){
			return mouseOver;
		}
		
		
		public void paintComponent(Graphics g){
				
		}
		
		public boolean containsPoint(int x,int y){
			p = getLocationOnScreen();
			if(x < p.x || y < p.y) return false;
			int w = getWidth();
			int h = getHeight();
			int px = x - p.x;
			int py = y - p.y;
			if(px <= w && py <= h) 
				return true;
			else 
				return false;
		}
		
	}
	
}
