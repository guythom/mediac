
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Point;

import javax.swing.*;
import javax.swing.border.LineBorder;



public class Dessin extends JPanel {
	
	// Nom du fractal (par d�faut Julia)
	private String forme = "Julia";
	//Nombre d'iteration
	private int ite;
	
	private String coloration;
	//Coordonn�es pour Mandelbrot
	private double ymax;
	private double ymin;
	private double xmax;
	private double xmin;
	//Coordonn�es pour le nombre complexe de Julia
	private double ca,cb =0;
	//Bool�en pour dessiner la zone � zoomer, ici � faux car on ne dessine pas la zone
	// � zoomer quand on dessine le fractal
	private boolean dessinRect = false;
	//Point de coordonn�es(x,y) en fonction de la souris pour dessiner une zone � zoomer
	private Point r1,r2;
	//Nombres pour les couleurs rouge, vert, bleu
	private int rouge, vert, bleu;
	
	/* Variables integer et tableau pour cr�er des nuances de couleurs
	   Couleurs d�grad�es premi�rement puis couleurs multiples choisies */
	int NB_COULS_DEGRA = 30;
	int NB_COULS_DEGRA2 = 10;
	int NB_COULS_MULTI = 12;
	Color[] couleursDegra = new Color[NB_COULS_DEGRA + 2];
	Color[] couleursDegra2 = new Color[NB_COULS_DEGRA2 + 2];
	Color couleursMulti[] = {Color.blue, Color.cyan, Color.green, Color.magenta, Color.orange, Color.pink, 
							 Color.red, Color.yellow, Color.darkGray, Color.gray, Color.lightGray, Color.white}; 
	

	// Constructeur
	public Dessin(){
	
		this.setPreferredSize(new Dimension(770, 650));
		this.setBackground(Color.lightGray);
		this.setBorder(new LineBorder(Color.RED, 2));
	
	
		//Cr�ation du tableau de couleurs d�grad�es
		for(int i = 0; i < 10; i++)
			couleursDegra[i] = new Color(200 - i * 20, i * 20, 0); 
		for(int i = 0; i < 10; i++)
			couleursDegra[i + 10] = new Color(0, 200 - i * 20, i * 20);
		for(int i = 0; i < 10; i++)
			couleursDegra[i + 20] = new Color(i * 20, 0, 200 - i * 10);
		
	
	}
	
	public void defCouleur(int rouge, int vert, int bleu)
	{
		JOptionPane message = new JOptionPane();
		//D�finition du tableau de couleur en fonction des valeurs contenues dans les 
		//champs textes rouge, vert, bleu
		if(rouge >= 0 && rouge<25 && vert>=0 && vert<25 && bleu>=0 && bleu<25)
		{
			for(int i = 0; i < 10; i++)
				couleursDegra[i] = new Color(30+rouge*i, vert*(i/2), bleu*i); 
			for(int i = 0; i < 10; i++)
				couleursDegra[i + 10] = new Color(rouge*i, 30+vert*i, bleu*(i/2));
			for(int i = 0; i < 10; i++)
				couleursDegra[i + 20] = new Color(rouge*(i/2), vert*i, 30+bleu*i);
			
			for(int i = 0; i < 10; i++)
				couleursDegra2[i] = new Color(rouge*i + 10, vert*i + 10, bleu*i + 10);
		}
	}

	// M�thode pour dessiner les fractales
    public void paint(Graphics g){
    	Graphics2D g2d = (Graphics2D)g;
	    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
    	// Cr�ation d'un rectangle noir pour "effacer" la fractale pr�c�dente
    	g2d.setColor(Color.black);
    	g2d.fillRect(1, 1, getWidth(), getHeight());
    	
    	// D�finition des variables couleur
    	defCouleur(rouge, vert, bleu);
    	
    	// Si on a selectionn� "Mandelbrot" dans la JCombobox...
    	if(forme == "Mandelbrot")
    	{
    		//Cr�ation du fractal Mandelbrot
    		Mandelbrot m = new Mandelbrot();
    		//Enregistrement des coordonn�es et de l'it�ration pour la classe Mandelbrot
    		m.setCoord(xmin,xmax,ymin,ymax);
    		m.setIteration(ite);
    		//Calcul du fractal
    		m.calcul();
    		//On parcourt toute la matrice axe
    		for(int i = 0; i < m.axe.length; i++)
    		{
    			for(int j = 0;j< m.axe[0].length;j++)
    			{
    				/*Si on constate que les valeurs de la matrice sont 0 on colore en noir
    				  sinon on colore en fonction de la m�thode de coloration */
    				if(m.axe[i][j] == 0 ) 
    	             g2d.setColor(Color.black);
    	           else
    	           {
    	        	   if (coloration == "deg")
    	        		   g2d.setColor(couleursDegra[(m.axe[i][j] - 1) % NB_COULS_DEGRA]);
    	        	   else if(coloration == "arc")
    	        		   g2d.setColor(couleursMulti[(m.axe[i][j] - 1) % NB_COULS_MULTI]);
    	        	   else
    	        		   g2d.setColor(couleursDegra2[(m.axe[i][j] - 1) % NB_COULS_DEGRA2]);
    	           }          
    	           g2d.drawLine(i,j,i,j);
    			 }
    		}   
    		
    	}
    	
    	// Si on a selectionn� "Julia" dans la JCombobox...
    	if(forme == "Julia")
    	{
    		//Cr�ation du fractal Julia
    		Julia ju = new Julia();
    		//Enregistrement de l'it�ration pour la classe Julia
    		ju.setIteration(ite);
    		//Enregistrement des coordoon�es du nombre complexe 
    		ju.setCaCb(ca, cb);
    		//Calcul du fractal
    		ju.calcul();
    		
    		//On parcourt toute la matrice axe
    		for(int i = 0; i < ju.axe.length; i++)
    		{
    			for(int j = 0;j< ju.axe[0].length;j++)
    			{
    				/*Si on constate que les valeurs de la matrice sont 0 on colore en noir
    				  sinon on colore en fonction de la m�thode de coloration */
    		
    				if(ju.axe[i][j] == 0 ) 
    	             g2d.setColor(Color.black);
    				
    	           else
    	           {
    	        	   if (coloration == "deg")
    	        		   g2d.setColor(couleursDegra[(ju.axe[i][j] - 1) % NB_COULS_DEGRA]);
    	        	   else if(coloration == "arc")
    	        		   g2d.setColor(couleursMulti[(ju.axe[i][j] - 1) % NB_COULS_MULTI]);
    	        	   else
    	        		   g2d.setColor(couleursDegra2[(ju.axe[i][j] - 1) % NB_COULS_DEGRA2]);
    	           }          
    	           g2d.drawLine(i,j,i,j);
    			 }
    		}
    	}
    	
    	// Si on a selectionn� "SierpinkiTriangle" dans la JCombobox...
    	if(forme == "SierpinkiTriangle")
    	{
    		//Cr�ation du triangle de Sierpinki	
    		SierpinkiTriangle sierp = new SierpinkiTriangle();
    			
    			// Remplissage du tableau de couleur dans une couleur avec
    			// son d�grad�
    			for(int i = 0; i < 200; i++)
    	        {
    	            sierp.colorWheel[i] = new Color(i + 56, 4, i + 56);
    	        }
    			
    			// Remplissage de la suite du tableau de couleur dans une couleur avec
    			// son d�grad�
    	        for(int j = 0; j < 200; j++)
    	        {
    	            sierp.colorWheel[j + 200] = new Color(255, 255 - j, 255 - j );
    	        }
    			
    			//Taille de la fen�tre : largeur et hauteur
    	        int larg = getSize().width;
    	        int haut = getSize().height;
    	        //Enregistrement de l'it�ration pour la classe SierpinkiTriangle
    	        sierp.setIteration(ite);
    	        //Calcul du fractal
    	        sierp.gasket(g, sierp.iteration, 0, haut, larg, haut);
    	    
    	}
    	// Si on a selectionn� "SierpinkiTapis" dans la JCombobox...
    	if(forme == "SierpinkiTapis")
    	{
    		//Cr�ation du tapis de Sierpinki	
    		SierpinkiTapis sier = new SierpinkiTapis();
    		
    		// Remplissage du tableau de couleur dans une couleur avec
			// son d�grad�
    		for(int i = 0; i < 200; i++)
            {
                sier.colorWheel[i] = new Color(i + 56, i + 56, 255);
            }

    		// Remplissage de la suite du tableau de couleur dans une couleur avec
			// son d�grad�
            for(int j = 0; j < 200; j++)
            {
                sier.colorWheel[j + 200] = new Color(255 - j, 4, 255 - j);
            }
    		
            //Taille de la fen�tre : largeur et hauteur
            int larg = getSize().width;
            int haut = getSize().height;
            //Enregistrement de l'it�ration pour la classe SierpinkiTapis
            sier.setIteration(ite);
            //Calcul du fractal
	        sier.tapis(g, sier.iteration, 0, 0, larg, haut);
    		
    	}
    	
    	// Si on a selectionn� "Koch" dans la JCombobox...
    	if(forme == "Koch")
    	{
    		//Cr�ation du fractal de Koch
    		Koch koch = new Koch();
    		
    		// Remplissage du tableau de couleur dans une couleur avec
			// son d�grad�
	        for(int i = 0; i < 200; i++)
	        {
	            koch.colorWheel[i] = new Color(i + 56, 0, 55);
	        }
	        
	        // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
	        for(int j = 0; j < 200; j++)
	        {
	            koch.colorWheel[j + 200] = new Color(255, 0, j + 56);
	        }
	        
	        // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
	        for(int k = 0; k < 200; k++)
	        {
	            koch.colorWheel[k + 400] = new Color(255 - k, 0, 255);
	        }
	        
	        // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
	        for(int l = 0; l < 200; l++)
	        {
	            koch.colorWheel[l + 600] = new Color(55, 0, 255 - l);
	        }
	    	
	        //Enregistrement de l'it�ration pour la classe Koch
	        koch.setIteration(ite);
	        //Calcul du fractal
	        koch.kochcurve(g, koch.iteration, 0, 420);
	        koch.kochcurve(g, koch.iteration, 120, 420);
	        koch.kochcurve(g, koch.iteration, -120, 420);
    	}
    	
    	// Si on a selectionn� "Koch2" dans la JCombobox...
    	if (forme == "Koch2"){
    		
    		//Cr�ation du fractal de Koch
    		Koch2 koch2 = new Koch2();
    		
    		// Remplissage du tableau de couleur dans une couleur avec
			// son d�grad�
    		for(int i = 0; i < 200; i++)
    	    {
    			koch2.colorWheel[i] = new Color(i + 56,123, 234);
    	    }
    		
    		// Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
    	    for(int j = 0; j < 200; j++)
    	    {
    	        koch2.colorWheel[j + 200] = new Color(19, 255 - j, 234);
    	    }
    	     
    	    //Taille de la fen�tre : largeur et hauteur
    	    int larg = getSize().width;
    	    int haut = getSize().height;
    	    
    	    koch2.x = larg / 4;
    	    koch2.y = haut / 4;
    	    //Enregistrement de l'it�ration pour la classe Koch2
    	    koch2.setIteration(ite);
    	    //Calcul du fractal
    	    koch2.koch2(g, koch2.iteration, larg / 2, 1);
    	    koch2.koch2(g, koch2.iteration, larg / 2, 2);
    	    koch2.koch2(g, koch2.iteration, larg / 2, 3);
    	    koch2.koch2(g, koch2.iteration, larg / 2, 0);   
    	}
    	
    	// Si on a selectionn� "Hilbert" dans la JCombobox...
    	if(forme == "Hilbert")
    	{
    		//Cr�ation du fractal de Hilbert
    		Hilbert hilbert = new Hilbert();
    		
    		// Remplissage du tableau de couleur dans une couleur avec
			// son d�grad�
    		for(int i = 0; i < 128; i++)
            {
    			hilbert.colorWheel[i] = new Color(0, 255 - i, i);
            }

    		// Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int j = 128; j < 256; j++)
            {
            	hilbert.colorWheel[j] = new Color(0, j, j);
            }

            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int k = 0; k < 256; k++)
            {
            	hilbert.colorWheel[k + 256] = new Color(0, 255 - k, 255);
            }

            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int l = 0; l < 128; l++)
            {
            	hilbert.colorWheel[l + 512] = new Color(0, l, 255 - l);
            }

            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int i1 = 0; i1 < 128; i1++)
            {
            	hilbert.colorWheel[i1 + 640] = new Color(0, 127 - i1, 127 - i1);
            }

            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int j1 = 0; j1 < 256; j1++)
            {
            	hilbert.colorWheel[j1 + 768] = new Color(0, j1, 0);
            }
  	      
            //Enregistrement de l'it�ration pour la classe Hilbert
            hilbert.setIteration(ite);
            //Taille de la fen�tre : largeur et hauteur
            int larg = getSize().width;
            int haut = getSize().height;
            //Calcul du fractal
            hilbert.hilbert(g, hilbert.iteration, larg, haut);
    	}
    	
    	// Si on a selectionn� "Peano" dans la JCombobox...
    	if(forme == "Peano")
    	{
    		//Cr�ation du fractal de Peano
    		Peano peano = new Peano();
    		
    		// Remplissage du tableau de couleur dans une couleur avec
			// son d�grad�
    		for(int i = 0; i < 200; i++)
            {
                peano.colorWheel[i] = new Color(i + 56, i + 56, i + 56);
            }

    		// Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int j = 0; j < 100; j++)
            {
            	peano.colorWheel[j + 200] = new Color(156, 34, 255 - j);
            }
            
            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int k = 0; k < 200; k++)
            {
            	peano.colorWheel[k + 300] = new Color(255 - k, 255 - k, 1);
            }

            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int l = 0; l < 100; l++)
            {
            	peano.colorWheel[l + 500] = new Color(12, 234, 155 + l);
            }
            
         	//Taille de la fen�tre : largeur et hauteur
            int larg = getSize().width;
            int haut = getSize().height;
            
            peano.x = 0;
            peano.y = haut / 2;
            //Enregistrement de l'it�ration pour la classe Peano
            peano.setIteration(ite);
            //Calcul du fractal
            peano.peano(g, peano.iteration, larg, 1);
            
            
    	}
    	
    	// Si on a selectionn� "TriangleOrigami" dans la JCombobox...
    	if (forme == "TriangleOrigami"){
    		//Cr�ation du fractal de TriangleOrigami
    		TriangleOrigami laby = new TriangleOrigami();
    		
    		// Remplissage du tableau de couleur dans une couleur avec
			// son d�grad�
    		for(int i = 0; i < 200; i++)
            {
                laby.colorWheel[i] = new Color(i + 56, 234, i + 56);
            }

    		 // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int j = 0; j < 200; j++)
            {
            	 laby.colorWheel[j + 200] = new Color(255 - j, 234, 255);
            }

            // Remplissage de la suite du tableau de couleur dans une couleur diff�rente avec
			// son d�grad�
            for(int k = 0; k < 200; k++)
            {
            	 laby.colorWheel[k + 400] = new Color(56, 234, 255 - k);
            }
            
            //Largeur de la fen�tre
            int larg = getSize().width;
            //Enregistrement de l'it�ration pour la classe TriangleOrigami
            laby.setIteration(ite);
            //Calcul du fractal
            laby.triangleOrigami(g, laby.iteration, 0, larg, 0, larg, 0);
        
    	}
    
    	// Si on a selectionn� "Cercle" dans la JCombobox...
    	if(forme == "Cercle")
    	{
    		//Cr�ation du fractal de Cercle
    		Cercle cercle = new Cercle();
    		//Initialisation du tableau par 2 couleurs
    		cercle.colorWheel[0] = new Color(12, 34, 56);
            cercle.colorWheel[1] = new Color(2, 150, 220); //2,234,124
            //Largeur de la fen�tre
    		int larg = getSize().width;
    		//Enregistrement de l'it�ration pour la classe Cercle
    		cercle.setIteration(ite);
    		//Calcul du fractal
    		cercle.cercle(g, cercle.iteration, 0, 0, larg);
    	}
    	
    }
	
    //Permet de modifier l'it�ration
    public void setIteration(int it)
    {
    	this.ite = it;
    }
    
    //Permet de modifier le forme
    public void setForme(String forme)
    {
    	this.forme = forme;
    }
    
    //Permet de modifier la couleur
    public void setColoration(String color)
    {
    	this.coloration = color;
    }
    
    //Permet de modifier les coordonn�es de Mandelbrot
    public void setCoord(double xmin,double xmax, double ymin, double ymax)
	 {
		
		 this.xmin = xmin;
		 this.xmax = xmax;
		 this.ymin = ymin;
		 this.ymax = ymax;
			 
	 }

    //Permet de modifier les coordonn�es du nombre complexe de Julia
    public void setCaCb(double ca, double cb)
    {
    	this.ca = ca;
    	this.cb = cb;
    }

    //Permet d'obtenir l'it�ration
    public int getIteration()
    {
    	return this.ite;
    }
    
    //Permet de modifier le bool�en
    public void setDessinRect (boolean dessinRect)
    {
    	this.dessinRect = dessinRect;
    }
    
    //Permet de modifier le point 1
    public void setR1(Point r1)
    {
    	this.r1 = r1;
    }
    
    //Permet de modifier le point 2
    public void setR2(Point r2)
    {
    	this.r2 = r2;
    }
 
    //Permet d'obtenir le point 1
    public Point getR1()
    {
    	return this.r1;
    }
    
    //Permet d'obtenir le point 2
    public Point getR2()
    {
    	return this.r2;
    }
 
    //Permet d'obtenir la forme
    public String getForme()
    {
    	return this.forme;
    }
    
    //Permet de modifier le nombre de la couleur rouge
    public void setRouge(int rouge)
    {
    	this.rouge = rouge;
    }
    
  //Permet de modifier le nombre de la couleur verte
    public void setVert(int vert)
    {
    	this.vert = vert;
    }
    
  //Permet de modifier le nombre de la couleur bleue
    public void setBleu(int bleu)
    {
    	this.bleu = bleu;
    }
}



