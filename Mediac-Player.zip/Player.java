/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.dnd.DropTarget;
import java.io.File;
import java.io.Serializable;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import uk.co.caprica.vlcj.logger.Logger;
import uk.co.caprica.vlcj.component.EmbeddedMediaPlayerComponent;
import uk.co.caprica.vlcj.player.embedded.EmbeddedMediaPlayer;
import uk.co.caprica.vlcj.player.MediaPlayer;
import uk.co.caprica.vlcj.player.MediaPlayerEventAdapter;
import uk.co.caprica.vlcj.player.MediaDetails;
import uk.co.caprica.vlcj.binding.internal.libvlc_media_t;
import uk.co.caprica.vlcj.player.MediaMeta;
import uk.co.caprica.vlcj.player.MediaPlayerFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.Vector;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.filechooser.*;

import mediac.gui.NFrame;
import mediac.gui.MNFrame;
import mediac.gui.MComboBox;

public class Player implements Serializable{

 public static final long serialVersionUID = -12322308831L;
 ScheduledExecutorService controleur = Executors.newSingleThreadScheduledExecutor();
 ScheduledExecutorService hover = Executors.newSingleThreadScheduledExecutor();
 ScheduledExecutorService mixer = Executors.newSingleThreadScheduledExecutor();
 String cropt[] = {"16:10","4:3","16:9","5:4","1:1","1:2","1:4",""};
 
AudioPlayer player;
AudioPlayer[]playerList = null;
MComboBox urlBox;
MNFrame frame;
JPanel panel;
MPanel control;
MPanel listPane;
MPanel icoPanel;
MPanel metaPanel;
MPanel playerPane;
MPanel playersContainer;

JList<Object>  playList;
ArrayList<String> someURL;
ArrayList<String> playerPathList;
ArrayList<String> playerNameList;

MBar mbar;
MSlider slider;
private MPlayerButton play1;
OverVideoPane overVideoPane;
JLabel time1,time2;
JLabel artiste,titre,temps,album,error;

TrayIcon sysIcon;
BufferedImage artworkImage,imgLeft;
JFileChooser choix;
FileFilter filtre;

GraphicsDevice carteGraph;
Timer full_screen_controler;
PlayListStyle playListStyle;
PlayListTransferHandler playListTransferHandler;
PlayListTransferHandler frameTransferHandler;
String playerOption;
SpectrumView animation;
OverPanel optionFrame;
VMenuItem item_lecteur1 = null;
ExternControl externControl;
private final AudioPlayer Xplayer;
final AudioPlayer Yplayer ;
private final MediacPlayer.PlayerPane Xpane;
final MediacPlayer.PlayerPane Ypane;

boolean full = false;
boolean remix = false;
boolean repeat = false;
boolean paused = false;
boolean length = false;
boolean mixing = false;
boolean option = false;
boolean isAudio = false;
boolean listview = true;
boolean recovry = false;
boolean wasAudio = false;
boolean viewControl = false;
boolean comFromEvent = false;
boolean multiPlayerMode = false;
boolean animation_enable = false;
   
int index = 0;
long current = 0;
int cropt_count = 0;
int playerCount = 2;
int remixDelay = 100;
protected int screenWidth = 0;
 
	public Player(){
	try{
		UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		//UIManager.put("nimbusBase",new Color(100,75,255,152));
		//UIManager.put("nimbusBase",Color.WHITE);
		UIManager.put("nimbusBase",new Color(30,30,30,255));
	}
	catch(Exception E){
    try{
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	}
    catch(Exception e) {}
    }
 
    frame = new MNFrame("Mediac Player"){
		@Override
		public void recovry(){
		recovryMode();
		}
	};
	frame.addWindowListener(new WindowAdapter(){
	public void windowClosing(WindowEvent we){
		System.exit(0);
	}
	public void windowOpened(WindowEvent e){
		attach();
		screenWidth = frame.getScreenWidth();
		if(screenWidth < 1024){
			playList.setFont(new Font("arial",Font.PLAIN,10));
			urlBox.setColumns(24);
			
		}
		else if(screenWidth >= 1024 && screenWidth < 1280){
		/****** Situation natve de mediac ***/
		}
		else if(screenWidth >= 1280 && screenWidth < 1500){
			playList.setFont(new Font("arial",Font.BOLD,15));
			urlBox.setColumns(40);
		}
		/** Tres grande resolution **/
		else{
			playList.setFont(new Font("arial",Font.BOLD,18));
			urlBox.setColumns(55);
		}
	
	}
	public void windowIconified(WindowEvent e){
		optionFrame.close();
	}
	
	public void windowDeiconified(WindowEvent e){
		if(screenWidth != frame.getUpdatedScreenWidth()){
				frame.updateDim();
				screenWidth = frame.getScreenWidth();
				if(screenWidth < 1024){
					icoPanel.setPreferredSize(new Dimension(250,120));
					playList.setFont(new Font("arial",Font.PLAIN,10));
					urlBox.setColumns(24);
				}
				else if(screenWidth >= 1024 && screenWidth < 1280){
					/****** Situation natve de mediac ***/
					icoPanel.setPreferredSize(new Dimension(250,200));
				}
				else if(screenWidth >= 1280 && screenWidth < 1500){
					icoPanel.setPreferredSize(new Dimension(250,200));
					playList.setFont(new Font("arial",Font.BOLD,15));
					urlBox.setColumns(40);
				}
				/** Tres grande resolution **/
				else{
					icoPanel.setPreferredSize(new Dimension(250,200));
					playList.setFont(new Font("arial",Font.BOLD,18));
					urlBox.setColumns(55);
				}
			}
	}
	
	});
	
	frame.addComponentListener(new ComponentAdapter(){
		public void componentResized(ComponentEvent e){
			if(screenWidth != frame.getUpdatedScreenWidth()){
				frame.updateDim();
				screenWidth = frame.getScreenWidth();
				if(screenWidth < 1024){
					icoPanel.setPreferredSize(new Dimension(250,120));
					playList.setFont(new Font("arial",Font.PLAIN,10));
					urlBox.setColumns(24);
				}
				else if(screenWidth >= 1024 && screenWidth < 1280){
				/****** Situation natve de mediac ***/
				icoPanel.setPreferredSize(new Dimension(250,200));
				}
				else if(screenWidth >= 1280 && screenWidth < 1500){
					icoPanel.setPreferredSize(new Dimension(250,200));
					playList.setFont(new Font("arial",Font.BOLD,15));
					urlBox.setColumns(40);
				}
				/** Tres grande resolution **/
				else{
					icoPanel.setPreferredSize(new Dimension(250,200));
					playList.setFont(new Font("arial",Font.BOLD,18));
					urlBox.setColumns(55);
				}
			}
		}
	});
	
	playerOption = "";
	
	Xplayer = new AudioPlayer();
	Yplayer = new AudioPlayer();
	Xplayer.setId(0);
	Yplayer.setId(1);
	
	Xplayer.addMediaPlayerEventListener(new MediaEventListener());
	Xplayer.setEnableMouseInputHandling(false);
	Xplayer.setEnableKeyInputHandling(false);
	Xpane = Xplayer.getCanvas();
	Ypane = Yplayer.getCanvas();
	
	player = Xplayer;
	playerPane = new MPanel();
	playerPane.setLayout(new BorderLayout());
	
	playersContainer = new MPanel();
	playersContainer.setLayout(new BorderLayout());
	playersContainer.add("Center",Xpane);
	playerPane.add("Center",playersContainer);
	
	PlayerMouseListener playerMouse = new PlayerMouseListener(player){
	  public void full(){
	  full();
	  }
	};

	Xpane.getPlayerPane().addMouseListener(playerMouse);
	Xpane.getPlayerPane().addMouseMotionListener(playerMouse);
	animation = new SpectrumView(player);
	animation.addMouseListener(playerMouse);
	animation.addMouseMotionListener(playerMouse);
	
	control = new MPanel();
	control.setLayout(new BorderLayout());
	control.setOpaque(false);
	
	panel = frame.getPane();
	panel.setLayout(new BorderLayout());
	
	playListTransferHandler = new PlayListTransferHandler
	(this,System.currentTimeMillis());
	
	frameTransferHandler = new PlayListTransferHandler
	(this,System.currentTimeMillis());
	
	playerPathList = new ArrayList<String>();
	playerNameList = new ArrayList<String>();
	
	externControl = new ExternControl(player);
	
	choix = new JFileChooser();
	choix.setMultiSelectionEnabled(true);
	choix.setSize(500,500);
	choix.setBackground(Color.BLACK);
	
	filtre = new FileNameExtensionFilter("Fichiers Multimedias ",MediaUtil.allExtensions());
	FileNameExtensionFilter filtreVideo = new FileNameExtensionFilter("Fichiers Videos",MediaUtil.extensionsVideos());
	
	FileNameExtensionFilter filtreAudio = new FileNameExtensionFilter("Fichiers Audios",MediaUtil.extensionsAudios());
	
	choix.addChoosableFileFilter(filtre);
	choix.addChoosableFileFilter(filtreAudio);
	choix.addChoosableFileFilter(filtreVideo);
	choix.setFileFilter(filtre);
    initAll();
	
	controleur.scheduleAtFixedRate(new Updater(player), 0L, 1L, TimeUnit.SECONDS);
	hover.scheduleAtFixedRate(playerMouse, 1L, 2L, TimeUnit.SECONDS);
	mixer.scheduleAtFixedRate(new Mixer(), 0L, 1L, TimeUnit.SECONDS);
	
	Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener(){
	@Override
	public void eventDispatched(AWTEvent event){
	if(event instanceof KeyEvent){
	KeyEvent ke = (KeyEvent)event;
	switch(ke.getID()){
		    case KeyEvent.KEY_PRESSED:
			switch(ke.getKeyCode()){
			
					case KeyEvent.VK_SPACE:
					Object source = ke.getSource();
					if(!(source instanceof JTextField)){
						if(!remix){
							pause_play();
						
						}
					}
	                break;
					
					case KeyEvent.VK_UP:
					if(!(ke.getSource() instanceof JList)){
					
					}
					break;
					
					case KeyEvent.VK_DOWN:
					if(!(ke.getSource() instanceof JList)){
					
                    }
					break;
					
					case KeyEvent.VK_RIGHT:
					if(!(ke.getSource() instanceof JTextField))
					next2();
					break;
					
					case KeyEvent.VK_LEFT:
					if(!(ke.getSource() instanceof JTextField))
					prev();
					break;
					
					case KeyEvent.VK_C:
					if(player.isPlaying() && !(ke.getSource() instanceof JList)){
					if(cropt_count == cropt.length)
					cropt_count = 0;
					player.setCropGeometry(cropt[cropt_count]);
					String rg = player.getCropGeometry();
					if(cropt_count == 8)
					player.setMarqueeText("Rognage Par defaut");
					else
					player.setMarqueeText("Rognage : " + rg);
					player.setMarqueeOpacity(100);
					player.setMarqueeColour(Color.WHITE);
					player.setMarqueeTimeout(500);         
					cropt_count++;
					}
					break;
							
					case KeyEvent.VK_ESCAPE:
		            if(full)full();
		            break;
					
					case KeyEvent.VK_N:
					if(!(ke.getSource() instanceof JList) && !(ke.getSource() instanceof JTextField))
					//remixNow();
					player.nextFrame();
					break;
					
					default:
					break;
			}
			break;
			default:
			break;
	}}}},AWTEvent.KEY_EVENT_MASK);
	
	buildActionMap();
	sysIcon();
	player.setVolume(player.getVolume());
    }
	
	void recovryMode(){
	optionFrame.close();
		if(!recovry){
			recovry = true;
			panel.remove(listPane);
			playerPane.remove(mbar);
			panel.updateUI();
		}
		else{
		recovry = false;
		playerPane.add("North",mbar);
		panel.add("West",listPane);
		playList.requestFocus();
		}
	}
	
	 private void sysIcon(){
	 if(SystemTray.isSupported()){
	 sysIcon = new TrayIcon(new ImageIcon("mediac/src/img/i16.png").getImage(),"Mediac Player");
	 PopupMenu popup = new PopupMenu();
	 MenuItem exit = new MenuItem("Quitter");
	 exit.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
	 System.exit(0);
	 }});
	 popup.add(exit);
	 MenuItem aprop = new MenuItem("A propos de Mediac Player");
	 exit.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
	 /****************************auteur*************************************/
	 }});
	 popup.add(aprop);
	 
	 sysIcon.setPopupMenu(popup);
	 SystemTray tray = SystemTray.getSystemTray();
	try{
		tray.add(sysIcon);
	}
	catch(AWTException e){
		sysIcon = null;
		}
	 }
	 else sysIcon = null;
	}
	
	private synchronized void showMessage(final String message,final TrayIcon.MessageType type){
	if(sysIcon != null)
	sysIcon.displayMessage(message,"Mediac Player",type);
	
	}
	
	private void buildActionMap(){
	InputMap map = panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
	
	map.put(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_MASK),"quitter");
	map.put(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK),"ouvrir");
	map.put(KeyStroke.getKeyStroke(KeyEvent.VK_PLUS, InputEvent.CTRL_MASK),"zoom_plus");
	map.put(KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, InputEvent.CTRL_MASK),"zomm_moins");
	
 	panel.getActionMap().put("quitter", new AbstractAction(){
	public void actionPerformed(ActionEvent e){
	System.exit(0);}});
	
	panel.getActionMap().put("ouvrir", new AbstractAction(){
	public void actionPerformed(ActionEvent e){
	load();
	}});
	
	panel.getActionMap().put("zoom_plus", new AbstractAction(){
	public void actionPerformed(ActionEvent e){
	/** zoom_plus **/System.out.println("zoom +++");}});
	
	panel.getActionMap().put("zomm_moins", new AbstractAction(){
	public void actionPerformed(ActionEvent e){
	/** zoom_plus **/System.out.println("zomm ---");}});
	
	}
 
	public static void start(String[]args){
	Player player = new Player();
	for(int i = 0; i < args.length; i++){
		File file = new File(args[i]);
		player.playerPathList.add(player.getWinEncodedPath(file));
		player.playerNameList.add(file.getName());
	}
	
	player.playList.setListData(player.playerNameList.toArray());
	player.listPane.updateUI();
	player.play();
	}
	
  public static void main(String[]args){
	if(args.length < 0)
		new Player();
	else 
		start(args);
  }
 
    public void initAll(){
    MPanel slidContainer = new MPanel();
	slidContainer.setOpaque(false);
    //MPanel buttonContainer = new MPanel();
	//buttonContainer.setOpaque(false);
	slidContainer.setLayout(new BorderLayout());
  
   Font fl = new Font("Arial",Font.BOLD,10);
   time1 = new JLabel("\t \t00:00:00\t \t");
   time2 = new JLabel(" \t \t00:00:00\t\t");
  
  time1.setFont(fl);
  time2.setFont(fl);
  
  time1.setForeground(Color.WHITE);
  time2.setForeground(Color.WHITE);
  
     play1 = new MPlayerButton(MPlayerButton.BUTTON_PLAY,48,48);
     play1.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
		 if(playerPathList.size() != 0){
			if(remix)remixNow();
				pause_play();
			if(!player.isPlayable()){
				index = 0;
				play();
			}
		 }
		 else{
			load();
		 }
	 }});
	 
     MPlayerButton play2 = new MPlayerButton(MPlayerButton.BUTTON_STOP,42,42);
     play2.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
	 if(player.isPlayable()){
	 player.stop();
	 if(remix) remixNow();
	 }
	 }});
	 
       MPlayerButton play4 = new MPlayerButton(MPlayerButton.BUTTON_LIST,42,42);
       play4.addActionListener(new ActionListener(){
	   public void actionPerformed(ActionEvent e){
	   if(!recovry){
			if(listview){
				panel.remove(listPane);
				listview = false;
				panel.updateUI();
			}
			else{
				panel.add("West",listPane);
				listview = true;
				panel.updateUI();
			}
	   }
	   }});
	   
     final MPlayerButton play5 = new MPlayerButton(MPlayerButton.BUTTON_OPEN,42,42);
     play5.addActionListener(new ActionListener(){
		 public void actionPerformed(ActionEvent e){
			if(optionFrame.isVisible()){
				optionFrame.close();
			}else{
				int width = control.getWidth();
				int height = control.getHeight();
				Point p = control.getLocationOnScreen();
				int x = p.x;
				int y = p.y + 57;
				optionFrame.setSize(new Dimension(width,20));
				optionFrame.setLocation(x,y);
				optionFrame.open();
			}
		 }
	 });
	 
     MPlayerButton play6 = new MPlayerButton(MPlayerButton.BUTTON_PREV,42,42);
     play6.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
	 prev();
	 }});
	 
     MPlayerButton play7 = new MPlayerButton(MPlayerButton.BUTTON_NEXT,42,42);
     play7.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
	 next2();
	 }});
  
    JPopupMenu popup = new JPopupMenu();
  
    MPlayerButton play8 = new MPlayerButton(MPlayerButton.BUTTON_FULL,42,42);
    play8.addActionListener(new ActionListener(){
	 public void actionPerformed(ActionEvent e){
	 load();
	 }});
  
      slider = new MSlider();
      slider.setMaximum(1000);
	  slider.setMinimum(0);
	  slider.setValue(0);
	  
	      slidContainer.add("North",new JLabel(" "));
		  slidContainer.add("Center",slider);
	      slidContainer.add("West",time1);
	      slidContainer.add("East",time2);
		  slidContainer.add("South",new JLabel(" "));
		  
		  MPanel sub_buttonContainer = new MPanel();
		  
		  sub_buttonContainer.setLayout(new FlowLayout(FlowLayout.CENTER,2,2));
		  sub_buttonContainer.add(play4);
          sub_buttonContainer.add(play2);
		  sub_buttonContainer.add(play6);
		  sub_buttonContainer.add(play1);
		  sub_buttonContainer.add(play7);
          sub_buttonContainer.add(play8);
		  sub_buttonContainer.add(play5);
		 
	//buttonContainer.add(sub_buttonContainer);/////////////////////////////////////
          
	MPanel subControl = new MPanel();
	subControl.setLayout(new BoxLayout(subControl,BoxLayout.Y_AXIS));
	subControl.setOpaque(false);
	
	subControl.add(sub_buttonContainer);
	MPanel volPanel = new MPanel();
	
	JLabel labVol = new JLabel(new ImageIcon("vol.png"));
	
    listPane = new MPanel();
	listPane.setLayout(new BorderLayout());
	
	playList = new JList<Object>();
	playList.setOpaque(false);
	//playList.setBorder(BorderFactory.createTitledBorder("Play list"));
	playList.setForeground(new Color(100,100,100));
	playList.setDragEnabled(true);
	playList.setTransferHandler(playListTransferHandler);
	panel.setTransferHandler(playListTransferHandler);
  
  playListStyle = new PlayListStyle();
  playList.setCellRenderer(playListStyle);
  JScrollPane scrollPane = new JScrollPane(playList);
  scrollPane.setBorder(BorderFactory.createTitledBorder("Play List"));
  scrollPane.setOpaque(false);
  scrollPane.setViewportBorder(null);
  scrollPane.getViewport().setOpaque(false);
  //playList.setListData(playerNameList.toArray());
    metaPanel = new MPanel();
  
   MPanel meta = new MPanel();
  meta.setLayout(new GridLayout(6,1));
  metaPanel.setLayout(new BorderLayout());
  
  artiste = new JLabel("    Artiste : ");
  artiste.setForeground(Color.WHITE);
  album = new JLabel("    Album : ");
  album.setForeground(Color.WHITE);
  titre = new JLabel("    Genre : ");
  titre.setForeground(Color.WHITE);
  temps = new JLabel("    Dur�e : ");
  temps.setForeground(Color.WHITE);
  
  error = new JLabel("");
  error.setForeground(Color.RED);
  
  
	try{
		imgLeft = ImageIO.read(new File("imgLeft.png"));
	}catch(Exception e){}
	
	artworkImage = imgLeft;
   
	icoPanel = new MPanel(){
		public void paintComponent(Graphics g){
			Graphics2D g2d = (Graphics2D) g;
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			if(artworkImage != null){
				g2d.drawImage(artworkImage, 0, 0, getWidth(), getHeight(), null);
			}
		}
	};
	
	JButton playAudioCD = new JButton("Lire / Ripper un CD audio",new ImageIcon("au.png"));
	JButton ripAudioCD = new JButton("Lire un CD/DVD/BR video",new ImageIcon("vid.png"));
	icoPanel.setLayout(new BoxLayout(icoPanel,BoxLayout.Y_AXIS));
	icoPanel.add(playAudioCD);
	icoPanel.add(ripAudioCD);
	
	meta.add(error);
    meta.add(artiste);
    meta.add(album);
    meta.add(titre);
    meta.add(temps);
	
	someURL = new ArrayList<String>();
	someURL.add("http://www.mediac-player.com/howto.flv");
	someURL.add("https://www.example.com/videos/xyz.mp4");
	urlBox = new MComboBox(someURL,30){
	public void go(String url){
	if(!someURL.contains(url))
		someURL.add(url);
		addURL(url);
	}};
	
	
	urlBox.setBackground(Color.BLACK);
	urlBox.getTextField().setBackground(Color.BLACK);
	urlBox.getTextField().setForeground(new Color(100,100,100));
	urlBox.setText("https://www.example.com/videos/0001.mp4");
	urlBox.popupContainer().setBackground(new Color(50,50,50));
	
	optionFrame = new OverPanel(this);
	
	metaPanel.add("North",urlBox);
    metaPanel.add("Center",icoPanel);
    metaPanel.add("South",meta);
	
   listPane.add("Center",scrollPane);
   listPane.add("South",metaPanel);
   
   javax.swing.border.TitledBorder border = BorderFactory.createTitledBorder("'");
   control.setBorder(border);
   control.add("North",slidContainer);
   control.add("Center",subControl);
   
   playerPane.add("South",control);
   
   //optionFrame.setInvoker(subControl);
   
   /*********************************** MENU AND MENUITEM************************/
   /*********************************** MENU AND MENUITEM************************/
   /*********************************** MENU AND MENUITEM************************/
   mbar = new MBar(frame);
   
   VMenu fichier = new VMenu("Fichier",mbar);
   VMenu lecteur = new VMenu("Lecteur",mbar);
   VMenu aide = new VMenu("Aide",mbar);
   
   VMenuItem item_fichier1 = new VMenuItem("Ouvrir"){
		public void click(){
			load();
		}
   };
   
   VMenuItem item_fichier2 = new VMenuItem("Quitter"){
		public void click(){
			System.exit(0);
		}
   };
   fichier.addItem(item_fichier1);
   fichier.addItem(item_fichier2);
   
   item_lecteur1 = new VMenuItem("Activer la repetition"){
		public void click(){
			setRepeat();
			if(repeat)
				item_lecteur1.setText("Desactiver la repetition");
			else
				item_lecteur1.setText("Activer la repetition");
		}
   };
   
   VMenuItem item_lecteur2 = new VMenuItem("Reinitialiser l'egaliseur"){
		public void click(){
			externControl.reset();
		}
   };
   
   VMenuItem item_lecteur3 = new VMenuItem("Ouvrir l'egaliseur"){
		public void click(){
			externControl.show();
		}
   };
   
   lecteur.addItem(item_lecteur1);
   lecteur.addItem(item_lecteur2);
   lecteur.addItem(item_lecteur3);
   
   VMenuItem item_aide1 = new VMenuItem("A Propos"){
		public void click(){
			Utiler.showHelpFrame();
		}
   };
   VMenuItem item_aide2 = new VMenuItem("Auteur"){
		public void click(){
			Utiler.showHelpFrame();
		}
   };
   aide.addItem(item_aide1);
   aide.addItem(item_aide2);
   
   mbar.addMenu(fichier);
   mbar.addMenu(lecteur);
   mbar.addMenu(aide);
   
   /*********************************** END MENU AND MENUITEM************************/
   playerPane.add("North",mbar);
   
   panel.add("West",listPane);
   panel.add("Center",playerPane);
   processListener();
   overVideoPane = new OverVideoPane(this);
   frame.setVisible(true);
  }
  
	public void stopVisualiser(){
		player.stopVisualiser();
	}
  
  public int getNewPlayingIndex(String path){
  int i = playerPathList.indexOf(path);
  if(i != -1)
	return i;
  else
	return 0;
  }
  
  public synchronized void setRepeat(){
  repeat = (repeat)?false:true;
  }
  
  public void addURL(String url){
  playerOption = "sout=#transcode{acodec=mp3,channels=2,ab=192,samplerate=44100,vcodec=dummy}:standard{dst=" + "D:\\Mint\\Dev\\mediac 1.0\\rip\\rip.mp3" + ",mux=raw,access=file}";
  if(!playerPathList.contains(url)){
    option = true;
    playerPathList.add(url);
    playerNameList.add(url);
    playList.setListData(playerNameList.toArray());
	listPane.updateUI();
    index = playerPathList.size() - 1;
    play();
  }
    else{
	  option = true;
      index = playerPathList.indexOf(url);
      play();
      }
  }
    private class MediaEventListener extends MediaPlayerEventAdapter{
	
	    @Override
        public void mediaChanged(MediaPlayer player, libvlc_media_t media, String mrl){
        
        }

        @Override
        public void finished(MediaPlayer player){
		 artworkImage = imgLeft;//icone.setImage(img);
		 icoPanel.repaint();
         slider.setValue(0);
		 //slider.setMaximum(1);
		 length = false;
		 updateLabels();
		 frame.setTitleLabel("Mediac Player");
		 frame.setTitle("Mediac Player");
		 next();
        }

        @Override
        public void paused(MediaPlayer player) {
		play1.setPause(false);
        }

        @Override
        public void playing(MediaPlayer player){
			play1.setPause(true);
            MediaDetails mediaDetails = player.getMediaDetails();
            MediaMeta meta = player.getMediaMeta();
			String temp = ((meta.getArtist()!= null)?meta.getArtist():"--Inconnu");
			artiste.setText("    Artiste : "+((temp.length() < 50)?temp:temp.substring(0,46)+"..."));
			temp = ((meta.getAlbum() != null)?meta.getAlbum():"--Inconnu");
			album.setText("    Album : "+((temp.length() < 50)?temp:temp.substring(0,46)+"..."));
			temp = ((meta.getGenre() != null)?meta.getGenre():"--Inconnu");
			titre.setText("    Genre : "+((temp.length() < 50)?temp:temp.substring(0,46)+"..."));
	        
			frame.setTitleLabel("" + playerNameList.get(index));
		    frame.setTitle("Mediac Player - " + playerNameList.get(index));
			 if(meta.getArtwork() != null){
			   artworkImage = meta.getArtwork();//icone.setImage(meta.getArtwork());
			   icoPanel.repaint();
			   }
			   else{
			     artworkImage = imgLeft;//icone.setImage(img);
				 icoPanel.repaint();
			    }
        }

        @Override
        public void stopped(MediaPlayer player) {
         artworkImage = imgLeft;
		 icoPanel.repaint();
         slider.setValue(0);
		 length = false;
		 updateLabels();
		 frame.setTitleLabel("Mediac Player");
		 frame.setTitle("Mediac Player");
		 if(full) full();
		 
		 if(animation.isRunning() && !multiPlayerMode ){
	    //animation.stop();
	    //playersContainer.remove(animation);
	    //playersContainer.add("Center",Xpane);
		//stopVisualiser();
	    //attach();
         }
		
		 play1.setPause(false);
        }
	
        @Override
        public void videoOutput(MediaPlayer player, int newCount) {
            if(newCount == 0) {
                return;
            }
			 
		     File logo = new File("mediac/src/image/i48.png");
             if(logo.exists()) {
             player.setLogoFile(logo.getAbsolutePath());
             player.setLogoOpacity(0.5f);
             player.setLogoLocation(10, 10);
             player.enableLogo(true);
             }
            player.setMarqueeText("Mediac !!! Par NKOT YOGO GUY THOMAS");
            player.setMarqueeOpacity(100);
            player.setMarqueeColour(Color.white);
            player.setMarqueeTimeout(3000);
            player.setMarqueeLocation(50, 50);
            player.enableMarquee(true);
			cropt[8] = player.getCropGeometry();
	    }
		
		 @Override
        public void error(MediaPlayer player){
		mixing = false;
		error.setText("    Erreur pendant la lecture de la source ");
		showMessage("Erreur pendant la lecture",TrayIcon.MessageType.ERROR);
        }

        @Override
        public void mediaSubItemAdded(MediaPlayer player, libvlc_media_t subItem) {            
        }

        @Override
        public void mediaDurationChanged(MediaPlayer player, long newDuration) {            
        }

        @Override
        public void mediaParsedChanged(MediaPlayer player, int newStatus) { 
        }

        @Override
        public void mediaFreed(MediaPlayer player) {            
        }

        @Override
        public void mediaStateChanged(MediaPlayer player, int newState) {           
        }

        @Override
        public void mediaMetaChanged(MediaPlayer player, int metaType) {           
        }
	}

	public void processListener(){
	 playList.addMouseListener(new MouseAdapter(){
	  public void mouseCliked(MouseEvent e){
	   if(e.getClickCount() == 2){
			int i = playList.locationToIndex(e.getPoint());
			if(i != -1){
				index = i;
				play();
			}
       }
	 }
	 public void mousePressed(MouseEvent e){
	  if(e.getClickCount() == 2){
			int i = playList.locationToIndex(e.getPoint());
			if(i != -1){
				index = i;
				play();
			}
			
      }
	 }
	 
	 public void mouseReleased(MouseEvent e){
	   //if(e.isPopupTrigger()){
	   //int i = playList.locationToIndex(e.getPoint());
			
			//ExternControl.show(player);/**** POPUP PLAY LIST HANDLER  *******/
			//}
			
	   //}
	 }});
	  
	  slider.addMouseListener(new MouseAdapter(){
            @Override
            public void mousePressed(MouseEvent e) {
				if(player.isPlayable() && player.isSeekable()){
				 int xn = e.getX();
				 long time = xn*slider.getMaximum()/slider.getWidth();
				 time = (time == 0)?1:time;
					player.setTime(time);
					slider.setValue(time);
				}
				 else{
				 slider.setValue(0);
				 }
            }
			
			  public void mouseReleased(MouseEvent e){
			    if(player.isPlayable() && player.isSeekable()){
				 long time = slider.getValue();
				    player.setTime(time);
				}
				  else{
				  slider.setValue(0);
				 }
			}
			public void mouseEntered(MouseEvent e){
	        slider.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
	        }

            public void mouseExited(MouseEvent e){
	        slider.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	        }	
        });
	    
		   playList.addKeyListener(new KeyAdapter(){
		   public void keyPressed(KeyEvent e){
		   if(e.getKeyCode() == KeyEvent.VK_DELETE)
		   delete();
		   if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
		   delete();
		   }});
	 }
	 
	public void delete(){
	int [] selection =  playList.getSelectedIndices();
	int lastIndex = selection.length - 1;
	int n = lastIndex;
	while(n > -1){
		if(selection[n] == index){
			player.stop();
			index = 0;
		}
		playerPathList.remove(selection[n]);
		playerNameList.remove(selection[n]);
		n--;
	}
	if(index != 0 && (selection[lastIndex] < index)){
		index = index - selection.length;
	}
	playList.setListData(playerNameList.toArray());
	listPane.updateUI();
	}
	
	public void attach(){
	player.attach();
	}
	
	public void sleep(long time){
	try{
		Thread.sleep(time);
	}
	catch(Exception ex){}
	}
	
	public void play(){
	if(player.isPlaying())
		player.stop();
	if(wasAudio()){
	   animation.stop();
	   player.setAudioMode(false);
	   player.setAnimMode(false);
	   //playersContainer.remove(animation);
	   //playersContainer.add("Center",Xpane);
	   //player.stopVisualiser();
	   //attach();
    }
	 error.setText("");
	   slider.setValue(0);
	   
	     if(playerPathList.size() > 0){
			if(option){
			player.play(playerPathList.get(index),playerOption);
			playList.setSelectedIndex(index);
			option = false;
			}
			else{
	         player.play(playerPathList.get(index));
		     playList.setSelectedIndex(index);
			}
		  }
		 
		  if(isAudio() &&  !multiPlayerMode){
	      //playersContainer.remove(Xpane);
		  if(animation_enable){
			//player.resumeVisualiser();
			//playersContainer.add("Center",animation);
			//animation.start();
		  }
	      
		  player.setAudioMode(true);
		  player.setAnimMode(animation_enable);
		  wasAudio = true;
          }
		  else wasAudio = false;
			slider.setEnabled(true);
			play1.setEnabled(true);
	}
	
	public void updateLabelTime(long millis){
	String time = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis), TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)), TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
	time1.setText("\t\t\t\t "+time+" ");
	}
	
	public void updateLength(long millis){
	slider.setMaximum(millis);
	String time = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis), TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)), TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
	temps.setText("    Dur�e : " + time);
	time2.setText("\t\t\t\t "+time+" ");
	}
	
	public void updatePosition(long pos){
	slider.setValue(pos);
	}
	
	public boolean isAudio(){
	if(playerPathList.size() == 0)
	return false;
	isAudio = false;
	int type = MediaUtil.getType(playerPathList.get(index));
	isAudio = (type == 0)?true:false;
	
	return isAudio;
	}
	
	public boolean wasAudio(){
	return wasAudio;
	}
	
	private class Updater implements Runnable{
	AudioPlayer player;
	int duration = 0;
	public Updater(AudioPlayer player){
	 this.player = player;
	}
	  @Override
            public void run() {
			if(!player.isSeekable()) return;
            final long time = player.getTime();
            
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run(){
                    if(player.isPlaying()) {
					   updateLabelTime(time);
                        updatePosition(time);
						if(!length && !mixing){
							updateLength(player.getLength());
							length = true;
					     }
						 else if(mixing && !length){ 
							updateLength(player.getLength());
						 }
                    }
                }
            });
        }
	}
	
	public void updateLabels(){
	updateLabelTime(0);
	updateLength(0);
	artiste.setText("    Artiste : ");
    album.setText("    Album : ");
    titre.setText("    Genre : ");
    temps.setText("    Dur�e : ");
	}
	
	public void next(){
	if(!repeat){
		if(playerPathList.size() > (index + 1)){
			index++;
			play();
	    }
		else{
			index = 0;
			play();
		}
	}
	else{
		if(playerPathList.size() > index){
			play();
	    }
		else{
			index = 0;
			play();
		}
	
	}
	}
	
	public void next2(){
		if(playerPathList.size() > (index + 1)){
			index++;
			play();
	    }
		else{
			index = 0;
			play();
		}
	}
	
	public void stream(){
	play();
	}
	
	public void pause_play(){
	if(player.canPause())
		player.pause();
		paused = (paused)?false:true;
	  //play1.setPause(paused);
	if(animation.isRunning())
	  animation.pause(paused);
	}
	
	public void nextIndex(){
	    if(playerPathList.size() > (index + 1)){
	      index++;
	    }
		else{
		 index = 0;
		}
	}
	
	public void prev(){
		if(playerPathList.size() > 0){
			if(index > 0)
				index--;
			else index = playerPathList.size()-1;
				play();
		}
	}
	
	public void requestFocus(){
	Xpane.requestFocus();
	}
	void closePopupMenu(){
	mbar.closePopupMenu();
	}
	
	/** Tres important **/
	public String getWinEncodedPath(File file){
	if(file == null) return null;
		String ascii = file.toURI().toASCIIString().substring(6);
		StringBuilder builder = new StringBuilder();
		for(int j = 0; j < ascii.length(); j++){
			if(ascii.charAt(j) == '/'){
				char ch = (char)'\\';
				builder.append(ch);
		    }
		    else{
				builder.append(ascii.charAt(j));
		    }
		}
		if(builder.toString().startsWith("\\"))
			return "file:///" + builder.toString().substring(1);
		else
			return "file:///"+builder.toString();
	}
	
	public void load(){
		choix.setSize(500,300);
		int val = choix.showOpenDialog(null);
		if(val == JFileChooser.APPROVE_OPTION){
			File[] rec = choix.getSelectedFiles();
			for(int i = 0; i < rec.length; i++){
			playerPathList.add(getWinEncodedPath(rec[i]));
			playerNameList.add(rec[i].getName());
			}
			playList.setListData(playerNameList.toArray());
			listPane.updateUI();
		}
	}
	/*********************8 FULL SCREEN HANDLER *********************************************************/
	public void full(){
	if(!recovry){
		if(full){
			playerPane.add("North",mbar);
			playerPane.add("South",control);
			panel.add("West",listPane);
			frame.full(false);
			full = false;
		}
		else{
			playerPane.remove(control);
			playerPane.remove(mbar);
			panel.remove(listPane);
			frame.full(true);
			full = true;
		}
	}
	}
	
private class PlayerMouseListener implements MouseMotionListener,Runnable,MouseListener{

 AudioPlayer player;
 protected boolean hover;
 protected boolean time_hover_exeded;
 protected long current = 0;
 
 public PlayerMouseListener(AudioPlayer incplayer){
  this.player = incplayer;
  hover = false;
  time_hover_exeded = false;
   }
 
    public void mouseEntered(MouseEvent e){
    current = System.currentTimeMillis();
	hover = true;
	if(this.player.getId() == -1)
	this.player.showInternalControl();
    }
	
	public void mouseExited(MouseEvent e){
	current = 0;
	hover = false;
	time_hover_exeded = false;
	defaultCursor();
	if(this.player.getId() == -1)
	this.player.hideInternalControl();
	}
	
	public void mousePressed(MouseEvent e){
	defaultCursor();
	if(e.getClickCount() == 2){
	   if(this.player.isPlayable())
	   full();
	   }
	current = System.currentTimeMillis();
	hover = true;
	
	}
	
	public void mouseClicked(MouseEvent e){
	   defaultCursor();
	   current = System.currentTimeMillis();
	   hover = true;
	}
    
	public void mouseReleased(MouseEvent e){
	defaultCursor();
	current = System.currentTimeMillis();
	hover = true;
	if(e.isPopupTrigger() && this.player.getId() == -1){
			this.player.muteIf();
		//int i = playList.locationToIndex(e.getPoint());
			
	}
	}
	
	public void mouseDragged(MouseEvent e){
	 defaultCursor();
	 current = System.currentTimeMillis();
	 hover = true;
	}
	
	public void mouseMoved(MouseEvent e){
	defaultCursor();
	current = System.currentTimeMillis();
	hover = true;
	if(full)
	setControl(true);
	 
	}
	
	void defaultCursor(){
	this.player.getCanvas().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	if(isAudio())
	animation.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
	
	void hideCursor(){
	Image blankImage = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
    this.player.getCanvas().setCursor(Toolkit.getDefaultToolkit().createCustomCursor(blankImage, new Point(0, 0), ""));
	if(isAudio())
	animation.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(blankImage, new Point(0, 0), ""));
	}
	
	public void run(){
	    if(hover){
	    long time = System.currentTimeMillis();
	    if(((time - current) / 1000) >= 2)
	    time_hover_exeded = true;
	    if(time_hover_exeded){
        hideCursor();
		if(full && viewControl){
		setControl(false);
		}
         }}
    }
  }
  
	private synchronized void setControl(boolean view){
		if(view){
			playerPane.add("South",control);
			panel.updateUI();
			viewControl = true;
		}
		else{
			playerPane.remove(control);
			panel.updateUI();
			viewControl = false;
			optionFrame.close();
		}
	}
  
	public int getVolume(){
		return player.getVolume();
	}
	private class Mixer implements Runnable {
		
		private boolean started = false;
		private long current = 0;
		public Mixer(){
			
		}
			
		public void run(){
			if(mixing && player.isPlaying()){
				long time = player.getLength();
				long current = player.getTime();
				long diff = (time - current)/1000;
				if(diff <= 40 && diff > 10){
					if(!started){
					 start_next_mix();
					 started = true;
					 current = System.currentTimeMillis();
					 }
				}
			    else if(diff <= 10){
				  if(started){
					started = false;
					stop_old_mix();
				  }
				}
				else if((diff > 40) && started){
					started = false;
					Yplayer.stop();
					//icoPanel.removeAll();
					overVideoPane.close();
				}
			    
			}
		}
			
			public void start_next_mix(){
				if(playerPathList.size() > (index + 1)){
				 index++;
				}
				 else{
				 index = 0;
				 }
				 startRelayer();
			}
			
			public void startRelayer(){
			int vol = player.getVolume();
			//icoPanel.add("Center",Ypane);
			overVideoPane.open();
			overVideoPane.setIsInAction(true);
            Yplayer.attach();
			Yplayer.play(playerPathList.get(index));
			Yplayer.setVolume(player.getVolume());
			overVideoPane.activeTransition();
			
			}
			
			public void stop_old_mix(){
			
			  int vol = player.getVolume(); 
			  player.setVolume(0);
			  player.play(playerPathList.get(index));
			  player.setTime(Yplayer.getTime()+1000);
			  player.setVolume(vol);
			  //Yplayer.setVolume(0);
			  //Yplayer.setVolume(0);
			  player.stop();
			  Yplayer.setVolume(player.getVolume());
			  overVideoPane.stopTransition();
			   
			  //overVideoPane.close();
			  //icoPanel.removeAll();
			  length = false;
			}
		}
	
	void enableUniquePlayer(){
	if(!multiPlayerMode)return;
	int index = this.index;
	for(int it = 0 ; it < playerList.length; it++){
		playerList[it].stop();
		playerList[it] = null;
	}
	playerList = null;
	player.stop();
	playersContainer.removeAll();
	multiPlayerMode = false;
	playersContainer.setLayout(new BorderLayout());
	playersContainer.add("Center",Xpane);
	attach();
	this.index = index;
	play();
	}
	
	public void addPlayer(int playerCount){
	if(playerPathList.size() == 0)
		return;
	if(playerCount == 1)
	enableUniquePlayer();
	
	if(playerCount != 2 && playerCount != 3 && playerCount != 4)
	return;
	int i = 0;
	int j = 0;
	int index = this.index;
	switch(playerCount){
		case 2:
			i = 2;
			j = 1;
			break;
		
		case 4:
			i = 2;
			j = 2;
			break;
		
		case 3:
			i = 3;
			j = 1;
			break;
	}
	
	playerCount = playerCount - 1;
	if(!multiPlayerMode)
	playerList = new AudioPlayer[playerCount];
	else{
		for(int it = 0 ; it < playerList.length; it++){
		playerList[it].stop();
		playerList[it] = null;
		}
	}
	
	player.stop();
	playersContainer.removeAll();
	playersContainer.setLayout(new GridLayout(i,j));
	playersContainer.add(Xpane);
	
	playerList = new AudioPlayer[playerCount];
	for(int k = 0; k < playerCount; k++){
	AudioPlayer newPlayer = new AudioPlayer();
	newPlayer.setEnableMouseInputHandling(false);
	newPlayer.setEnableKeyInputHandling(false);
	newPlayer.setCropGeometry(cropt[2]);
	
	PlayerMouseListener mouseListener = new PlayerMouseListener(newPlayer);
	playerList[k] = newPlayer;
	newPlayer.setId(-1);
	newPlayer.setNum(k);
	newPlayer.getCanvas().getPlayerPane().addMouseListener(mouseListener);
	newPlayer.getCanvas().getPlayerPane().addMouseMotionListener(mouseListener);
	hover.scheduleAtFixedRate(mouseListener, 1L, 2L, TimeUnit.SECONDS);
	
	playersContainer.add(newPlayer.getCanvas());
	newPlayer.attach();
	}
	
	player.attach();
	this.index = index;
	player.play(playerPathList.get(index),playerOption);
	multiPlayerMode = true;
	}
	
	public void remixNow(){
		if(remix){
			remix = false;
			slider.setEnabled(true);
			play1.setEnabled(true);
		}
		else{
			remix = true;
			slider.setEnabled(false);
			play1.setEnabled(false);
		}
		player.remixNow(remixDelay);
		
	}
}