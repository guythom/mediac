
public class Julia {
	
	//Repr�sente le nombre de fois que l'on rep�te la formule de Mandelbrot
	public int iteration;
	//Cr�ation d'un matrice : axe abscisse - ordonn�e
    public int[][] axe;
   //Repr�sente la largeur et la hauteur maximale que la fen�tre aura
    public int lwin;
   	public int hwin;
    //Repr�sente les abscisses max et min et ordonn�es max et min que l'on peut avoir
    private double ymax,ymin,xmin,xmax;
    //Repr�sente la partie r�elle et imaginaire d'un complexe
    private double ca, cb;
    
    public Julia(){
       
    	//Initialisation des variables
    	 hwin=710;
         lwin=710;
         axe = new int[lwin][hwin];
         ymax=2;
         ymin=-2;
         xmin=-2;
         xmax=2;
               
    }
   
	public void calcul(){
        //Va contenir les valeurs qui vont permettre de cr�er le fractal
		int n;
        /*Parcours de l'hauteur et de la largeur de la fen�tre pour fixer les valeurs dans 
        la matrice axe gr�ce � la formule de Mandelbrot*/
        
		
		for(int i=0;i<hwin;i++)
        {
            for(int j=0;j<lwin;j++)
            {
                
            	
            	//D�but de formule de Julia
            	Complexe z = new Complexe((i*(xmax-xmin)/(double)(hwin) + xmin),(ymax -j*(ymax-ymin)/(double)(lwin)));
            	Complexe c = new Complexe(ca,cb);
                n=0;
                /*Tant que le nombre d'it�ration est sup�rieur � n et la norme du complexe z
                est inf�rieur � 4, on incr�mente n et on place dans le complexe z
                la valeur de la somme du complexe c et le carr� du complexe z */
               //System.out.println(z.norme2());
                while((n<iteration) && (z.norme2()<4))
                {
                    n++;
                    //Fin de formule de Mandelbrot
                    z=(z.carre()).somme(c);
                }
                /*On stocke dans la matrice axe les valeurs de n si elles sont inf�rieures
                 � celle de l'it�ration ou sinon on fixe 0 � la matrice axe */
               if(n<iteration)
                    axe[i][j]=n;
                else
                    axe[i][j]=0;
            }
        }
    
    }
	
	//Permet de modifier l'attribut it�ration
	 public void setIteration(int it)
	    {
	    	this.iteration = it;
	    }
	 
	 //Permet de modifier les attributs ca et cb
	 public void setCaCb(double ca, double cb)
	    {
	    	this.ca = ca;
	    	this.cb = cb;
	    }
}


