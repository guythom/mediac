/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;

public class InternalButton extends JButton{
  public static final long serialVersionUID = 21233102233L;
  
    public static final int BUTTON_PLAY = 1;
      public static final int BUTTON_PAUSE = 2;
	    public static final int BUTTON_STOP = 3;
	      public static final int BUTTON_PLUS = 4;
	        public static final int BUTTON_MOIN = 5;
		      public static final int BUTTON_MUTE = 6;
			    public static final int BUTTON_PREV = 7;
				 public static final int BUTTON_NEXT = 8;
			  
			    protected int BUTTON_TYPE;
             protected boolean hover;
           protected boolean click;
         protected boolean enable;
       protected int width = 0;
	  protected int height = 0;
	  
	  int px = 0;
	  int py = 0;
	  
	BufferedImage[] icones;
	BufferedImage[] ticones;
	  
  public InternalButton(int BUTTON_TYPE,int w,int h){
  
   super();
   setBorderPainted(false);
   setBorder(null);
   hover = false;
    click = false;
      enable = true;
       this.BUTTON_TYPE = BUTTON_TYPE;
         setPreferredSize(new Dimension(w,h));
           icones = new BufferedImage[4];
		   ticones = new BufferedImage[2];
		     processIcones(BUTTON_TYPE);
			 
             px = icones[0].getWidth();
			 py = icones[0].getHeight();
			 
   addMouseListener(new MouseAdapter(){
   public void mouseEntered(MouseEvent e){
   
    //setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	hover = true;
	repaint();
	}
	
	public void mouseExited(MouseEvent e){
	//setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	hover = false;
	repaint();
	}
	
	public void mouseClicked(MouseEvent e){
	//RAS
	}
	
	
	public void mousePressed(MouseEvent e){
	     
	}
	
	public void mouseReleased(MouseEvent e){
	
	// RAS
	 }});
	 //setOpaque(false);
   }
   
   public void setPause(boolean state){
	   if(state){
	    icones[0] = ticones[0];
	    icones[1] = ticones[1];
	    setToolTipText("Pause");
	    repaint();
	    }
		else{
		icones[0] = icones[2];
		icones[1] = icones[3];
		setToolTipText("Jouer");
		repaint();
		}
	}
   @Override
	public boolean contains(int x, int y){
		Ellipse2D el = new Ellipse2D.Double(0, 0, px,py);
		return el.contains(x, y);
	}
   
   @Override
   public void paintComponent(Graphics g){
    Graphics2D g2d = (Graphics2D)g;
	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
	g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
		if(enable){
		g2d.setComposite(AlphaComposite.SrcOver.derive(0.4f));
	    g2d.drawImage(icones[0],width/4,height/3,this);
		}
		else{
		g2d.setComposite(AlphaComposite.SrcOver.derive(0.1f));
	    g2d.drawImage(icones[0],width/4,height/3,this);
		}
	       if(hover && enable){
		    //g2d.setComposite(AlphaComposite.SrcOver.derive(0.4f));
			g2d.drawImage(icones[1],width/4,height/3,this); 
	        }
	      else if(click && (BUTTON_TYPE == BUTTON_PLAY || BUTTON_TYPE == BUTTON_PAUSE || BUTTON_TYPE == BUTTON_MUTE) && enable){
	        //g2d.setComposite(AlphaComposite.SrcOver.derive(0.4f));
			g2d.drawImage(icones[1],width/4,height/3,this);
	       }
	g2d.dispose();
	g.dispose();
   }
   
   public void set(boolean state){
    if(state){
	 enable = true;
	 repaint();
	 }
	  else{
	   enable = false;
	   repaint();
	   }
    }
	
   public void focus(boolean focus){
	click = focus;
	repaint();
	 }
	
 public void processIcones(int BUTTON_TYPE){
 
 try{
  switch(BUTTON_TYPE){
		      case BUTTON_PLAY:
			  icones[0] = ImageIO.read(new File("ip1.png"));
			  icones[1] = ImageIO.read(new File("ip2.png"));
			  icones[2] = ImageIO.read(new File("ip1.png"));
			  icones[3] = ImageIO.read(new File("ip2.png"));
			  ticones[0] = ImageIO.read(new File("ipa1.png"));
			  ticones[1] = ImageIO.read(new File("ipa2.png"));
			  setToolTipText("Lecture");
			  break;
			  
			  case BUTTON_PAUSE:
			  icones[0] = ImageIO.read(new File("ipa1.png"));
			  icones[1] = ImageIO.read(new File("ipa2.png"));
			  setToolTipText("Pause");
			  break;
			  
			  case BUTTON_STOP:
			  icones[0] = ImageIO.read(new File("is1.png"));
			  icones[1] = ImageIO.read(new File("is2.png"));
			  setToolTipText("Stopper");
			  break;
			  
			  case BUTTON_PLUS:
			  icones[0] = ImageIO.read(new File("vp1.png"));
			  icones[1] = ImageIO.read(new File("vp2.png"));
			  setToolTipText("Augmenter le volume");
			  break;
			  
			  case BUTTON_MOIN:
			  icones[0] = ImageIO.read(new File("vm1.png"));
			  icones[1] = ImageIO.read(new File("vm2.png"));
			  setToolTipText("Diminuer le volume");
			  break;
			  
			  case BUTTON_MUTE:
			  icones[0] = ImageIO.read(new File("im1.png"));
			  icones[1] = ImageIO.read(new File("im2.png"));
			  setToolTipText("Muet");
			  break;
			  
			  case BUTTON_PREV:
			  icones[0] = ImageIO.read(new File("ipr1.png"));
			  icones[1] = ImageIO.read(new File("ipr2.png"));
			  setToolTipText("Précédent");
			  break;
			  
			  case BUTTON_NEXT:
			  icones[0] = ImageIO.read(new File("in1.png"));
			  icones[1] = ImageIO.read(new File("in2.png"));
			  setToolTipText("Suivant");
			  break;
			  
			  default:
			  System.out.println("Type de Boutton non pris en charge");
			  break;
		 }
      }
       catch(IOException e){
       
       }
   }
}