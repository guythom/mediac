
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

public class MVolumeComponent extends JPanel{

protected AudioPlayer player;
protected JLabel labValue;
protected VSlider volumeBar;
protected int currentVolume = 200;
protected FrameButton reduire;
protected  FrameButton agrandir;
protected Player iplayer;
	public MVolumeComponent(Player play){
		setOpaque(false);
		iplayer = play;
		setLayout(new FlowLayout(FlowLayout.CENTER,4,0));
		this.player = play.player;
		currentVolume = player.getVolume();
		volumeBar = new VSlider();
		volumeBar.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				setVolume(e.getX());
			}
		});
		
		volumeBar.setMaximum(200);
		volumeBar.setMinimum(15);
		volumeBar.setValue(currentVolume);
		volumeBar.repaint();
		labValue = new JLabel("   VOLUME : " + player.getVolume());
		labValue.setForeground(new Color(255,0,0));
		labValue.setFont(new Font("Agency FB",Font.BOLD,14));
	
		agrandir = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("mediac/src/img/p1.png")),new ImageIcon(MVolumeComponent.class.getResource("mediac/src/img/p2.png")),"Augmenter le volume"){
			public void click(){
				incVolume();
			}
		};
	
		reduire = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("mediac/src/img/m1.png")),new ImageIcon(MVolumeComponent.class.getResource("mediac/src/img/m2.png")),"Baisser le volume"){
			public void click(){
				decVolume();
			}
		};
		
		final FrameButton mute = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("im3.png")),new ImageIcon(MVolumeComponent.class.getResource("im4.png")),new ImageIcon(MVolumeComponent.class.getResource("mu1.png")),new ImageIcon(MVolumeComponent.class.getResource("mu2.png")),"Desactiver le son","Activer le son"){
			public void click(){
				player.muteIf();
			}
		};
		
		
		add(mute);
		add(new JLabel(" "));
		add(reduire);
		add(volumeBar);
		add(agrandir);
		add(labValue);
	}
	
	/**public JLabel getLabel(){
		return labValue;
	}**/
	
	public void setVolume(int volume){
		if(volume > 200)
			currentVolume = 200;
		else if(volume < 15)
			currentVolume = 15;
		else
			currentVolume = volume;
			
		volumeBar.setValue(currentVolume);
		player.setVolume(currentVolume);
		player.setMarqueeOpacity(100);
        player.setMarqueeColour(Color.GREEN);
        player.setMarqueeTimeout(500);
		player.setMarqueeText(currentVolume+"");
		labValue.setText("   VOLUME : " + currentVolume);
	}
	
	protected void incVolume(){
		currentVolume  = player.getVolume();
		if(currentVolume < 200)
			currentVolume++;
		else
			currentVolume = 200;
		
		volumeBar.setValue(currentVolume);
		player.setVolume(currentVolume);
		player.setMarqueeOpacity(100);
        player.setMarqueeColour(Color.GREEN);
        player.setMarqueeTimeout(500);
		player.setMarqueeText(currentVolume+"");
		labValue.setText("   VOLUME : " + currentVolume);
	}
	
	protected void decVolume(){
		currentVolume  = player.getVolume();
		if(currentVolume > 15)
			currentVolume--;
		else
			currentVolume = 15;
		
		volumeBar.setValue(currentVolume);
		player.setVolume(currentVolume);
		player.setMarqueeOpacity(100);
        player.setMarqueeColour(Color.GREEN);
        player.setMarqueeTimeout(500);
		player.setMarqueeText(currentVolume + "");
		labValue.setText("   VOLUME : " + currentVolume);
	}
	
	protected void updateVolume(){
	currentVolume  = player.getVolume();
	volumeBar.setValue(currentVolume);
	labValue.setText("   VOLUME : " + currentVolume);
	}
	
	private  class VSlider extends JComponent implements MouseListener,MouseMotionListener{
	protected int value = 0;
	protected int max = 1;
	protected int min = 0;
	protected Color background;

		public VSlider(){
			background  = new Color(200,200,200);
			setFocusable(true);
			setOpaque(true);
			setRequestFocusEnabled(true);
			enableEvents(AWTEvent.FOCUS_EVENT_MASK);
			enableEvents(AWTEvent.KEY_EVENT_MASK);
			enableEvents(AWTEvent.MOUSE_EVENT_MASK);
			setPreferredSize(new Dimension(200,15));
		}
		
		@Override
		public boolean contains(int x, int y){
			Ellipse2D el = new Ellipse2D.Double(0, 0, 200,15);
			return el.contains(x, y);
		}
		@Override
		public void paintComponent(Graphics g){
			setPreferredSize(new Dimension(200,15));
			Graphics2D g2d = (Graphics2D)g;
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
			
			g2d.setColor(background);
			g2d.fillRoundRect(0, 0, 200, 15,15,15);
			
			GradientPaint gradient = new GradientPaint(0, 15,new Color(0,100,255), value, 150,  new Color(255,0,0,255));
			g2d.setPaint(gradient);
			g2d.fillRoundRect(0, 0, value, 15,15,15);
		}
   
		public void setValue(int i){
			int temp_value = i;
			if(temp_value < min)
				temp_value = min;
			if(temp_value > max)
				temp_value = max;
			value = temp_value;//(int)(temp_value*getWidth()/max);
			repaint();
		}
   
		public long getValue(){
			/**if(getWidth() > 0)
				return (int)(value*max/getWidth());
			else**/
			return value;
		}
   
		public void setMaximum(int max){
			if(max > 0)
				this.max = max;
			else
				this.max = 1;
		}
   
		public void setMinimum(int min){
			if(min > 0)
				this.min = min;
			else
				this.min = 0;
		}
   
		public long getMaximum(){
			return max;
		}
   
		public long getMinimum(){
			return min;
		}
		
		public void mouseClicked(MouseEvent e){}
		public void mousePressed(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mouseDragged(MouseEvent e){}
		public void mouseMoved(MouseEvent e){}
	}
}
