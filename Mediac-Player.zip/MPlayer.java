import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.GraphicsEnvironment;


import uk.co.caprica.vlcj.player.MediaPlayerFactory;
import uk.co.caprica.vlcj.player.direct.DirectMediaPlayer;
import uk.co.caprica.vlcj.player.direct.RenderCallbackAdapter;

public class MPlayer extends LibLoader{

public BufferedImage image;
private MediaPlayerFactory factory;
private DirectMediaPlayer mediaPlayer;
public int width = 900;
public int height = 700;
public int[] datas = new int[]{3700,2900,2222,2212,1111,1111};

String media = "";
MPanelPlayer panel = null;
String[] args = new String[]{};
boolean state = true;

 public MPlayer(String media, String[] args,MPanelPlayer panel){
  try{
    this.panel = panel;
    image = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration().createCompatibleImage(width, height);
    image.setAccelerationPriority(1.0f);
    this.media = media;
        factory = new MediaPlayerFactory(args);
        mediaPlayer = factory.newDirectMediaPlayer(width, height, new TestRenderCallback());
    }
	 catch(Exception e){
	  System.out.println("Erreur lors de l'initialisation de la lecture...");
	  }
  }
  
 public MPlayer(final int width,final int height){
  try{
    image = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration().createCompatibleImage(width, height);
    image.setAccelerationPriority(1.0f);
        factory = new MediaPlayerFactory(args);
        mediaPlayer = factory.newDirectMediaPlayer(width, height, new TestRenderCallback());
    }
	 catch(Exception e){
	  System.out.println("Erreur lors de l'initialisation des Composants ...");
	  state = false;
	  }
  }
	 /** Jour le media courant **/
	 public void play(){
	  try{
	   Thread.sleep(5000);
	  }
	    catch(Exception e){
		System.out.println("Thread courant interrompu dans son attente");
		}
	    mediaPlayer.playMedia(media);
        mediaPlayer.nextChapter();
	    state = true;
	   }
	  
	  public String getMedia(){
	   return media;
	   }
	  public void setMedia(String media){
	   this.media = media;
	   System.out.println("Nouveau mrl " + media);
	   }
	   
      public boolean getState(){
	  return state;
	  }
	  
    private final class TestRenderCallback extends RenderCallbackAdapter {

        public TestRenderCallback() {
            super(((DataBufferInt) image.getRaster().getDataBuffer()).getData());
        }

        @Override
        public void onDisplay(DirectMediaPlayer mediaPlayer, int[] data) {
            /** C'est ici que se font les manipulations sur les donnees videos brutes stockees dans data **/
			//if(panel != null)
			//panel.repaint();
            //System.out.println("Le buffer compte " + data.length + " Couleurs ");
			 //datas = checkDatas(data);
			 datas = data;
			 //System.out.println("" + data[0] + " " + data[1]);
			 //new sun.misc.BASE64Encoder().encode(Bytes);
        }
    }
	
	public synchronized int[] getDatas(){
	
	 return datas;
	}

}