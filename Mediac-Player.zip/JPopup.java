import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.sun.awt.AWTUtilities;
import com.sun.jna.platform.WindowUtils;

public class JPopup extends JDialog{
	VMenu menu;
	
	public JPopup(JFrame frame,VMenu Inmenu){
		super(frame, "",false,WindowUtils.getAlphaCompatibleGraphicsConfiguration());
		setUndecorated(true);
		AWTUtilities.setWindowOpaque(this, false);
		menu = Inmenu;
		setSize(350,90);
	
		addFocusListener(new FocusAdapter(){
			public void focusGained(FocusEvent e) {
			
			}
			public void focusLost(FocusEvent e) {
				setVisible(false);
				menu.hover = false;
				menu.repaint();
			}
		
		});
	}

}