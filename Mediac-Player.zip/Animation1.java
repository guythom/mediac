import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.RenderingHints;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.WindowConstants;

import java.awt.RadialGradientPaint;

@SuppressWarnings("serial")
public class Animation1 extends JComponent {

    int x=100;
    int y=100;
    float theta=0;
    int dx=6;
    int dy=4;
    float dtheta=-0.1f;
    
    private final Area house = new Area(createHouse(0,0));
    
    public Animation1(int width,int height) {
        setPreferredSize(new Dimension(width,height));
        new Timer(100,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x=x+dx;
                y=y+dy;
                theta=theta+dtheta;
                repaint();
            }
        }).start();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2=(Graphics2D)g;
        g2.setColor(Color.BLACK);
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setPaint(new RadialGradientPaint(getWidth()/2,getHeight()/2,getWidth()/4,new float[]{0.4f,0.6f},new Color[]{Color.BLUE,Color.BLACK}));
        int w = getWidth();
        int h = getHeight();
        g2.fillRect(0,0,w,h);
        g2.setColor(new Color(0,120,220,255));
		
        AffineTransform old = g2.getTransform();
        g2.translate(x,y);
        g2.rotate(theta);
        g2.fill(house);
        Area tmp = house.createTransformedArea(g2.getTransform());
        g2.setTransform(old);
        if (tmp.intersects(w,0,w,h)) {
            dx=-dx;
            if (dy>0) dtheta=-0.1f;
            else dtheta=0.1f;
        }
        if (tmp.intersects(0,0,1,h)) {
            dx=-dx;
            if (dy>0) dtheta=0.1f;
            else dtheta=-0.1f;
        }
        if (tmp.intersects(0,0,w,1)) {
            dy=-dy;
            if (dx>0) dtheta=-0.1f;
            else dtheta=0.1f;
        }
        if (tmp.intersects(0,h,w,h)) {
            dy=-dy;
            if (dx>0) dtheta=0.1f;
            else dtheta=-0.1f;
        }
    }
    
    public static void main(String[] args) {
        JFrame f=new JFrame("Bouncing house");
        final Animation1 area = new Animation1(400,400);
        f.getContentPane().add(area);
        f.pack();
        f.setResizable(false);
        f.setDefaultCloseOperation(args.length == 0 ? JFrame.EXIT_ON_CLOSE : WindowConstants.DISPOSE_ON_CLOSE);
        f.setVisible(true);
    }

    /**
     * Creates a house-shaped polygon. x and y represents the center of the house.
     */
    private Polygon createHouse(int x,int y) {
        Polygon p=new Polygon();
        p.addPoint(x-40,y+45);
        p.addPoint(x-40,y);
        p.addPoint(x-50,y);
        p.addPoint(x,y-45);
        p.addPoint(x+50,y);
        p.addPoint(x+40,y);
        p.addPoint(x+40,y+45);
        return p;
    }

}
