import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.concurrent.TimeUnit;

public class VolumeControl extends JPanel{
MSlider slider = null;
InternalButton plus;
InternalButton moin;

	public VolumeControl(){
	super();
	slider = new MSlider(){
		public void exec(){
		setLevel();
		}
	};
	setLayout(new BorderLayout());
	//setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
	setOpaque(false);
	slider.setMaximum(2000);
	slider.setMinimum(150);
	slider.setSlideType(1);
	
	plus = new InternalButton(InternalButton.BUTTON_PLUS,30,30);
	moin = new InternalButton(InternalButton.BUTTON_MOIN,30,30);
	
	add("West",moin);
	add("Center",slider);
	add("East",plus);
	
	slider.addMouseListener(new MouseAdapter(){
	public void mouseClicked(MouseEvent e){
	}

    public void mousePressed(MouseEvent e){
	}
	
	});
	plus.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	up();
	}});
	
	moin.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	down();
	}});
	
	}
	
	public void up(){
	slider.setValue(slider.getValue() + 10);
	}
	
	public void down(){
	slider.setValue(slider.getValue() - 10);
	}
	
	public void setLevel(){
	System.out.println("Updating");
	}
	
	public long getValue(){
	return slider.getValue();
	}
	
	public void setValue(long value){
	slider.setValue(value);
	}
	public static void main(String[]args){
	JFrame frame = new JFrame("test MSlider");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	JPanel panel = new JPanel();
	panel.setLayout(new BorderLayout());
	//panel.setBackground(new Color(0,0,0));
	
	final VolumeControl slide = new VolumeControl();
	
	//panel.add("North",new JButton("Hi !"));
	//panel.add("Center",slide);
	frame.getContentPane().add(slide);
	frame.setSize(700,300);
	frame.setLocationRelativeTo(null);
	frame.setVisible(true);
	}

}