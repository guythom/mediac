import java.util.ArrayList;
import javax.sound.sampled.SourceDataLine;

public class AudioBuffer{

ArrayList<byte[]> buffer;
SourceDataLine line = null;
Thread mixerThread = null;
AudioPlayer player = null;
protected boolean isMixing = false;
protected boolean pause = false;
	public AudioBuffer(SourceDataLine line,AudioPlayer player){
	this.line = line;
	this.player = player;
	buffer = new ArrayList<byte[]>();
	resetMixer();
	}
	
	public void resetMixer(){
	mixerThread = new Thread(new Runnable(){
		public void run(){
			player.pause();
			playSample();
		}
	});
	
	}
	
	protected void playSample(){
	byte[] samples = null;
		while(true){
			for(int i = 0; i < buffer.size();i++){
				samples = buffer.get(i);
				line.write(samples,0,samples.length);
			}
			if(!isMixing) break;
			sleep(50);
			//line.drain();
		}
		if(player.isPlayable()){
			player.play();
		}
		resetMixer();
		buffer.clear();
	}
	
	public void add(byte[]samples){
		buffer.add(samples);
	}
	
	protected void playBuffer(){
		mixerThread.start();
	}
	protected  boolean isMixing(){
		return isMixing;
	}
	
	public synchronized void mix(){
		if(!isMixing()){
			isMixing = true;
			playBuffer();
		}
	}
	
	public void sleep(int delay){
		try{
			mixerThread.sleep(delay);
		}catch(Exception e){
			
		}
	}
	
	public synchronized void stopMix(){
		isMixing = false;
	}
	
}