import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class Utiler{
public static final long serialVersionUID = -1439220305231L;

	public static void showHelpFrame(){
		JFrame frame = new JFrame("Mediac Player 1.0 intro - A Propos");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(580,150);
		JPanel root = new JPanel();
		root.setLayout(new BorderLayout());
		frame.getContentPane().add(root);
		JTextPane textPane = new JTextPane();
		//textPane.setFont(new Font("Arial",Font.BOLD,14));
		
		textPane.setEditable(false);
		String text = " Mediac Player 1.0 - Intro  \n Verion 1.0 -Introdution - Mars 2016 \n La version 1.0 finale sera disponible le 01 Juin 2016 sur \"www.mediac.org\"  \n (copyright) NKOT YOGO GUY THOMAS : Douala - Cameroun - PK8 \n Tel : (+237)679 82 13 90 - Email : nkotyogo@yahoo.fr \n Veuillez me contacter pour toutes suggestions ou demandes.";
		textPane.setText(text);
		root.add("Center",textPane);
		frame.setVisible(true);
	}
	
	
	public class DataBaseManager{
		DataBase dataBase = null;
		public DataBaseManager(){
			 
		
		}
		
		public void loadDataBase(){
			if(ensureDataBase()){
				try{
					ObjectInputStream input;
					input = new ObjectInputStream(new FileInputStream("db.obj"));
					DataBase dataBase;
					dataBase = (DataBase)input.readObject();
				}catch(Exception e){}
			}
		
		}
		
		public void addToDataBase(){
		
		}
		
		protected boolean ensureDataBase(){
			String store = System.getProperty("user.home");
			store = store + File.separatorChar + "Application Data";
			store = store + File.separatorChar + "Mediac Player";
			File appDataPath = new File(store);
			
			if(appDataPath.exists() &&  appDataPath.isDirectory()){
				File dataBasePath = new File(store + File.separatorChar + "db.obj");
				if(dataBasePath.exists()){
					return true;
				}
				else{
					try{
						if(dataBasePath.createNewFile()){
							System.out.println(dataBasePath.getPath()+">>>");
							dataBase = new DataBase();
							return false;
						}
					}catch(Exception e){}
				}
			}
			else{
				if(appDataPath.mkdirs()){
					File dataBasePath;
					dataBasePath = new File(store + File.separatorChar + "db.obj");
					try{
						if(dataBasePath.createNewFile()){
							dataBase = new DataBase();
							System.out.println(dataBasePath.getPath()+">>>");
							return false;
						}
							
					}catch(Exception e){}
				}
			
			}
			
			return false;
		}
		
		
	}
	
	









}