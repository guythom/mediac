
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.ArrayList;


public class ExternControl{

String [] eq_list = { "20 Hz",
    "25 Hz",
    "31.5 Hz",
    "40 Hz",
    "50 Hz",
    "63 Hz",
    "80 Hz",
    "100 Hz",
    "125 Hz",
    "160 Hz",
    "200 Hz",
    "250 Hz",
    "315 Hz",
    "400 Hz",
    "500 Hz",
    "630 Hz",
    "800 Hz",
    "1k Hz",
    "1.25k Hz",
    "1.6k Hz",
    "2k Hz",
    "2.5k Hz",
    "3.15k Hz",
    "4k Hz",
    "5k Hz",
    "6.3k Hz",
    "8k Hz",
    "10k Hz",
    "12.5k Hz",
    "16k Hz",
    "20k Hz"};
ArrayList<JComponent> componentList = new ArrayList<JComponent>();
ArrayList<JSlider> sliderList = new ArrayList<JSlider>();
final JPanel root = new JPanel();
	public ExternControl(final AudioPlayer player){
	root.setLayout(new BorderLayout());
	
	JPanel eq = new JPanel();
	eq.setLayout(new GridLayout(3,32));
	
	final JLabel level_pre = new JLabel(" 0 %");
	final JSlider sliderPre = new JSlider(SwingConstants.VERTICAL);
	sliderPre.setMaximum(12);
	sliderPre.setMinimum(-12);
	sliderPre.setValue(0);
	sliderPre.addChangeListener(new ChangeListener(){
		public void stateChanged(ChangeEvent e){
			long val = sliderPre.getValue();
			float value = val/12.0f;
			player.setPreampDbValue(1,val);
			player.setPreampDbValue(0,val);
			level_pre.setText(value*100 + " %");
		}});
		JLabel label_pre = new JLabel("Pream");
		
	for(int i = 0; i < eq_list.length; i++){
	final JLabel level = new JLabel(" 0 %");
	final JSlider slider = new JSlider(SwingConstants.VERTICAL);
	final int index = i;
	slider.setMaximum(1000);
	slider.setMinimum(-200);
	slider.setValue(0);
	slider.addMouseListener(new MouseAdapter(){
            @Override
            public void mousePressed(MouseEvent e) {
			long val = slider.getValue();
			float value = val/1000.0f;
			player.setBandValue(index,1,value);
			player.setBandValue(index,0,value);
			level.setText(value*100 + " %");
            }
			public void mouseReleased(MouseEvent e){
			long val = slider.getValue();
			float value = val/1000.0f;
			player.setBandValue(index,1,value);
			player.setBandValue(index,0,value);
			level.setText(value*100 + " %");
			}
        });
		
		slider.addChangeListener(new ChangeListener(){
		public void stateChanged(ChangeEvent e){
			long val = slider.getValue();
			float value = val/1000.0f;
			player.setBandValue(index,1,value);
			player.setBandValue(index,0,value);
			level.setText(value*100 + " %");
		}});
		
	JLabel label = new JLabel(eq_list[i]);
	componentList.add(level);
	componentList.add(slider);
	componentList.add(label);
	sliderList.add(slider);
	}
	
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < componentList.size()/3; j++)
			eq.add(componentList.get(j*3 + i));
	
	eq.add(level_pre);
	eq.add(sliderPre);
	eq.add(label_pre);
		
	root.add("North",eq);
	
	}
	
	public void reset(){
		for(int i = 0; i < sliderList.size();i++){
			sliderList.get(i).setValue(0);
		}
	}
	
	public void show(){
		JFrame frame = new JFrame("Controleur temporaire de Mediac");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(700,400);
		frame.getContentPane().add(root);
		frame.setVisible(true);
	}
	
	public static void show(AudioPlayer player){
	new ExternControl(player);
	}


}