
public class Mandelbrot {
    
    
	//Repr�sente le nombre de fois que l'on rep�te la formule de Mandelbrot
	private int iteration;
	//Cr�ation d'un matrice : axe abscisse - ordonn�e
    public int[][] axe;
   //Repr�sente la largeur et la hauteur maximale que la fen�tre aura
    private int lwin;
    private int hwin;
    //Repr�sente les abscisses max et min et ordonn�es max et min que l'on peut avoir
    private double ymax,ymin,xmin,xmax;
    
    public Mandelbrot(){
       
    	//Initialisation des variables
    	 hwin=700;
         lwin=700;
         axe = new int[lwin][hwin];
                   
    }
   
	public void calcul(){
        //Va contenir les valeurs qui vont permettre de cr�er le fractal
		int n;
        /*Parcours de l'hauteur et de la largeur de la fen�tre pour fixer les valeurs dans 
        la matrice axe gr�ce � la formule de Mandelbrot*/
        
		
		for(int i=0;i<hwin;i++)
        {
            for(int j=0;j<lwin;j++)
            {
                //D�but de formule de Mandelbrot
            	Complexe c = new Complexe((i*(xmax-xmin)/(double)(hwin) + xmin),(ymax - j*(ymax-ymin)/(double)(lwin)));
            	Complexe z = new Complexe(0,0);
                n=0;
                /*Tant que le nombre d'it�ration est sup�rieur � n et la norme du complexe z
                est inf�rieur � 4, on incr�mente n et on place dans le complexe z
                la valeur de la somme du complexe c et le carr� du complexe z */
                while((n<iteration) && (z.norme2()<4))
                {
                    n++;
                    //Fin de formule de Mandelbrot
                    z=(z.carre()).somme(c);
                }
                /*On stocke dans la matrice axe les valeurs de n si elles sont inf�rieures
                 � celle de l'it�ration ou sinon on fixe 0 � la matrice axe */
               if(n<iteration)
                    axe[i][j]=n;
                else
                    axe[i][j]=0;
            }
        }
        
    }
	
	//Permet de modifier les attributs xmin, xmax, ymin, ymax
	public void setCoord(double xmin,double xmax, double ymin, double ymax)
	 {
		
		 this.xmin = xmin;
		 this.xmax = xmax;
		 this.ymin = ymin;
		 this.ymax = ymax;
			 
	 }
	
	//Permet de modifier l'attribut it�ration
	 public void setIteration(int it)
	    {
	    	this.iteration = it;
	    }
}
