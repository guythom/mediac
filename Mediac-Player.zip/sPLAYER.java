playerPane.removeAll();
               if(player.getId() == 0){
               playerPane.add("Center",Xpane);
			   playerPane.updateUI();
			   getNextPlayer().attach();
               }
               else{
               playerPane.add("Center",Ypane);
			   playerPane.updateUI();
               getNextPlayer().attach();
               }