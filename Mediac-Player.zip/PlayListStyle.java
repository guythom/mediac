/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

  import java.awt.*;
  import javax.swing.*;
  
  class PlayListStyle extends JLabel implements ListCellRenderer<Object> {
      final static ImageIcon audio = new ImageIcon("audio.png");
      final static ImageIcon video = new ImageIcon("video.png");
	  final static ImageIcon inc = new ImageIcon("inc.png");
      public static final long serialVersionUID = -12322308832L;
      public PlayListStyle(){
	  
	  }
 
      public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean isSelected,    boolean cellHasFocus){
	      
          String s = value.toString().toLowerCase();
          setText((s.length()<50)?s:s.substring(0,46)+"...");
		  if(isAudio(s) == 0)
		   setIcon(audio);
		    else if(isAudio(s) == 1)
			  setIcon(video);
			    else
				  setIcon(inc);
		  
          if (isSelected) {
		      //setFont(new Font("arial",Font.BOLD,20));
		      //setBackground(new Color(51,102,255,255));
			  setOpaque(true);
			  setBackground(new Color(100,100,100));
              setForeground(Color.WHITE);
          } else {
              //setBackground(list.getBackground());
			  setOpaque(false);
              setForeground(list.getForeground());
			}
          setEnabled(list.isEnabled());
          setFont(list.getFont());
          
          return this;
      }
	  
	  public int isAudio(String value){
	  return MediaUtil.getType(value);
	  }
  }