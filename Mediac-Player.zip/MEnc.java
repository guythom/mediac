/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
import quentinc.geom.Matrix;

public class MEnc{

public static final int[][] Mmat = new int[][]{
                                          {-1,1,0},
										  {-1,0,1},
										  {0,-1,0}
										  };
										  
public static final int[][] InvM = new int[][]{
                                          {-1,0,-1},
										  {0,0,-1},
										  {-1,1,-1}
										  };
static int[][] tempx = new int[][]{{1,1,1},{1,1,1},{1,1,1}};

static int[][] tempx2 = new int[][]{{0,0,1},{1,0,1},{1,1,1}};

static int zero_count = 0;
static int count = 1;
static int countX = 0;
static int countY = 0;
static int [][] tmat = null;
static long time = 0;
static String towrite = "";
static FileManip manip = new FileManip();
static final FileManip manip2 = new FileManip();
static final FileManip manip3 = new FileManip();
static final FileManip manip4 = new FileManip();

   public static void checkAllNuplet(int n,int k){
   manip.initWriteFile("nombre_repondant_matrice.txt");
   manip2.initWriteFile("amatrice_repondante.txt");
   manip3.initWriteFile("Combinaison_avec_8_zeros.txt");
   manip4.initWriteFile("rapport.txt");
      int[] k_uplet = new int[k];
	  long uplet = 1;
	  long temp = 0;
	  for(int i = 0; i < k; i++)
      uplet *= n;
	  time = System.currentTimeMillis();
	  for(long i = 0; i < uplet; i++){
	      temp = i;
		  towrite = "" + i;
	      for(int j = 0; j < k; j++){
		  k_uplet[j] = (int)(temp % n);
		  temp = temp/n;
		  }
		  int[][] mat = new int[3][3];
		  
		  mat[0][0] = k_uplet[0];//151200000
		  mat[0][1] = k_uplet[1];
		  mat[0][2] = k_uplet[2];
		  mat[1][0] = k_uplet[3];
		  mat[1][1] = k_uplet[4];
		  mat[1][2] = k_uplet[5];
		  mat[2][0] = k_uplet[6];
		  mat[2][1] = k_uplet[7];
		  mat[2][2] = k_uplet[8];
		  //toString(mat);
		  tmat = mat;
		  check(matrix_mult(Mmat,mat));
		  
		 long stime = (System.currentTimeMillis() - time)/1000;
		 if(stime >= 1){
		   try{
		    Thread.currentThread().sleep(5000);
			time = System.currentTimeMillis(); 
		   }
		   catch(Exception e){
		 
		   }
		 }
		 
	  }
   }
   
   public static int[][] matrix_mult(int A[][],int B[][]){
   if(A[0].length != B.length)
   throw new ArithmeticException(String.format("Le nombre de colonne de A doit egaler le nombre de ligne de B"));
   
   int[][] ret = new int[A.length][B[0].length];
   
   for(int i = 0; i < A.length; i++)
      for(int j = 0; j < B[0].length; j++)
	     for(int k = 0; k < A[0].length; k++)
		 ret[i][j]  += A[i][k] * B[k][j]; 
		 
   return ret;
   }

   public static void main(String [] args){
   /**int n = Integer.parseInt(args[0]);
   int k = Integer.parseInt(args[1]);
   checkAllNuplet(n,k);
   long stime = (System.currentTimeMillis() - time)/1000;
   //System.out.println(" "+zero_count+" produits de matrices avec au moins 8 zero en " + stime + " secondes" );
   manip4.writeLine(" "+zero_count+" produits de matrices avec au moins 8 zero en " + stime + " secondes");
   manip4.writeLine(" "+countY+" matrices avec au moins 8 zero en " + stime + "en secondes");
	//int[][] B = new int[][]{{63400,50000,200},{65534,200,6553},{65534,128,1}};
	//toString(matrix_mult(Mmat,B));*/
	checkZero();
   }
   
   public static void print(int Matrix[][]){
   for(int i = 0; i < Matrix.length; i++){
      for(int j = 0; j < Matrix[0].length; j++){
	  System.out.printf(" " + Matrix[i][j]);
	  }
	  System.out.printf("\n");
   }
   
   }
   
   public static String toString(int Matrix[][]){
   String m = "";
   for(int i = 0; i < Matrix.length; i++){
      for(int j = 0; j < Matrix[0].length; j++){
	  m = m + Matrix[i][j] + " ";
	  }
	  m = m + "\n";
	  //System.out.printf("\n");
   }
   return m;
   }
  
  public static void check(int Matrix[][]){
  int z = 0;
  for(int i = 0; i < Matrix.length; i++){
      for(int j = 0; j < Matrix[0].length; j++){
	  if(Matrix[i][j] == 0)
	  z++;
	  }
  }
  if(z < 8){
  countX++;
  //System.out.println("Matrice = " + countX + " --------- ");
  //System.out.println("-----------------------");
  //toString(tmat);
  //System.out.println(".....................");
  //toString(directMult(tmat,Mmat));
  //System.out.println("Matrice = " + countX + " -- moins ");
  //check2(matrix_mult(Mmat,oppose(Matrix)));
  //check2(matrix_mult(oppose(Matrix),Mmat));
  } //toString(Matrix);
    else{
	zero_count++;
	countX++;
	manip.writeLine(towrite);
	manip2.writeLine(toString(tmat));
	if(count == 262145)System.exit(0);
	//if(zero_count > 466 )System.exit(0);
  //System.out.println("-----------------------");
  //toString(tmat);
  //System.out.println(".....................");
  //toString(directMult(tmat,Mmat));
	
	//if(tmat.equals(tempx)){
	//System.out.println("index = " + countX );
	/**boolean v = true;
	for(int i = 0; i < tmat.length; i++){
      for(int j = 0; j < tmat[0].length; j++){
	  if(tmat[i][j] != tempx2[i][j])
	  v = false;
	  }
    }
	if(v){
	System.out.println("index = " + countX );
	toString(tmat);}
	//if(count == 10)System.exit(0);
	//count++;
	
	
	/**boolean br = false;
	int[][] tMatrix = matrix_mult(InvM,Matrix);
	for(int i = 0; i < tMatrix.length; i++){
      for(int j = 0; j < tMatrix[0].length; j++){
	  if(tMatrix[i][j] == 4){
	  //toString(Matrix);
	  zero_count++;
	  br = true;
	  break;
	  }
	  }
       if(br) break;
	   }
    
    //toString(matrix_mult(InvM,Matrix));
	//toString(Matrix);
	
	//System.out.println("________________________________________");**/
    }
	z = 0;
	for(int i = 0; i < tmat.length; i++){
      for(int j = 0; j < tmat[0].length; j++){
	  if(tmat[i][j] == 0)
	  z++;
	  }
    }
	if(z < 8){
	}
	///
	else {
	countY++;
	manip3.writeLine(towrite);
	}
	
  }
  
  public static void check2(int Matrix[][]){
  toString(Matrix);
  int z = 0;
  for(int i = 0; i < Matrix.length; i++){
      for(int j = 0; j < Matrix[0].length; j++){
	  if(Matrix[i][j] == 0)
	  z++;
	  }
  }
  if(z < 3){
  toString(Matrix);
  } //toString(Matrix);
  else zero_count++;
  }
  
  public static int[][] oppose(int[][] bad){
  int[][] ret = new int[bad.length][bad[0].length];
  for(int i = 0; i < bad.length; i++){
      for(int j = 0; j < bad[0].length; j++){
	  ret[i][j] = 0 - bad[i][j];
	  }
  }
  return ret;
  }
  
  public static int[][] directMult(int[][]d1,int[][]d2){
  int[][] ret = new int[d1.length][d1[0].length];
  for(int i = 0; i < d1.length; i++){
      for(int j = 0; j < d1[0].length; j++){
	  ret[i][j] = d1[i][j]*d2[i][j];
	  }
  }
  return ret;
  }
  
  private String getBits( int value )
   {
      int displayMask = 1 << 31;
      StringBuffer buf = new StringBuffer( 35 );

      for ( int c = 1; c <= 32; c++ ) {
         buf.append(
            ( value & displayMask ) == 0 ? '0' : '1' );
         value <<= 1;

         if ( c % 8 == 0 )
            buf.append( ' ' );
      }

      return buf.toString();
   }
   
   public static int inverseBits(int i) {
        i = (i & 0x55555555) << 1 | (i >>> 1) & 0x55555555;
        i = (i & 0x33333333) << 2 | (i >>> 2) & 0x33333333;
        i = (i & 0x0f0f0f0f) << 4 | (i >>> 4) & 0x0f0f0f0f;
        i = (i << 24) | ((i & 0xff00) << 8) |
            ((i >>> 8) & 0xff00) | (i >>> 24);
        return i;
    }
	
	public static void checkZero(){
	Matrix mat1 = null;
	Matrix mat2 = null;
	Matrix mat3 = null;
	Matrix mat4 = null;
	
	double[][] zero = new double[][]{{0,0},{0,0}};
	Matrix matzero = new Matrix(zero);
	double[][] m1 = new double[2][2];
	double[][] m2 = new double[2][2];
	
	int[] k_uplet = new int[2];
	int uplet = 256;//1 << 24;
	System.out.println(""+uplet);
	int temp = 0;
	
		for(int i = 0; i < uplet; i++){
	      temp = i;
		  
	      for(int j = 0; j < 2; j++){
		  k_uplet[j] = (int)(temp % 16);
		  temp = temp/16;
		  }
			m1[0][0] = bget((double)(k_uplet[0] >> 3));
			m1[0][1] = bget((double)((k_uplet[0] >> 2)&1));
			m1[1][0] = bget((double)((k_uplet[0] >> 1)&1));
			m1[1][1] = bget((double)(k_uplet[0]&1));
			
			m2[0][0] = bget((double)(k_uplet[1] >> 3));
			m2[0][1] = bget((double)((k_uplet[1] >> 2)&1));
			m2[1][0] = bget((double)((k_uplet[1] >> 1)&1));
			m2[1][1] = bget((double)(k_uplet[1]&1));
		  
			mat1 = new Matrix(m1);
			mat2 = new Matrix(m2);
			double det1 = (m1[0][0]*m1[1][1]) - (m1[0][1]*m1[1][0]);
			double det2 = (m2[0][0]*m2[1][1]) - (m2[0][1]*m2[1][0]);
			
			
			if(det1 != 0 && det2 != 0){
			
			if(!mat1.equals(matzero) && !mat2.equals(matzero)){
			mat3 = mat1.multiply(mat2);
			mat4 = mat2.multiply(mat1);
			boolean mb3 = (mat3.equals(matzero))?true:false;
			boolean mb4 = (mat4.equals(matzero))?true:false;
			
				if(mb3 && mb4){
				System.out.println("Produit null des deux cote");
				System.out.println(mat1.toString());
				System.out.println(mat2.toString());
				}
				else if(mb3 || mb4){
				System.out.println("Produit null d'un seul cote");
				System.out.println(mat1.toString());
				System.out.println(mat2.toString());
				}
			}
			}
		}
	
	}
	
	public static double get(double nb){
	double max = 8;
	double k = max/2;
	double n = (nb >= max)?(max-1):nb;
	return (n <= k && n >= 0)?n:(0 - (max - n));
	
	}
	
	public static double bget(double nb){
	double ret = (nb == 0)?-1:1;
	System.out.println("input " + nb + " return " + ret);
	return ret;
	}
	
	
	
	
	
	
}