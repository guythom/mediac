/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;


import java.util.ArrayList;

public class MComboBox extends JPanel{

protected JTextField textBox;
protected JLabel control;
protected JPopupMenu popup;
protected ArrayList<String> elementList;
protected JPanel cont;


protected boolean show = false;

ImageIcon [] icons = new ImageIcon [2];

 public MComboBox(ArrayList elementList,int col){
  super();
  setBorder(BorderFactory.createLineBorder(new Color(0,102,255,255)));
  setBackground(new Color(255,255,255,255));
  this.elementList = elementList;
  
  textBox = new JTextField(col);
  textBox.setBorder(null);
  textBox.setFont(new Font("calibri",Font.BOLD,15));

  MPlainDocument mdoc = new MPlainDocument(this,textBox,elementList);
  textBox.setDocument(mdoc);
  
  icons[0] = new ImageIcon("mediac/src/img/c1.png");
  icons[1] = new ImageIcon("mediac/src/img/c2.png");
  
  control = new JLabel(icons[0]);
  control.setUI(new javax.swing.plaf.basic.BasicLabelUI());
  control.setBorder(null);
  control.addMouseListener(new MouseAdapter(){
  public void mousePressed(MouseEvent e){
  list();
  }
  public void mouseEntered(MouseEvent e){
  control.setIcon(icons[1]);
  }
  public void mouseExited(MouseEvent e){
  control.setIcon(icons[0]);
  }});
 textBox.addActionListener(new ActionListener(){
 public void actionPerformed(ActionEvent e){
 go(e.getActionCommand());
 }});

  add(textBox);
  add(control);		
 } 
 
 public void list(){
 if(!show){
  showPopup();
  show = true;
  }
  else{
  hidePopup();
  show = false;
  }
 }
 
 public void showPopup(){
 popup = new JPopupMenu();
 popup.setBorder(BorderFactory.createLineBorder(new Color(100,100,100,255)));
 cont = new JPanel();
 cont.setBackground(Color.WHITE);
 cont.setBorder(null);
 JScrollPane scroll = new JScrollPane(cont);
 cont.setLayout(new GridLayout(elementList.size(),1));
 
 popup.addPopupMenuListener(new MenuListener());
 popup.setBackground(Color.WHITE);
 popup.setUI(new javax.swing.plaf.basic.BasicPopupMenuUI());
 popup.setPreferredSize(new Dimension(getWidth(),getHeight()*8));
 popup.setBorder(null);
 
 for(int i = 0; i < elementList.size();i++){
 final JLabel menuItem = new JLabel(elementList.get(i));
 menuItem.setUI(new javax.swing.plaf.basic.BasicLabelUI());
 menuItem.setFont(new Font("arial",Font.BOLD,15));
 if(i == 0)
  menuItem.setForeground(new Color(0,102,255,255));
 else
  menuItem.setForeground(new Color(50,50,50,255));
  menuItem.addMouseListener(new MouseAdapter(){
  public void mousePressed(MouseEvent e){
  textBox.setText(menuItem.getText());
  hidePopup();
  go(textBox.getText());
  }
  public void mouseEntered(MouseEvent e){
  menuItem.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
  menuItem.setBackground(new Color(51,102,255,255));
  menuItem.setForeground(new Color(0,102,255,255));
  menuItem.setFont(new Font("arial",Font.BOLD,18));
  }
  public void mouseExited(MouseEvent e){
  menuItem.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
  menuItem.setBackground(Color.WHITE);
  menuItem.setForeground(new Color(50,50,50,255));
  menuItem.setFont(new Font("arial",Font.BOLD,15));
  }});
 
  cont.add(menuItem);
 }
  popup.add(scroll);
  
  popup.show(this,getX(),getY()+getHeight()+20);
  popup.setLocation(getX(),getY()+getHeight()+20);
 }
 
 public void hidePopup(){
 if(cont != null) cont.removeAll();
 if(cont != null)
 popup.setVisible(false);
 popup = null;
 cont = null;
 }
 
 class MenuListener implements PopupMenuListener{
 
  public void popupMenuWillBecomeVisible(PopupMenuEvent e){
  
  }
  public void popupMenuWillBecomeInvisible(PopupMenuEvent e){
    if(show){
    popup.removeAll();
     cont.removeAll();
      popup = null;
       cont = null;
        show = false;
    }
  }
  public void popupMenuCanceled(PopupMenuEvent e){
    if(show){
     popup.removeAll();
      cont.removeAll();
       popup = null;
        cont = null;
         show = false;
    }
  }
 }
 
 /** A overrider **/
 public void go(String url){
 
 }
  
}