import javafx.scene.web.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.embed.swing.JFXPanel;
import javafx.embed.swing.SwingNode;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker.State;
import netscape.javascript.JSObject;


import com.sun.javafx.application.PlatformImpl;
 public class Insert{
 
 SwingNode swingNode;
 JPanel panel;
 JFXPanel fxpanel;
 JFrame frame;
 
  public Insert(){
  frame = new JFrame("Bindings des objects java en js");
  frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  fxpanel = new JFXPanel();
  frame.getContentPane().add(fxpanel);
  panel = new JPanel();
  panel.setBackground(java.awt.Color.BLACK);
  frame.setVisible(true);
   PlatformImpl.startup(new Runnable(){
     public void run(){
	 swingNode = new SwingNode();
	 swingNode.setContent(panel);
	  WebView view = new WebView();
	  final WebEngine engine = view.getEngine();
	  fxpanel.setScene(new Scene(view,(int)frame.getSize().getWidth(),(int)frame.getSize().getHeight(),true));
	  
	  engine.getLoadWorker().stateProperty().addListener(new ChangeListener<State>(){
	  public void changed(ObservableValue ov,State oldState,State newState){
	   if(newState == State.SUCCEEDED){
	     JSObject js = (JSObject)engine.executeScript("window");
		 org.w3c.dom.Document doc = engine.getDocument();
		 int width = Integer.parseInt(doc.getElementById("videoSurface").getAttribute("width"));
		 int height = Integer.parseInt(doc.getElementById("videoSurface").getAttribute("height"));
		 System.out.println("width = " + width + " height = " + height);
		 js.setMember("MPlayer",new MPlayer(width,height));
	    }
		 if(newState == State.RUNNING){
		 
		  
		  }
		   if(newState == State.CANCELLED){
		    
			
			}
			 if(newState == State.FAILED){
			 
			  }
	  }
	  });
	  engine.load("http://localhost/home");
	 }
   });
  
  }
  
  public static void main(String[]args){
  new Insert();
  }
  
 }