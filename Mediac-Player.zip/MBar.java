import javax.swing.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.Iterator;

public class MBar extends MPanel{
ArrayList<VMenu> menuList = new ArrayList<VMenu>();
JFrame frame = null;

   public MBar(JFrame frame){
	  super();
	  this.frame = frame;
	  setFocusable(true);
      setRequestFocusEnabled(true);
      enableEvents(AWTEvent.FOCUS_EVENT_MASK);
      enableEvents(AWTEvent.MOUSE_EVENT_MASK);
      setLayout(new FlowLayout(FlowLayout.LEFT,1,1));
      setPreferredSize(new Dimension(400,30));
   }
   
   public void addMenu(VMenu menu){
   menuList.add(menu);
   add(menu);
   }
   
	public void closePopupMenu(){
		for(Iterator i = menuList.iterator();i.hasNext();){
			VMenu menu = (VMenu)i.next();
			menu.closePopupMenu();
		}
	}
   
   public JFrame getFrame(){
   return frame;
   }
}