/** NKOTYOGO GUY THOMAS  DOUALA  Septembre 2014**/

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.concurrent.*;

/** Simple cpmosant anime 
**@author NKOT YOGO GUY THOMAS
**@see MAnimation**/

public class MAnimatePanel1 extends JPanel implements MAnimation{
ScheduledExecutorService controleur = Executors.newSingleThreadScheduledExecutor();

protected int ib[];
protected int bit_trate;
public boolean paint = false;
byte[] data;
Random random;
int i = 0;
  public MAnimatePanel1(){
  
     data = new byte[256];
     for(int i = 0; i < 256; i++){
       data[i] = (byte)i;
     }
	   random = new Random();
	   ib = new int[2];
	   bit_trate = 0;
	   controleur.scheduleAtFixedRate(new Player(), 0L, 1L, TimeUnit.SECONDS);
  
  }
  
  public void paintComponent(Graphics g){
    Graphics2D g2d = (Graphics2D)g;
	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
	g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
	if(paint){
	    
		if(i == 255)
		i = 0;
	    Color c1 = new Color(ib[0]&0xff,ib[1]&0xff,data[i]&0xff);
		Color c2 = new Color(ib[1]&0xff,data[i]&0xff,data[ib[0]]&0xff);
	    GradientPaint paint = new GradientPaint(0,getHeight(),c1,getWidth(),50,c2);
		i++;
		g2d.setPaint(paint);
		g2d.fillRect(0,0,getWidth(),getHeight());
    }
	else{
	g2d.setColor(Color.BLACK);
	g2d.fillRect(0,0,getWidth(),getHeight());
	}
  }

         public void start(){
           //player.start();
		   
         }

         public void stop(){
         }

         public void dispose(){

         }
		 
		 public int getRate(){
		 return 100;
		 }
		 
		 public void sleep(int t){
		   try{
		      Thread.sleep(t);
		    }catch(Exception e){
		    }
		 }
	
	
    public static void main(String[]args){
	final MAnimatePanel1 animation = new MAnimatePanel1();
	SwingUtilities.invokeLater(new Runnable(){
	  public void run(){
	   JFrame frame = new JFrame("UN JComponent avec animation");
	   frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	   frame.setSize(700,600);
	   frame.setLocationRelativeTo(null);
	   frame.getContentPane().add(animation);
	   frame.setVisible(true);
	  }});
	}
	
  private class Player implements Runnable{
  
      public Player(){
	  
	  }
	   public void run(){
	     repaint();
		 updateUI();
		 random.nextBytes(data);
		 ib[0] = random.nextInt(8);
		 bit_trate = getRate();
		 ib[1] = bit_trate;
		 if(paint == false){
		 sleep(5000);
		 paint = true;
		 }
	   }
  }
}

interface MAnimation{

void start();

void stop();

void dispose();
}