/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;

import mediac.util.WebService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class MTabbedPane extends JTabbedPane{

ArrayList<String> history;
int count = 0;
public MFrame frame;

 public MTabbedPane(MFrame frame){
 super(JTabbedPane.TOP,JTabbedPane.SCROLL_TAB_LAYOUT);
 this.frame = frame;
 
 JButton plus = new JButton("+");
 plus.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e){
  int tab_count = getTabCount();
  addService("",tab_count-1);
  setSelectedIndex(tab_count-1);
  }});
 
 history = new ArrayList<String>();
 history.add("http://www.mediac.com");
 history.add("http://www.fractis.com");
 history.add("http://www.google.com");
 history.add("http://www.facebook.com");
 history.add("http://www.yahoo.com");
 history.add("http://www.gmail.com");
 history.add("http://mail.yahoo.fr");
 history.add("http://www.hotmail.fr");
 history.add("http://localhost/home");
 
 addService("http://localhost/home");
 insertTab(null,null,null,null,1);
 setTabComponentAt(1,plus);
 
 
 addPropertyChangeListener(new PropertyChangeListener(){
 public void propertyChange(PropertyChangeEvent e){
 if(getTabCount() == 1)
  System.exit(0);
 }});
 
 }

 public void addService(final String url){
 count += 1;
 int tab_count = getTabCount();
  WebService service = new WebService(url,history,MTabbedPane.this);
  
  TabPanel tab = new TabPanel(MTabbedPane.this);
  
  Thread thread = new Thread(service,"T"+count);
  
  service.setThread(thread);
  
  thread.start();
  
  insertTab(null,null,service,null,tab_count);
  
  setTabComponentAt(tab_count,tab);
  Thread th = Thread.currentThread();
  System.out.println(th.getName());
  }
  
  public void addService(String url,int index){
  count += 1;
  WebService service = new WebService(url,history,MTabbedPane.this);
  
  TabPanel tab = new TabPanel(MTabbedPane.this);
  
  Thread thread = new Thread(service,"T"+count);
  
  service.setThread(thread);
  
  thread.start();
  
  insertTab(null,null,service,null,index);
  
  setTabComponentAt(index,tab);
  
  }
  
}