/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;


import javax.swing.*;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Shape;
import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.event.*;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import java.awt.Color;
import java.awt.geom.RoundRectangle2D;
import java.awt.GridLayout;
import java.util.Arrays;
import com.sun.awt.AWTUtilities;
import java.awt.FlowLayout;

/**
*@author NKOT YOGO GUY THOMAS
*@see mediac.gui.WebRegion
**/
public final class MFrame extends JFrame{
JPanel root,panel;
JPanel bar;
JPanel bar1,bar2;
GraphicsDevice carteGraph;
JLabel title;
Color borderColor = new Color(0,102,255,255);
boolean max = false;
protected int x;
protected int y;
protected int xi;
protected int yi;
int larg = 0;
int haut = 0;

 public MFrame(String titre){
  super(titre);
  setUndecorated(true);
  setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
  larg = (int)((18*screen.width)/20);
  haut = (int)((9*screen.height)/10);
  setLocation((screen.width - larg)/2,(screen.height - haut)/2);
  setSize(larg,haut);
  
    ImageIcon icon16 = new ImageIcon(MFrame.class.getResource("../src/img/i16.png"));
	ImageIcon icon32 = new ImageIcon(MFrame.class.getResource("../src/img/i32.png"));
	ImageIcon icon48 = new ImageIcon(MFrame.class.getResource("../src/img/i48.png"));
    setIconImages(Arrays.asList(icon16.getImage(),icon32.getImage(),icon48.getImage()));
	root = new JPanel();
    title = new JLabel(titre);
    title.setForeground(Color.WHITE);
    panel = new JPanel();
    getContentPane().add(panel);
    doFrame();
    setBordered();
  }
   public void setBordered(){
   panel.setBorder(BorderFactory.createLineBorder(borderColor,4));
   }
   public void doFrame(){
    Shape shape = new RoundRectangle2D.Double(0,0,larg,haut,10,10);
    AWTUtilities.setWindowShape(this,shape);
	carteGraph = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
	/*** bouttun de fermeture **/
	final MBButton close = new MBButton("x");
	close.setToolTipText("Fermer");
    close.setForeground(Color.RED);

    close.addMouseListener(new MouseAdapter(){
    public void mouseEntered(MouseEvent e1){
    close.setForeground(Color.WHITE);
    }
    public void mouseExited(MouseEvent e2){
    close.setForeground(Color.RED);
    }
    public void mousePressed(MouseEvent e){
    System.exit(0);
    }});
	
	final MBButton reduire = new MBButton("<");
	reduire.setForeground(Color.WHITE);
    reduire.setToolTipText("R�duire");
    reduire.addMouseListener(new MouseAdapter(){
    public void mouseEntered(MouseEvent e1){
    reduire.setForeground(Color.RED);
    }
    public void mouseExited(MouseEvent e2){
    reduire.setForeground(Color.WHITE);
    }
    public void mousePressed(MouseEvent e){
    setExtendedState(JFrame.ICONIFIED);
    }
   });
	
final MBButton agrandir = new MBButton("+");
agrandir.setToolTipText("Agrandir");
agrandir.setForeground(Color.WHITE);
agrandir.addMouseListener(new MouseAdapter(){
public void mouseEntered(MouseEvent e1){
agrandir.setForeground(Color.RED);
}
public void mouseExited(MouseEvent e2){
agrandir.setForeground(Color.WHITE);
}
public void mousePressed(MouseEvent e){

if(!max){
maximum();
agrandir.setToolTipText("Niveau Inferieur");
setShape2();
}
else{
agrandir.setToolTipText("Agrandir");
minimum();
setShape2();
}
}});
    
	bar = new JPanel();

	bar1 = new JPanel();
	bar1.setBackground(borderColor);
	bar1.setLayout(new FlowLayout(FlowLayout.LEFT));
	JLabel icon = new JLabel(new ImageIcon(MFrame.class.getResource("../src/img/i16.png")));
	bar1.add(icon);
	bar1.add(title);
	
	bar2 = new JPanel();
	bar2.setLayout(new FlowLayout(FlowLayout.RIGHT));
	bar2.setBackground(borderColor);
	bar2.add(close);
	bar2.add(agrandir);
	bar2.add(reduire);
	
	 bar.setLayout(new GridLayout(1,2));
	 bar.setBackground(borderColor);
	 bar.add(bar1);
	 bar.add(bar2);
	 bar.addMouseListener(new MouseAdapter(){
     public void mousePressed(MouseEvent e){
	  if(!max){
       Point point = e.getPoint();
       xi = (int)point.getX();
       yi = (int)point.getY();
	   } 
	    else{
		//ignore
		}
	 }
	 });
	   
	bar.addMouseMotionListener(new MouseMotionAdapter(){
    public void mouseDragged(MouseEvent e){
	if(!max){
     int cx = e.getXOnScreen();
     int cy = e.getYOnScreen();
     x = cx-xi;
     y = cy-yi;
     setLocation(x,y);
	 }
	  else{
	   //ignore
	   }
     }});
	
	panel.setLayout(new BorderLayout());
	panel.add(BorderLayout.NORTH,bar);
	panel.add(BorderLayout.CENTER,root);
	}
  public void setShape2(){
   Shape shape = new RoundRectangle2D.Double(0, 0, larg, haut, 10, 10);
   AWTUtilities.setWindowShape(this, shape); 
   }
  public void setFullScreen(){
   carteGraph.setFullScreenWindow(this);
   }
  public JPanel getPane(){
   return root;
   }
  public void setTitleLabel(String text){
  title.setText(text);
  this.setTitle(text);
  }
  public void setOpaq(float opacity){
  this.setOpacity(opacity);
  }
  
  public void maximum(){
  max = true;
  this.setExtendedState(JFrame.MAXIMIZED_BOTH);
  Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
  larg = getSize().width;
  haut = getSize().height - 20;
  setSize(larg,haut);
  System.gc();
  }
  
  public void minimum(){
  max = false;
  Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
  larg = (int)((18*screen.width)/20);
  haut = (int)((9*screen.height)/10);
  setLocation((screen.width - larg)/2,(screen.height - haut)/2);
  setSize(larg,haut);
  System.gc();
  }
  
  public void full(boolean st){
   if(st){
        if (carteGraph.isFullScreenSupported()) {
		panel.remove(bar);
		panel.setBorder(BorderFactory.createLineBorder(new Color(255,255,255,255),1));
        setFullScreen();
        }
	    else{
	    maximum();
	    }
   }
       else{
	   panel.add(BorderLayout.NORTH,bar);
	   setBordered();
	   carteGraph.setFullScreenWindow(null);
	   minimum();
	   System.gc();
	   }
  }
  
  public void setBorderColor(Color color){
  borderColor = color;
  setBordered();
  bar1.setBackground(borderColor);
  bar2.setBackground(borderColor);
  bar.setBackground(borderColor);
  }
  
  
}