/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;

import javax.swing.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.*;
import java.awt.*;

public class FloatOption extends JDialog{
JPanel root;
 public FloatOption(MFrame frame){
 super(frame,false);
 Dimension dim = frame.getSize();
 Point location = frame.getLocation();
 int x = location.x+10;
 int y = location.y + 100;
 
 int width = dim.width / 10;
 int height = 4*dim.height/5;
 setUndecorated(true);
 setOpacity(0.6f);
 setSize(width,height);
 setLocation(x,y);
 root = new JPanel();
 root.setBackground(Color.WHITE);
  getContentPane().setLayout(new BorderLayout());
  JPanel bar = new JPanel();
  bar.setLayout(new FlowLayout(FlowLayout.RIGHT));
  final MBButton close = new MBButton("x");
  close.setFont(new Font("Arial",Font.BOLD,18));
  close.setForeground(Color.WHITE);
  close.setToolTipText("Cacher");
  close.addMouseListener(new MouseAdapter(){
    public void mouseEntered(MouseEvent e1){
    close.setForeground(Color.RED);
    }
    public void mouseExited(MouseEvent e2){
    close.setForeground(Color.WHITE);
    }
    public void mousePressed(MouseEvent e){
    dispose();
    }});
  bar.setBackground(new Color(0,102,255,255));
  bar.add(close);
  
  root.setBorder(BorderFactory.createLineBorder(new Color(0,102,255,255),2));
  getContentPane().add(BorderLayout.NORTH,bar);
  getContentPane().add(BorderLayout.CENTER,root);
  
  setVisible(true);
  }

  public JPanel getPane(){
  return root;
  }
}