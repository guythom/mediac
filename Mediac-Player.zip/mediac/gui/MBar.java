package mediac.gui;

import javax.swing.*;
import java.awt.*;

public class MBar extends JPanel{
   
   public MBar(){
      setFocusable(true);
      setRequestFocusEnabled(true);
      enableEvents(AWTEvent.FOCUS_EVENT_MASK);
      enableEvents(AWTEvent.KEY_EVENT_MASK);
      enableEvents(AWTEvent.MOUSE_EVENT_MASK);
      setLayout(new FlowLayout(FlowLayout.LEFT,1,1));
      setBackground(new Color(150,150,150));
     
   }
}