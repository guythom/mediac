/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

package mediac.gui;

import javafx.scene.layout.Region;
import javafx.scene.web.WebView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;

 public class WebRegion extends Region{
 WebView brouteur = null;
 
 public WebRegion(WebView brouteur){
   this.brouteur = brouteur;
   getStyleClass().add("brouteur");
   getChildren().add(brouteur);
 }

	private Node createSpacer() {
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        return spacer;
    }
 
    @Override protected void layoutChildren() {
        double w = getWidth();
        double h = getHeight();
        layoutInArea(brouteur,0,0,w,h,0, HPos.CENTER, VPos.CENTER);
    }
 
    @Override protected double computePrefWidth(double height) {
        return 700;
    }
 
    @Override protected double computePrefHeight(double width) {
        return 700;
    }
}