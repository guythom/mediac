/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;

import mediac.util.WebService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class TabPanel extends JPanel{

private JAnimatedIcon iconLab;
private TabButton close;
private MTabbedPane root;
private WebService service;

 public TabPanel(MTabbedPane rootGet){
 super();
 if(rootGet == null)
 return;
 this.root = rootGet;
 setBackground(Color.WHITE);
 close = new TabButton();
 close.addActionListener(new ActionListener(){
 public void actionPerformed(ActionEvent e){
 dispose();
 }
 });
    setOpaque(false);
    File fichier = new File("_tab.gif");
    iconLab = new JAnimatedIcon(fichier.getAbsolutePath(),10000);
    iconLab.setColorKeyTransparency(Color.WHITE,0.9f);
    iconLab.reDimension(16,16);
    setText("Onglet vide");
	setLayout(new BorderLayout());
	add("West",iconLab);
	add("East",close);
	
	setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));
	setPreferredSize(new Dimension(200,20));
	
  addMouseListener(new MouseAdapter(){
  public void mousePressed(MouseEvent e){
  set();
  }
  public void mouseClicked(MouseEvent e){
  set();
  }});
  
  }
 
  public void setIcon(String icone,int milli){
  iconLab.setImages(icone);
  iconLab.reDimension(16,16);
  iconLab.setColorKeyTransparency(Color.WHITE,0.1f);
  iconLab.setAnimRate(milli);
  iconLab.restart();
  //System.gc();
   }
   
  public void setText(String title){
  String text = "";
  if(title.length() > 30)
   text  = title.toLowerCase().substring(0,27)+"...";
    else 
     text = title.toLowerCase();
     iconLab.setText(text);
	 iconLab.setToolTipText(title);
   }
   
  public void setLoading(){
  iconLab.setImages(JAnimatedIcon.readGifImages("loading.gif"));
  iconLab.reDimension(16,16);
  iconLab.setColorKeyTransparency(Color.WHITE,0.1f);
  iconLab.setAnimRate(300);
  iconLab.restart();
  setText("Chargement");
  //System.gc();
  }
  
  public void setDafaulIcon(){
  setIcon("_tab.gif",10000);
  }
	public void clean(){
	 iconLab = null;
	 close = null;
	}
 public void dispose(){
  int index = root.indexOfTabComponent(TabPanel.this);
   if(index == -1){
    System.out.println("index = -1");
	return;
	}
    service = (WebService)root.getComponentAt(index);
    service.kill();
    root.remove(index);
	if(index == 0)
	root.setSelectedIndex(0);
	else
	root.setSelectedIndex(index - 1);
    service = null;
	System.gc();
    }
  
  public void setClosable(boolean closable){
   if(closable){
    close.setVisible(true);
    }
     else{
      close.setVisible(false);
	  }
   }
   
   public WebService getService(){
   int index = root.indexOfTabComponent(TabPanel.this);
   if(index == -1){
    System.out.println("index = -1");
	return null;
	}
    service = (WebService)root.getComponentAt(index);
    return service;
    }
	
public void set(){
int index = root.indexOfTabComponent(TabPanel.this);
root.setSelectedIndex(index);
}

}