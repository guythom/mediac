/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

package mediac.gui;

import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;
import javax.swing.text.PlainDocument;

public class MPlainDocument extends PlainDocument {
 
	private final ArrayList<String> dictionary;
 
	private final JTextComponent _textField;
	private final MComboBox comboBox;
 
	public MPlainDocument(MComboBox combo,JTextComponent field, ArrayList<String> dictionary) {
	    comboBox = combo;
		_textField = field;
		this.dictionary = dictionary;
	}
	
	@Override
	public void insertString(int offs, String str, AttributeSet a)
			throws BadLocationException {
		super.insertString(offs, str, a);
		String word = autoComplete(getText(0, getLength()));
		if (word != null) {
			super.insertString(offs + str.length(), word, a);
			 
			 //dictionary.set(0,_textField.getText());
			 //comboBox.list();
			_textField.setFocusable(true);
			_textField.requestFocus();
			_textField.setCaretPosition(offs + str.length());
			_textField.moveCaretPosition(getLength());
			
		}
	}

      public String autoComplete(String text) {
		for (Iterator<String> i = dictionary.iterator(); i.hasNext();) {
			String word = i.next().toLowerCase();
			String temp = text.toLowerCase();
			if (word.startsWith(temp)) {
				return word.substring(text.length());
			}
		}
		return null;
      }

}