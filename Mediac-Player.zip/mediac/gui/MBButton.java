package mediac.gui;

import java.awt.*;
import javax.swing.ImageIcon;
import java.awt.Font;

public class MBButton extends javax.swing.JButton{

public MBButton(String text){
	super(text);
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setFont(new Font("arial",Font.BOLD,16));
 }
 
 public MBButton(ImageIcon icon){
	super(icon);
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setFont(new Font("arial",Font.BOLD,16));
 }
 
 
}