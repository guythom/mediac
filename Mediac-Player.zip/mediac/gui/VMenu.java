package mediac.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;

public class VMenu extends JPanel implements MouseListener,MouseMotionListener{

int max_srtWidth = 0;
int max_strHeight = 0;
int x_start = 0;
int y_start = 0;
boolean hover = false;

int px = 0;
int py = 0;

protected String label = "";

JPopupMenu popup = new JPopupMenu();
//JList<Object> list = new JList<Object>();

ArrayList<VMenuItem> itemList = new ArrayList<VMenuItem>();
GeneralItemMouseListener generalItemMouseListener;

protected GradientPaint back_gradient = new GradientPaint(0, getHeight(),new Color(50,120,50), getWidth(), 50, new Color(0,255,255));
protected GradientPaint text_gradient = new GradientPaint(0, 10,new Color(0,255,10), 100, 20, new Color(255,255,255));

protected GradientPaint back_gradienth = new GradientPaint(0, getHeight(),new Color(51,102,255,255), getWidth(), 50, new Color(0,100,240));

protected GradientPaint text_gradienth = new GradientPaint(0, 10,new Color(0,240,5), 100, 20, new Color(200,200,200));

protected Color textColor = new Color(255,255,255);
protected Color backColor = new Color(51,102,255,255);

protected boolean isGradText = true;
protected boolean isGradBack = true;

protected Font font = new Font("Agency FB",Font.BOLD,18);
    
	 
    public int getStringWidth(){
	return max_srtWidth;
	}
     
	public int getStringHeight(){
	return max_strHeight;
	}
	
	
	public VMenu(String label){
	this.label = label;
	updateSize();
	popup.setInvoker(this);
	setFocusable(true);
        setRequestFocusEnabled(true);
        enableEvents(AWTEvent.FOCUS_EVENT_MASK);
        enableEvents(AWTEvent.KEY_EVENT_MASK);
        enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	    addMouseListener(this);
  
  generalItemMouseListener = new GeneralItemMouseListener();
  
  popup.setForeground(new Color(51,102,255,255));
  popup.setBackground(Color.WHITE);
  //popup.setBorder(BorderFactory.createTitledBorder("*********"));
  
    repaint();
	}
	
	public void addItem(VMenuItem item){
	itemList.add(item);
	item.addMouseListener(generalItemMouseListener);
	popup.removeAll();
	popup.setLayout(new GridLayout(itemList.size(),1));
	   for(Iterator i = itemList.iterator();i.hasNext();){
	   popup.add((VMenuItem)i.next());
	   }
	}
	
	private class GeneralItemMouseListener extends MouseAdapter{
	
     public void mousePressed(MouseEvent e){
     popup.setVisible(false);
     }
  
	}
	
	public String getText(){
	return label;
	}
	
	public void setText(String newLabel){
	label = newLabel;
	updateSize();
	repaint();
	}
	
	public void updateSize(){
	
	 AffineTransform trans = font.getTransform();
     FontRenderContext render = new FontRenderContext(trans,true,true);
	 if(render == null)
	 System.exit(0);
     Rectangle2D rect = font.getStringBounds(label,render);
	 
	 max_srtWidth = (int)rect.getWidth() + 20;
	 max_strHeight = font.getSize()+ (font.getSize()/20) + 1;
	 
	 x_start = (max_srtWidth - (int)rect.getWidth())/2;
	 y_start = ((int)rect.getHeight() - max_strHeight )/2;
	 
	 y_start = max_strHeight - (2*((int)rect.getHeight() - max_strHeight)) + y_start;
	 
	 max_strHeight = max_strHeight - ((int)rect.getHeight() - max_strHeight);
	 
	}
    
	
	
	public Font getFont(){
	return font;
	}
	
	public void setForeground(Color textColor){
	this.textColor = textColor;
	repaint();
	}
	
	public void setBackground(Color backColor){
	this.backColor = backColor;
	repaint();
	}
	
	public void paintComponent(Graphics g){
	
	setPreferredSize(new Dimension(max_srtWidth,max_strHeight));
	Graphics2D g2d = (Graphics2D)g;
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	
	if(hover){
      //g2d.setColor(backColor);
	  //g2d.fillRect(5,0,max_srtWidth,max_strHeight);
      g2d.setColor(textColor);
	  g2d.drawString(label,x_start,y_start);
	  }
	   else{
        //g2d.setColor(new Color(150,150,150));
	    //g2d.fillRect(5,0,max_srtWidth,max_strHeight);
        g2d.setColor(textColor);
	    g2d.drawString(label,x_start,y_start);
	   }
	   
	}
	
	

	
	public void mouseClicked(MouseEvent e){
	
	}

    public void mousePressed(MouseEvent e){
	hover = true;
	repaint();
	int xmouse = e.getXOnScreen();
	int ymouse = e.getYOnScreen();
	int xloc = e.getX();
	int yloc = e.getY();
	px = xmouse - xloc + 5;
	py = ymouse - yloc + max_strHeight;
	popup.setLocation(px,py);
	popup.setVisible(true);
	}
	
        public void mouseReleased(MouseEvent e){
	
	    }

    public void mouseEntered(MouseEvent e){
	hover = true;
	repaint();
	int xmouse = e.getXOnScreen();
	int ymouse = e.getYOnScreen();
	int xloc = e.getX();
	int yloc = e.getY();
	px = xmouse - xloc + 5;
	py = ymouse - yloc + max_strHeight;
	popup.setLocation(px,py);
	popup.setVisible(true);
	}

    public void mouseExited(MouseEvent e){
	hover = false;
    repaint();
	}
	
	public void mouseDragged(MouseEvent e){
	
	}

    public void mouseMoved(MouseEvent e){
	
	}


}
