/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;


import javax.swing.*;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Shape;
import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.event.*;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Color;
import java.awt.Font;
import java.awt.geom.RoundRectangle2D;
import java.awt.GridLayout;
import java.util.Arrays;
import com.sun.awt.AWTUtilities;
import java.awt.FlowLayout;

/**
*@author NKOT YOGO GUY THOMAS
*@see mediac.gui.WebRegion
**/
public class NFrame extends JFrame{
JPanel root,panel;
JPanel bar;
JPanel bar1,bar2;
Insets insets;
GraphicsDevice carteGraph;
GraphicsConfiguration graphConfig;
Dimension screen;
Toolkit toolkit;
JLabel title;
Color borderColor = new Color(0,80,80,255);
boolean max = false;
boolean recovryMode = false;
protected int x;
protected int y;
protected int xi;
protected int yi;
int larg = 0;
int haut = 0;

 public NFrame(String titre){
  super(titre);
  carteGraph = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
  graphConfig = carteGraph.getDefaultConfiguration();
  toolkit = Toolkit.getDefaultToolkit();
  updateScreenDim();
  setUndecorated(true);
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  
  larg = (int)((18*screen.width)/20);
  haut = (int)((9*screen.height)/10);
  setLocation((screen.width - larg)/2,(screen.height - haut)/2);
  setSize(larg,haut);
    ImageIcon icon16 = new ImageIcon(NFrame.class.getResource("../src/img/i16.png"));
	ImageIcon icon32 = new ImageIcon(NFrame.class.getResource("../src/img/i32.png"));
	ImageIcon icon48 = new ImageIcon(NFrame.class.getResource("../src/img/i48.png"));
    setIconImages(Arrays.asList(icon32.getImage(),icon16.getImage()));
	root = new JPanel();
    title = new JLabel(titre);
    title.setForeground(Color.WHITE);
	title.setFont(new Font("calibri",Font.BOLD,12));
    panel = new JPanel();
    getContentPane().add(panel);
    doFrame();
    setBordered();
  }
  
  public void updateScreenDim(){
  screen = toolkit.getScreenSize();
  insets = toolkit.getScreenInsets(graphConfig);
  
  if(insets.bottom > 0)
	screen.height -= insets.bottom;
	
  if(insets.top > 0)
	screen.height -= insets.top;
  
  if(insets.left > 0)
	screen.width -= insets.left;
	
  if(insets.right > 0)
	screen.width -= insets.right;
  
  }
  
	public int getScreenWidth(){
		return screen.width;
	}
	public void setBordered(){
		panel.setBorder(BorderFactory.createLineBorder(borderColor,2));
	}
	
	public void doFrame(){
    Shape shape = new RoundRectangle2D.Double(0,0,larg,haut,10,10);
    AWTUtilities.setWindowShape(this,shape);
	
	/*** bouttun de fermeture **/
		final FrameButton close = new FrameButton(new ImageIcon(NFrame.class.getResource("../src/img/f1.png")),new ImageIcon(NFrame.class.getResource("../src/img/f2.png")),"Fermer");
	
		close.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		System.exit(0);
		}});
	
	/*** bouttun  reduire **/
		final FrameButton reduire = new FrameButton(new ImageIcon(NFrame.class.getResource("../src/img/m1.png")),new ImageIcon(NFrame.class.getResource("../src/img/m2.png")),"Réduire");
	
		reduire.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		setExtendedState(JFrame.ICONIFIED);
		}});
	
	/*** bouttun agrandir **/
		final FrameButton agrandir = new FrameButton(new ImageIcon(NFrame.class.getResource("../src/img/p1.png")),new ImageIcon(NFrame.class.getResource("../src/img/p2.png")),"Agrandir");

		agrandir.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			if(!max){
				maximum();
				agrandir.setToolTipText("Niveau Inferieur");
				setShape2();
				}
			else{
				agrandir.setToolTipText("Agrandir");
				minimum();
				setShape2();
				}
		}});
		
		final FrameButton recovry = new FrameButton(new ImageIcon(NFrame.class.getResource("../src/img/r1.png")),new ImageIcon(NFrame.class.getResource("../src/img/r2.png")),"Mode Mini Space");
		recovry.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		if(!recovryMode){
			recovryMode = true;
			String text = title.getText();
			title.setFont(new Font("calibri",Font.PLAIN,8));
			title.setText((text.length()<50)?text:text.substring(0,46)+"...");
			larg = 450;
			haut = 200;
			//setLocation((screen.width - larg),(screen.height - haut));//en bas a droite
			setLocation((screen.width - larg)-25,25);
			setSize(larg,haut);
			agrandir.setEnabled(false);
			setAlwaysOnTop(true);
			recovry();
			
		}
		else{
		String text = getTitle();
		title.setFont(new Font("calibri",Font.BOLD,12));
		//title.setText((text.length()<60)?text:text.substring(0,56)+"...");
		title.setText(text);
		setAlwaysOnTop(false);
		recovryMode = false;
		minimum();
		agrandir.setEnabled(true);
		recovry();
		}
		}});
		
	VMenu fichier = new VMenu("FICHIER");
	VMenuItem quitter = new VMenuItem("QUITTER");
	fichier.addItem(quitter);
	
	bar = new JPanel();

	bar1 = new JPanel();
	bar1.setBackground(borderColor);
	bar1.setLayout(new FlowLayout(FlowLayout.LEFT));
	JLabel icon = new JLabel(new ImageIcon(NFrame.class.getResource("../src/img/i25.png")));
	bar1.add(icon);
	bar1.add(title);
	//bar1.add(fichier);
	
	bar2 = new JPanel();
	bar2.setLayout(new FlowLayout(FlowLayout.RIGHT));
	bar2.setBackground(borderColor);
	
	bar2.add(recovry);
	bar2.add(reduire);
	bar2.add(agrandir);
	bar2.add(close);
	
	 bar.setLayout(new GridLayout(1,2));
	 bar.setBackground(borderColor);
	 bar.add(bar1);
	 bar.add(bar2);
	 bar.addMouseListener(new MouseAdapter(){
     public void mousePressed(MouseEvent e){
	  if(!max){
       Point point = e.getPoint();
       xi = (int)point.getX();
       yi = (int)point.getY();
	   } 
	 }});
	   
	bar.addMouseMotionListener(new MouseMotionAdapter(){
    public void mouseDragged(MouseEvent e){
	if(!max){
     int cx = e.getXOnScreen();
     int cy = e.getYOnScreen();
     x = cx-xi;
     y = cy-yi;
     setLocation(x,y);
	 }
	  
     }});
	
	panel.setLayout(new BorderLayout());
	panel.add(BorderLayout.NORTH,bar);
	panel.add(BorderLayout.CENTER,root);
	}
	
  public void setShape2(){
   Shape shape = new RoundRectangle2D.Double(0, 0, larg, haut, 10, 10);
   AWTUtilities.setWindowShape(this, shape); 
   }
  public void setFullScreen(){
   carteGraph.setFullScreenWindow(this);
   }
  public JPanel getPane(){
   return root;
   }
  public void setTitleLabel(String text){
  if(!recovryMode){
	title.setText(text);
	this.setTitle(text);
  }
  else{
	title.setText((text.length()<40)?text:text.substring(0,36)+"...");
	this.setTitle(text);
  }
  }
  
  public void setOpaq(float opacity){
  this.setOpacity(opacity);
  }
  
  public void maximum(){
  max = true;
  this.setExtendedState(JFrame.MAXIMIZED_BOTH);
  
  /**if(insets.bottom > 0)
	haut = getSize().height - insets.bottom;
  if(insets.top > 0)
	haut = getSize().height - insets.top;
  if(insets.left > 0)
	larg = getSize().width - insets.left;
  if(insets.right > 0)
	larg = getSize().width - insets.right;**/
  updateScreenDim();
  larg = screen.width;
  haut = screen.height;
  setSize(larg,haut);
  }
  
  public void minimum(){
  max = false;
  larg = (int)((18*screen.width)/20);
  haut = (int)((9*screen.height)/10);
  setLocation((screen.width - larg)/2,(screen.height - haut)/2);
  setSize(larg,haut);
  }
  
  
  public void full(boolean st){
   if(st){
        if (carteGraph.isFullScreenSupported()) {
		panel.remove(bar);
		panel.setBorder(BorderFactory.createLineBorder(new Color(255,255,255,255),1));
        setFullScreen();
        }
	    else{
	    maximum();
	    }
   }
       else{
	   panel.add(BorderLayout.NORTH,bar);
	   setBordered();
	   carteGraph.setFullScreenWindow(null);
	   maximum();
	   }
  }
  
  public void setBorderColor(Color color){
  borderColor = color;
  setBordered();
  bar1.setBackground(borderColor);
  bar2.setBackground(borderColor);
  bar.setBackground(borderColor);
  }
  
  public void addMenuBar(JPanel mbar){
  bar1.add(mbar);
  bar1.updateUI();
  }
  
  public void recovry(){
  }
  
  
}