/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
package mediac.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TabButton extends JButton{

        protected void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D)g.create();
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if(getModel().isPressed())
                g2.translate(1, 1);
            g2.setStroke(new BasicStroke(3F));
            g2.setColor(new Color(255, 51, 10, 255));
            if(getModel().isRollover())
                g2.setColor(Color.RED);
            int delta = 5;
            g2.drawLine(delta, delta, getWidth() - delta - 1, getHeight() - delta - 1);
            g2.drawLine(getWidth() - delta - 1, delta, delta, getHeight() - delta - 1);
            g2.dispose();
        }

        public TabButton()
        {
            super();
            int size = 17;
            setPreferredSize(new Dimension(size, size));
            setToolTipText("Fermer Cet Onglet");
            setUI(new javax.swing.plaf.basic.BasicButtonUI());
            setContentAreaFilled(false);
            setFocusable(false);
			setBackground(new Color(255,255,255,255));
            setBorder(BorderFactory.createBevelBorder(0,new Color(140,255,255,255),new Color(0,153,255,200)));
            setBorderPainted(false);
            setRolloverEnabled(true);
			addMouseListener(new MouseAdapter(){
  public void mouseEntered(MouseEvent e){
   setBorderPainted(true);
   setContentAreaFilled(true);
   }
  public void mouseExited(MouseEvent e){
   setBorderPainted(false);
   setContentAreaFilled(false);
   }
   });
   
        }
    }