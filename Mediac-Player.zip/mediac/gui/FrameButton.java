package mediac.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import java.awt.Font;

public class FrameButton extends javax.swing.JButton{

ImageIcon icone1 = null;
ImageIcon icone2 = null;

public FrameButton(String text){
	super(text);
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setFont(new Font("arial",Font.BOLD,16));
	setFocusable(false);
    setRequestFocusEnabled(false);
 }
 
 public FrameButton(ImageIcon i1,ImageIcon i2,String toolTip){
	super(i1);
	icone1 = i1;
	icone2 = i2;
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setToolTipText(toolTip);
	setFocusable(false);
    setRequestFocusEnabled(false);
		addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e1){
			setIcon(icone2);
			}
			public void mouseExited(MouseEvent e2){
			setIcon(icone1);
			}
		});
 }
 
 
}