import javax.swing.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.awt.event.*;
import java.util.ArrayList;

public class VMenuItem extends JPanel implements MouseListener,MouseMotionListener{

protected String label = "";
JLabel lab;

protected Color textColor = new Color(255,255,255);//(150,150,150);
protected Color backColor = new Color(50,50,50);//(0,50,250,255);

protected Font font = new Font("Agency FB",Font.PLAIN,22);
	
	public VMenuItem(String label){
	this.label = label;
	lab = new JLabel("");
	    lab.setText("  "+label);
		setLayout(new BorderLayout());
        enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	    addMouseListener(this);
		setPreferredSize(new Dimension(300,15));
        setFor(backColor);
	    setBackground(textColor);
		lab.setFont(font);
		setOpaque(true);
        add("West",lab);
		setFocusable(false);
        setRequestFocusEnabled(false);
	}
	
	public String getText(){
		return label;
	}
	
	public void setText(String newLabel){
		label = newLabel;
		lab.setText(label);
	}
	
	public void setFor(Color textColor){
		lab.setForeground(textColor);
	}
	
	public void mouseClicked(MouseEvent e){}

    public void mousePressed(MouseEvent e){
		click();
	}
	
    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){
	setFor(textColor);
	setBackground(backColor);
	}

    public void mouseExited(MouseEvent e){
	setFor(backColor);
	setBackground(textColor);
	}
	
	public void mouseDragged(MouseEvent e){
	
	}

    public void mouseMoved(MouseEvent e){
	
	}
	
	public void click(){
	
	}
	
}
