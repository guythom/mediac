import javax.swing.*;
import java.awt.*;
import java.beans.*;
import java.awt.event.*;
import java.util.*;

public class Dial extends JComponent{
int minValue,value,maxValue,radius;

	public Dial(){
	this(0,100,0);
	}

	public Dial(int minValue,int maxvalue,int value){
	this.maxValue = maxValue;
	this.minValue = minValue;
	this.value = value;
	setForeground(new Color(102,102,200));
		addMouseListener(new MouseAdapter(){
		public void mousePressed(MouseEvent e){
		spin(e);
		}
		});
		
		addMouseMotionListener(new MouseMotionAdapter(){
		public void mouseDragged(MouseEvent e){
		spin(e);
		}
		});
	}
	
	protected void spin(MouseEvent e){
		int y = e.getY();
		int x = e.getX();
		double th = Math.atan((1.0*y - radius)/(x - radius));
		int value = ((int)(th/(2*Math.PI)*(maxValue - minValue)));
		if(x < radius)
			setValue(value + maxValue/2);
		else if(y < radius)
			setValue(value + maxValue);
		else
			setValue(value);
	}
	
	public void paintComponent(Graphics g){
	Graphics2D g2d = (Graphics2D)g;
	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	int tick = 1 ; // le pas 
	radius = getSize().width /2 - tick;
	g2d.setPaint(getForeground().darker());
	g2d.drawLine(radius*2 + tick/2,radius,radius*2 + tick,radius);
	g2d.setStroke(new BasicStroke(2));
	draw3DCircle(g2d,0,0,radius,true);
	int knobRadius = radius/7;
	double th = value *(2*Math.PI)/(maxValue - minValue);
	int x = (int)(Math.cos(th)*(radius - knobRadius*3)),
	y = (int)(Math.sin(th)*(radius - knobRadius*3));
	g2d.setStroke(new BasicStroke(1));
	draw3DCircle(g2d,x+radius-knobRadius,y+radius-knobRadius,knobRadius,false);
	
	}
	
	private void draw3DCircle(Graphics g,int x,int y,int radius,boolean raised){
	Color foreground = getForeground();
	Color light = foreground.brighter();
	Color dark = foreground.darker();
	g.setColor(foreground);
	g.fillOval(x,y,radius*2,radius*2);
	g.setColor(raised?light:dark);
	g.drawArc(x,y,radius*2,radius*2,45,180);
	g.setColor(raised?dark:light);
	g.drawArc(x,y,radius*2,radius*2,225,180);
	}
	
	public Dimension getPreferredSize(){
		return new Dimension(100,100);
	}
	
	
	public void setValue(int value){
	firePropertyChange("value",this.value,value);
	this.value = value;
	repaint();
	fireEvent();
	}
	
	public int getValue(){ return value; }
	public void setMinimum(int minValue){ this.minValue = minValue;}
	public int getMinimum(){return minValue;}
	public void setMaximum(int maxValue){this.maxValue = maxValue;}
	public int getMaximum(){return maxValue;}
	
	public void addDialListener(DialListener listener){
	listenerList.add(DialListener.class,listener);
	}
	
	public void removeDialListener(DialListener listener){
	listenerList.remove(DialListener.class,listener);
	}
	
	void fireEvent(){
	Object[] listeners = listenerList.getListenerList();
		for(int i = 0; i < listeners.length;i+= 2)
		  if(listeners[i] == DialListener.class)
			((DialListener)listeners[i + 1]).dialAdjusted(new DialEvent (this,value));
	}

	/***************************** class DialEvent **************************/
	
	public class DialEvent extends java.util.EventObject{
		int value;
		
		DialEvent(Dial source,int value){
			super(source);
			this.value = value;
		}
		
		public int getValue(){
		return value;
		}
	}
	
	public interface DialListener extends java.util.EventListener{
		void dialAdjusted(DialEvent e);
	}
	
	public static void main(String[]args){
	JFrame frame = new JFrame("Un composant special");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setSize(400,400);
	
	final JLabel statut = new JLabel("Valeur : 0");
	Dial dial = new Dial();
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
	//panel.setPreferredSize(new Dimension(400,400));
	panel.add(new JLabel("-----------"));
	panel.add(dial);
	panel.add(statut);
	//frame.getContentPane().add(new JLabel("-----------"),BorderLayout.NORTH);
	frame.getContentPane().add(panel);
	//frame.getContentPane().add(statut,BorderLayout.SOUTH);
	dial.addDialListener(new DialListener(){
	public void dialAdjusted(DialEvent e){
	statut.setText("Valeur : " + e.getValue());
	}});
	
	frame.setVisible(true);
	
	
	}



}