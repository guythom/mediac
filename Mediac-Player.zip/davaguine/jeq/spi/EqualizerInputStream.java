
package davaguine.jeq.spi;

import davaguine.jeq.core.IIRControls;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.IOException;


public class EqualizerInputStream extends AudioInputStream {
    private davaguine.jeq.core.EqualizerInputStream eq;

  
    public EqualizerInputStream(AudioInputStream stream, int bands) {
        super(stream, stream.getFormat(), stream.getFrameLength());
        AudioFormat format = stream.getFormat();
        if (!format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED) && !!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED))
            throw new IllegalArgumentException("Unsupported encoding");
        eq = new davaguine.jeq.core.EqualizerInputStream(stream,
                format.getSampleRate(),
                format.getChannels(),
                format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED),
                format.getSampleSizeInBits(),
                format.isBigEndian(),
                bands);
    }//frameLength = AudioSystem.NOT_SPECIFIED;
	
	public EqualizerInputStream(AudioFormat format, int bands) {
	super(null, format, AudioSystem.NOT_SPECIFIED);
        if (!format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED) && !!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED))
            throw new IllegalArgumentException("Unsupported encoding");
        eq = new davaguine.jeq.core.EqualizerInputStream(format.getSampleRate(),
                format.getChannels(),
                format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED),
                format.getSampleSizeInBits(),
                format.isBigEndian(),
                bands);
    }

   
    public IIRControls getControls() {
        return eq.getControls();
    }

    public static boolean isParamsSupported(AudioFormat format, int bands) {
        if (!format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED) && !!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED))
            return false;
        return davaguine.jeq.core.EqualizerInputStream.isParamsSupported(
                format.getSampleRate(),
                format.getChannels(),
                format.getSampleSizeInBits(),
                bands);
    }

   
    public int available() throws IOException {
        return eq.available();
    }

  
    public void close() throws IOException {
        eq.close();
    }

    public synchronized void mark(int readlimit) {
        eq.mark(readlimit);
    }

   
    public boolean markSupported() {
        return eq.markSupported();
    }

   
    public int read() throws IOException {
        return eq.read();
    }

    
    public int read(byte b[]) throws IOException {
        return read(b, 0, b.length);
    }
	
	public byte[] filter(byte[] data){
	return eq.filter(data);
	}
	
	public byte[] filter(int[]data){
	return eq.filter(data);
	}
	
	public int[] getInt(){
	return eq.getInt();// on renvoi le  buffer int traite
	}
	
	public int[] getInteger(byte[] data){
	return eq.getInteger(data);// on transforme le buffer des octects en buffer des entiers
	}

    
    public int read(byte[] b, int off, int len) throws IOException {
        return eq.read(b, off, len);
    }

   
    public void reset() throws IOException {
        eq.reset();
    }

  
    public long skip(long n) throws IOException {
        return eq.skip(n);
    }
}
