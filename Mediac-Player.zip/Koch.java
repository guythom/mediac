
import java.awt.Color;
import java.awt.Graphics;


public class Koch {
	//Repr�sente le nombre de fois que l'on rep�te les formules de Koch
	int iteration;
	//Tableau de couleurs
    Color colorWheel[];
    //Indice du tableau de couleur
    int colorIdx;
    //Angle 1
    double x;
    //Angle 2
	double y;
	 

	    public Koch()
	    {
	    	//Instancie le tableau de 800 couleurs et instancie l'indice � 0
	        colorWheel = new Color[800];
	        colorIdx = 0;
	        //On fixe les angles 1 et 2 � 120� et � 160�
	        x = 120;
	        y = 160;
	       
	    }


	    public void kochcurve(Graphics g, int iteration, double d, double d1)
	    {
	        //En fonction de la valeur de l'angle "d" {-120,0,120}�
	    	//et en lui appliquant un modulo de lui-m�me
	    	d %= 360;
	        //On lui enl�ve 360�
	        if(d > 180)
	        	d -= 360;
	        //On lui ajoute 360�
	        if(d < -180)
	        	d += 360;
	        	        
	        if(iteration == 1)
	        {
	            //D�finition des coordonn�es avec des formules utilisant des angles et des
	        	// cosinus et sinus  avec d1 qui varie
	        	double d2 = (d * 3.1415926535897931) / 180;
	            double d3 = x + d1 * Math.cos(d2);
	            double d4 = y + d1 * Math.sin(d2);
	            //Dessine une ligne avec 2 points d�finis par les coordonn�es (x,y) et (d3,d4)
	            // de couleur fix� par le tableau de couleur et son indice
	            g.setColor(colorWheel[colorIdx]);
	            g.drawLine((int)x, (int)y, (int)d3, (int)d4);
	            //On red�finit x et y
	            x = d3;
	            y = d4;
	          //Permet de d�finir l'indice du tableau de couleur pour cr�er un d�grad� de couleur
	            if(++colorIdx >= 800)
	            	colorIdx = 0;
	        } 
	        else
	        {
	            //Permet de dessiner le motif de Koch sur chaque segment en fonction 
	        	// de l'angle de segment et du nombre d'it�ration
	        	kochcurve(g, iteration - 1, d, d1 / 3);
	        	kochcurve(g, iteration - 1, d - 60, d1 / 3);
	            kochcurve(g, iteration - 1, d + 60, d1 / 3);
	            kochcurve(g, iteration - 1, d, d1 / 3);
	        }
	    }

	  //Permet de modifier l'attribut it�ration
	    public void setIteration(int it)
	    {
	    	this.iteration = it;
	    }

}
