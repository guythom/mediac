/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
import java.awt.event.*;
import java.util.concurrent.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import uk.co.caprica.vlcj.component.EmbeddedMediaPlayerComponent;

public class PlayerMouseListener{

 
}