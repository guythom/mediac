public Polygon vdessus(){
	Polygon vd = new Polygon();
	/**************************  VUE DE DESSUS **************************************/
	    vd.addPoint(150,50);
        vd.addPoint(250,50);
		vd.addPoint(200,100);
	    vd.addPoint(100,100); 
	return vd;
	}
	
	public Polygon vface(){
	Polygon vf = new Polygon();
	/*************************VUE DE FACE *************************/
        vf.addPoint(200,100);
        vf.addPoint(200,200);
        vf.addPoint(100,200);
        vf.addPoint(100,100);
	return vf;
	}
    
	public Polygon vdroite(){
	Polygon vd = new Polygon();
	/*************************VUE DE DROITE ********************************/
		vd.addPoint(200,100);
		vd.addPoint(250,50);
		vd.addPoint(250,150);
		vd.addPoint(200,200);
    return vd;
	}