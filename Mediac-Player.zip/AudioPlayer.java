/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.BooleanControl;
import javax.sound.sampled.TargetDataLine;
import javax.sound.sampled.AudioInputStream;

import uk.co.caprica.vlcj.player.MediaPlayer;
import uk.co.caprica.vlcj.player.MediaMeta;
import uk.co.caprica.vlcj.player.MediaPlayerEventListener;
import uk.co.caprica.vlcj.player.directaudio.DirectAudioPlayer;
import uk.co.caprica.vlcj.binding.internal.libvlc_media_t;

import davaguine.jeq.spi.EqualizerInputStream;
import davaguine.jeq.core.IIRControls;

import com.sun.jna.Pointer;

/**import org.apache.commons.math3.transform.DftNormalization;
import org.apache.commons.math3.transform.TransformType;
import org.apache.commons.math3.transform.FastFourierTransformer;
import org.apache.commons.math3.complex.Complex;**/
import java.util.Date;
import java.util.Timer;
import java.util.Arrays;
import java.util.Scanner;
import java.util.TimerTask;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public final class AudioPlayer extends MediacPlayer{

private int BLOCK_SIZE = 4;              // Block de 4 echantillons
private int SAMPLE_BITS = 16;           // echantillons de 16 bits
private float RATE = 44100.0f;         // Frequence d'echantillonage 44.1 KHz
private boolean BIGENDIAN = false;
private int CHANNELS = 2;            // Stereo si 1 bon effet

protected AudioFormat format;     // format audio
protected SourceDataLine line;  // ligne audio (carte son)
protected SourceDataLine mic_line_play;
protected SourceDataLine mic_line_effect;
protected SourceDataLine loc_line; // temporaire pour les effets
protected TargetDataLine mic_line;
protected AudioInputStream mic_input;
protected AudioInputStream eq_input;
protected AudioBuffer audioBuffer;
protected EqualizerInputStream eq;
protected IIRControls eq_control;
protected JPanel internalRoot;

protected byte[] datas = new byte[1024];
protected byte[] mic_datas = new byte[1024];
protected int[] samples = new int[1024];
protected float[] frames = new float[32];
protected short[] amp = null;
protected FloatControl panControl = null;
protected FloatControl balControl = null;
protected FloatControl gainControl = null;
protected FloatControl volControl = null;
protected BooleanControl muteControl = null;

protected float pane = 0.0f;
protected float bal = 0.0f;
protected float gain = 0.0f;
protected float vol = 0.5f;
protected float frequence = 44100.0f;
protected float levelCountL = 0.0f;
protected float levelCountR = 0.0f;


protected int effect_id = 0;
protected int mic_effect_id = 0;
protected int state = 0;
protected int updateCount = 0;
protected int volume = 100;
protected int voix = 3;
protected int ech_count = 0;
protected int time = 1;//duree des echantillons audio ou duree du son tout simplement
//protected int N = 1;//Nombre total d'echantillons
protected long remixDelay = -1;
protected long remixStartedTime = 0;
protected long remixDelayCount = 0;

protected boolean mic_play = false;
protected boolean newEffect = false;
protected boolean micEffect = false;
protected boolean first = true;
protected boolean effect = false;
protected boolean rateChange = false;
protected boolean setVol = true;
protected boolean audio = false;
protected boolean anim = false;
protected boolean mute = false;
protected boolean equalize = true;
protected boolean remix = false;
protected boolean remixHasStart = false;
protected boolean isOverInternalRoot = true;
protected boolean stopLoop = false;

int toRemove = 400;
int sc = 0;

//STANDARD implique la formule mathematique standard || UNITARY la methode unitaire
//final DftNormalization norme = DftNormalization.valueOf("STANDARD");
//FORWARD pour la transformee || INVERSE pour la transformee inverse
//final TransformType type = TransformType.valueOf("FORWARD");
//final FastFourierTransformer fft = new FastFourierTransformer(norme);

protected Thread MicPlayer = null;
Thread threadVolumeEffect = null;
private int id = 0;


	protected void mute(boolean mute){
	if(muteControl != null)
		muteControl.setValue(mute);
	else return;
	}
	public void muteIf(){
		mute = (mute)?false:true;
		mute(mute);
	}
    public float getPane(){
	if(panControl != null)
	      return panControl.getValue();
	        else return 0.0f;
    }
	/** -1 : 1**/
	public void setPane(float pane){
	if(panControl != null){
	  panControl.setValue(pane);
	  pane = pane;
	  }
	    else return;
	}
    
	public void setGain(float gain){
	if(gainControl != null){
	    gainControl.setValue(gain);
		this.gain = gain;
		}
	     else return;
	}
	
	public float getGain(){
	if(gainControl != null)
	   return gainControl.getValue();
	     else return 0.0f;
	}
	
	public void setVol(float vol){
	if(volControl != null){
	    volControl.setValue(vol);
		this.vol = vol;
		}
	}
	
	public float getVol(){
	if(volControl != null)
	  return volControl.getValue();
	    else return 0.0f;
	}
	
	public void setBal(float bal){
	if(balControl != null){
	   balControl.setValue(bal);
	   this.bal = bal;
	   }
	    else return;
	}
	
	public float getBal(){
	if(balControl != null)
	  return balControl.getValue();
	    else return 0.0f;
	}
	
	public void stream(String path){
		cancelRemix();
		getMediaPlayer().playMedia(path,
            formatRtpStream("230.0.0.1", 4444),
            ":no-sout-rtp-sap",
            ":no-sout-standard-sap",
            ":sout-all",
            ":sout-keep"
        );
	}
	public String formatRtpStream(String serverAddress, int serverPort){
		StringBuilder sb = new StringBuilder(60);
        sb.append(":sout=#rtp{dst=");
        sb.append(serverAddress);
        sb.append(",port=");
        sb.append(serverPort);
        sb.append(",mux=ts}");
        return sb.toString();
	
	}
	
	public float getPreampValue(int canal){
	return eq_control.getPreampValue(canal);//-12dB 12 dB
	}
	
	public void setPreampDbValue(int canal,float value){
	eq_control.setPreampDbValue(canal,value);
	}
	
	public float getBandValue(int band, int canal) {
    return eq_control.getBandValue(band,canal);
    }
	
	public void setBandValue (int band,int canal,float value){
	eq_control.setBandValue(band,canal,value);
	}
	
	
	public synchronized void setAudioMode(boolean mode){
	audio = mode;
	}
	public synchronized void setAnimMode(boolean mode){
	anim = mode;
	}

	public synchronized void setRate(float rate){
	if(effect) return;
	   frequence = rate;
	   effect_id = 1;
       newEffect = true;
	}
	
	
	public synchronized float getRate(){
	if(effect)
	 return 0.0f;
	     else return frequence;
	}
	
	public void setId(int i){
	id = i;
	}
	public int getId(){
	return id;
	}
	
       public void init() throws Exception {
		format = new AudioFormat(RATE,SAMPLE_BITS,CHANNELS,true,BIGENDIAN);
	    line = AudioSystem.getSourceDataLine(format);
		eq = new EqualizerInputStream(format, 31);
		eq_control = eq.getControls();
		mic_line_play = AudioSystem.getSourceDataLine(format);
		Info infos = new Info(TargetDataLine.class,format);
		//mic_line = (TargetDataLine) AudioSystem.getLine(infos);
		//mic_input = new AudioInputStream(mic_line);
		MicPlayer = new Thread(new Runnable(){
            public void run(){
            startMicPlayer();
            }
        });
	   }
	   
	public AudioPlayer(){
	super("S16N",44100,2);
	try{
		init();
		line.open(format);
		line.start();
		audioBuffer = new AudioBuffer(line,this);
	}
	catch(Exception e){
		e.printStackTrace();
		javax.swing.JOptionPane.showMessageDialog(null,new JLabel("Votre carte audio/pilote semble incompatible avec Mediac Player"),"Erreur",javax.swing.JOptionPane.ERROR_MESSAGE);
		state = -1;
	}
	
	createInternalControl();
	}
	
	public void play(String path){
	cancelRemix();
	getMediaPlayer().playMedia(path);
	}
	
	public void play(String path,String option){
	cancelRemix();
	getMediaPlayer().playMedia(path,option);
	}
	
	public void stop(){
	getMediaPlayer().stop();
	}
	
	public void setTime(long time){
	getMediaPlayer().setTime(time);
	}
	
	public void prepare(String path){
	getMediaPlayer().prepareMedia(path);
	}
	
	public void setNum(int playerId){
	setPlayerId(playerId);
	}
	
	public boolean canPause(){
	return getMediaPlayer().canPause();
	}
	
	public void play(){
		cancelRemix();
		getMediaPlayer().play();
	}
	
	public void pause(){
		getMediaPlayer().pause();
	}
	
	public boolean isPlayable(){
	return getMediaPlayer().isPlayable();
	}
	
	public boolean isPlaying(){
	return getMediaPlayer().isPlaying();
	}
	
	public void setVolume(int vol){
	volume = (vol >= 15)?vol:15;
	getMediaPlayer().setVolume(volume);
	}
	
	public int getVolume(){
	return volume;
	}
	
	public MediaMeta getMediaMeta(){
	return getMediaPlayer().getMediaMeta();
	}
	
	public void setPosition(float pos){
	getMediaPlayer().setPosition(pos);
	}
	
	public float getPosition(){
	return getMediaPlayer().getPosition();
	}
	
	public long getTime(){
	return getMediaPlayer().getTime();
	}
	
	public long getLength(){
	return getMediaPlayer().getLength();
	}
	
	public void setMarqueeText(String marq){
	getMediaPlayer().setMarqueeText(marq);
	}
	
	public void setMarqueeSize(int size){
	getMediaPlayer().setMarqueeSize(size);
	}
	
	public void setMarqueeOpacity(int op){
	getMediaPlayer().setMarqueeOpacity(op);
	}
	
	public void setMarqueeColour(Color color){
	getMediaPlayer().setMarqueeColour(color);
	}
	
	public void setMarqueeTimeout(int time){
	getMediaPlayer().setMarqueeTimeout(time);
	}
	
	public void setMarqueeLocation(int x, int y){
	getMediaPlayer().setMarqueeLocation(x,y);
	}
	
	public void enableMarquee(boolean bol){
	getMediaPlayer().enableMarquee(bol);
	}
	
	public void setCropGeometry(String crop){
	getMediaPlayer().setCropGeometry(crop);
	}
	
	public String getCropGeometry(){
	return getMediaPlayer().getCropGeometry();
	}
	
	public void setRepeat(boolean rep){
	getMediaPlayer().setRepeat(rep);
	}
	
	public boolean getRepeat(){
	return getMediaPlayer().getRepeat();
	}
	
	public void setScale(float factor){
	getMediaPlayer().setScale(factor);
	}
	
	public void setAspectRatio(String aspectRatio){
		getMediaPlayer().setAspectRatio(aspectRatio);
	}
	public boolean isSeekable(){
	return getMediaPlayer().isSeekable();
	}
	
	public void addMediaPlayerEventListener(MediaPlayerEventListener mediaListener){
	getMediaPlayer().addMediaPlayerEventListener(mediaListener);
	}
	
	public SourceDataLine makeLine(float RATE,int SAMPLE_BITS,int CHANNELS,boolean BIGENDIAN){
	SourceDataLine newLine = null;
	 try{
	  AudioFormat format = new AudioFormat(RATE,SAMPLE_BITS,CHANNELS,true,BIGENDIAN);
	  newLine = AudioSystem.getSourceDataLine(format);
	  newLine.open(format);
	  newLine.start();
	  }
	    catch(Exception e){
		newLine = line;
		}

	    return newLine;
	}
	
	protected synchronized SourceDataLine getMic_line_play(){
	if(micEffect){
	switch(mic_effect_id){
	           case 0:
			   mic_line_effect = makeLine(44100,16,2,false);
			   micEffect = false;
			   break;
	           case 1:
			   mic_line_effect = makeLine(50000,16,2,false);//Bad Bass man
			   micEffect = false;
			   break;
			   case 2:
			   /** Si la frequencee est grande lq voix devient plus aigue si on dimunie elle de vient grave**/
			   mic_line_effect = makeLine(70000,8,2,false);//-------------------Bon  Robot effect on peut modifier la frequence
			   micEffect = false;
			   break;
			   case 3:
			   mic_line_effect = makeLine(44100,16,1,false);
			   micEffect = false;
			   break;
			   case 4:
			   mic_line_effect = makeLine(44100,8,1,false);
			   micEffect = false;
			   break;
			   default:
			   mic_line_effect = mic_line_play;
			   micEffect = false;
			   break;
	 }}
	 return mic_line_effect;
	}
	
	public void updateControl(){
    panControl = null;
    balControl = null;
    gainControl = null;
    
	 if(line.isControlSupported(FloatControl.Type.MASTER_GAIN)){
				  gainControl = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
				  gainControl.setValue(gain);
				   }
				        if(line.isControlSupported(FloatControl.Type.PAN)){
					        panControl = (FloatControl) line.getControl(FloatControl.Type.PAN);
							panControl.setValue(pane);
					         }
					                 if(line.isControlSupported(FloatControl.Type.BALANCE)){
					                   balControl = (FloatControl) line.getControl(FloatControl.Type.BALANCE);
									   balControl.setValue(bal);
					                    }
										    if(line.isControlSupported(FloatControl.Type.VOLUME)){
					                            volControl = (FloatControl) line.getControl(FloatControl.Type.VOLUME);
									            volControl.setValue(vol);
					                             }
	if(line.isControlSupported(BooleanControl.Type.MUTE)){
		muteControl = (BooleanControl)line.getControl(BooleanControl.Type.MUTE);
		muteControl.setValue(mute);
	}
										
										
	 }
	
	public float getLevel(){
		return line.getLevel();
	}
	
	/** On annule la voix droite**/
	public void vgauche(){
	  for(int i = 4; i < datas.length; i += 4){
	  datas[i-4] = 0;
	  datas[i-3] = 0;
	  }
	}
	
	/** On annule  la void droite**/
	public void vdroite(){
	  for(int i = 4; i < datas.length; i += 4){
	  datas[i-2] = 0;
	  datas[i-1] = 0;
	  }
	}
	
	public synchronized int[] getSamples(){
		return samples;
	}
	
	@Override
    public void play(DirectAudioPlayer mediaPlayer, Pointer samples, int sampleCount, long pts) {
		int bufferSize = sampleCount * BLOCK_SIZE;
		byte[] data = samples.getByteArray(0, bufferSize);
	
		if(equalize)
			datas = eq.filter(data);
		else 
			datas = data;
		if(remix){
			audioBuffer.add(datas);
			remixDelayCount++;
		}
		setAudioDatas(datas,eq,equalize);
		
	    if(first){
			time = (int)mediaPlayer.getLength()/1000;
			setVolume(volume);
			first = false;
		}
        line.write(datas, 0, datas.length);
		if(remixDelay == remixDelayCount){
			audioBuffer.mix();
			remixHasStart = true;
		}
		
    }
	
	public void nextFrame(){
		getMediaPlayer().nextFrame();
	}
	public long getAudioDelay(){
		return getMediaPlayer().getAudioDelay();
	}
	
	public float getFps(){
		return getMediaPlayer().getFps();
	}
	   
	@Override
    public void mediaChanged(MediaPlayer mediaPlayer, libvlc_media_t media, String mrl){
	setVol = true;
	first = true;
    }

    @Override
    public void opening(MediaPlayer mediaPlayer) {
	setVol = true;
    }

    @Override
    public void buffering(MediaPlayer mediaPlayer, float newCache) {
	setVol = true;
    }

    @Override
    public void playing(MediaPlayer mediaPlayer) {
		setVol = true;
		if(state == -1)
			getMediaPlayer().stop();
		updateControl();							
    }

    @Override
    public void paused(MediaPlayer mediaPlayer) {
	
    }
    @Override
    public void stopped(MediaPlayer mediaPlayer) {
		line.flush();
    }

    @Override
    public void forward(MediaPlayer mediaPlayer) {
    }

    @Override
    public void backward(MediaPlayer mediaPlayer) {
    }

    @Override
    public void finished(MediaPlayer mediaPlayer) {
	setVol = true;
	first = true;
    }

    @Override
    public void timeChanged(MediaPlayer mediaPlayer, long newTime) {
    }

    @Override
    public void positionChanged(MediaPlayer mediaPlayer, float newPosition) {
    }

    @Override
    public void seekableChanged(MediaPlayer mediaPlayer, int newSeekable) {
    }

    @Override
    public void pausableChanged(MediaPlayer mediaPlayer, int newPausable) {
    }

    @Override
    public void titleChanged(MediaPlayer mediaPlayer, int newTitle) {
    }

    @Override
    public void snapshotTaken(MediaPlayer mediaPlayer, String filename) {
    }

    @Override
    public void lengthChanged(MediaPlayer mediaPlayer, long newLength) {
    }

    @Override
    public void videoOutput(MediaPlayer mediaPlayer, int newCount) {
    }

    @Override
    public void error(MediaPlayer mediaPlayer) {
	
    }

    @Override
    public void mediaMetaChanged(MediaPlayer mediaPlayer, int metaType) {
    }

    @Override
    public void mediaSubItemAdded(MediaPlayer mediaPlayer, libvlc_media_t subItem) {
    }

    @Override
    public void mediaDurationChanged(MediaPlayer mediaPlayer, long newDuration) {
    }

    @Override
    public void mediaParsedChanged(MediaPlayer mediaPlayer, int newStatus) {
    }

    @Override
    public void mediaFreed(MediaPlayer mediaPlayer) {
    }

    @Override
    public void mediaStateChanged(MediaPlayer mediaPlayer, int newState) {
    }

    @Override
    public void newMedia(MediaPlayer mediaPlayer) {
	first = true;
    }

    @Override
    public void subItemPlayed(MediaPlayer mediaPlayer, int subItemIndex) {
    }

    @Override
    public void subItemFinished(MediaPlayer mediaPlayer, int subItemIndex) {
	first = true;
    }

    @Override
    public void endOfSubItems(MediaPlayer mediaPlayer) {
    }

    @Override
    public void pause(DirectAudioPlayer mediaPlayer, long pts) {
		if(!remixHasStart)
			line.flush();
    }

    @Override
    public void resume(DirectAudioPlayer mediaPlayer, long pts) {
    }

    @Override
    public void flush(DirectAudioPlayer mediaPlayer, long pts) {
    }

    @Override
    public void drain(DirectAudioPlayer mediaPlayer) {
    }
	
   public synchronized void magic_mic(int id){
   mic_effect_id = id;
   micEffect = true;
   }
   
   public synchronized byte[] getDatas(){
   return datas;
   }
   
   public void startMicPlayer(){
	   if(mic_line == null) return;
   try{
        mic_line.open();
        mic_line.start();
	    mic_line_play.open(format);
	    mic_line_play.start();
		mic_line_effect = mic_line_play;
		mic_play = true;
	       while(mic_play){
		   mic_input.read(mic_datas);
		   getMic_line_play().write(mic_datas,0,mic_datas.length);
		   }
		    
	  }
	    catch(Exception e){
		} finally{
		    try{
			 mic_line.close();
			 mic_input.close();
			 getMic_line_play().close();
			 }
			  catch(Exception e){
			  }
		  }	 
   }
   
    public void playMic(){
		if(!MicPlayer.getState().equals("NEW")){
		   MicPlayer = new Thread(new Runnable(){
				public void run(){
					startMicPlayer();
				}
		   });
		}
		MicPlayer.start();
    }
   
   public void stopMic(){
		synchronized(AudioPlayer.class){
			mic_play = false;
		}
   }
   
   public void activeMic(){
   if(!mic_play)
		playMic();
   else stopMic();
   }
   
   public void shutdownVolume(){
		threadVolumeEffect = new Thread(){
			public void run(){
				for(int i = getVolume(); i > 14; i--){
					setVolume(i);
					try{
						threadVolumeEffect.sleep(100);
					}catch(Exception e){}
				}
			}
		};
		threadVolumeEffect.start();
   }
   
	public void turnOnVolume(final int maxVolume){
		threadVolumeEffect = new Thread(){
			public void run(){
				int current = getVolume();
				for(int i = 15; i < maxVolume+1; i++){
					setVolume(i);
					try{
						threadVolumeEffect.sleep(100);
					}catch(Exception e){}
				}
			}
		};
		threadVolumeEffect.start();
   }
   
   public void createInternalControl(){
   InternalButton play = new InternalButton(InternalButton.BUTTON_PLAY,30,30);
   InternalButton stop = new InternalButton(InternalButton.BUTTON_STOP,30,30);
   InternalButton mute = new InternalButton(InternalButton.BUTTON_MUTE,30,30);
   VolumeControl slide = new VolumeControl();
   internalRoot = new JPanel();
   internalRoot.setBackground(Color.BLACK);
   //internalRoot.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
   internalRoot.addMouseListener(new MouseAdapter(){
	public void mouseEntered(MouseEvent e){
	setIsOverInternalRoot(true);
	}
	public void mouseExited(MouseEvent e){
	setIsOverInternalRoot(false);
	}
	
	public void mouseReleased(MouseEvent e){
	   
	}
	});
   internalRoot.setOpaque(false);
   internalRoot.setLayout(new FlowLayout(FlowLayout.LEFT));
   internalRoot.add(mute);
   internalRoot.add(play);
   internalRoot.add(stop);
   internalRoot.add(slide);
   }
   
   public void showInternalControl(){
   //getCanvas().add("South",internalRoot);
   }
   
   public void hideInternalControl(){
   //if(!isOverInternalRoot())
   //getCanvas().remove(internalRoot);
   }
   
	public synchronized void remixNow(long delay){
		if(remix){
			cancelRemix();
			remix = false;
			remixDelay = -1;
		}
		else{
			remixDelay = delay;
			remix = true;
			remixDelayCount = 0;
		}
   }
   
   public synchronized void cancelRemix(){
   if(remix) remix = false;
   remixDelay = -1;
   audioBuffer.stopMix();
   remixHasStart = false;
   }
   
   public synchronized boolean isOverInternalRoot(){
   return isOverInternalRoot;
   }
   protected synchronized void setIsOverInternalRoot(boolean b){
   isOverInternalRoot = b;
   }
   
}