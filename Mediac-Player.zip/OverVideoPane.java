import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.sun.awt.AWTUtilities;
import com.sun.jna.platform.WindowUtils;

public class OverVideoPane extends JWindow{
protected JFrame binder;
protected JPanel panel;
protected MPanel bindPanel;
protected Player iplayer;
protected AudioPlayer mainPlayer;
protected  AudioPlayer player;
protected MediacPlayer.PlayerPane videoPane;
protected Thread transitor = null;
protected boolean isInAction = false;
protected boolean  stopTransition = false;
protected int x = 0;
protected int y = 0;
protected int w = 0;
protected int h = 0;

	public OverVideoPane(Player player){
		super(player.frame,WindowUtils.getAlphaCompatibleGraphicsConfiguration());
		AWTUtilities.setWindowOpaque(this, false);
		setFocusableWindowState(false);
        setType(Window.Type.POPUP);
		//try {
               //setAlwaysOnTop(true);
            //} 
		//catch (SecurityException se) {}
		
		this.player = player.Yplayer;
		bindPanel = player.playersContainer;
		binder = player.frame;
		mainPlayer = player.player;
		iplayer = player;
		videoPane = player.Ypane;
		
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		//panel.setOpaque(true);
		panel.setLayout(new BorderLayout());
		panel.setBorder(BorderFactory.createLineBorder(Color.WHITE,1));
		panel.add("Center",videoPane);
		setLayout(new BorderLayout());
		add("Center",panel);
		
		
		binder.addComponentListener(new ComponentAdapter(){
			public void componentMoved(ComponentEvent e){
				close();
				if(isInAction)
					open();
			}
			public void componentHidden(ComponentEvent e){
				close();
			}
			public void componentShow(ComponentEvent e){
				if(isInAction)
					open();
			}
			public void componentResized(ComponentEvent e){
				close();
				if(isInAction)
					open();
			}
		});
	}
	
	public void setIsInAction(boolean action){
		isInAction = action;
	}
	
	public void close(){
		setVisible(false);
	}
	
	public void open(){
		updateBounds();
		setVisible(true);
	}
	
	public void totalOpen(){
		Point p = bindPanel.getLocationOnScreen();
		w = bindPanel.getWidth();
		h = bindPanel.getHeight();
		x = p.x;
		y = p.y;
		setSize(new Dimension(w,h));
		setLocation(x,y);
	
	}
	
	public void activeTransition(){
	setSize(new Dimension(0,0));
	Point p = bindPanel.getLocationOnScreen();
	w = bindPanel.getWidth();
	h = bindPanel.getHeight();
	x = p.x;
	y = p.y;
	stopTransition = false;
		transitor = new Thread(){
			public void run(){
				player.setCropGeometry(iplayer.cropt[0]);
				while(true){
					int j = 1;
					for(int i = 1; i < w+1; i+=10){
						setSize(new Dimension(i,j));
						if(j < h)
							j += 10;
						try{
							transitor.sleep(100);
						}catch(Exception e){}
					}
					setSize(new Dimension(w/2,h/2));
					try{
						transitor.sleep(1000);
					}catch(Exception e){}
					
					synchronized(OverVideoPane.class){
						if(stopTransition){
						totalOpen();
							break;
						}
					}
				}
			}
		};
		transitor.start();
	
	}
	
	public synchronized void stopTransition(){
		stopTransition = true;
	}
	
	public void updateBounds(){
		Point p = bindPanel.getLocationOnScreen();
		w = bindPanel.getWidth();
		h = bindPanel.getHeight();
		x = p.x;
		y = p.y;
		setSize(new Dimension(w,h));
		setLocation(x,y);
	}
}