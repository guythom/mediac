/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2015 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

/**@author NKOT YOGO GUY THOMAS
*@see Mediac 1.0
**/
public class BitManip{

  public static int bitCount(long value){
    if(value == 0 || value == 1)
	   return 1;
	   int count = 0;
       long temp = value;
          while(true){
	      if(temp == 0)
	      break;
	      temp = temp >> 1;
	      count++;
	      }
	return count;
  }
  
  public static int bitCount(int value){
    if(value == 0 || value == 1)
	   return 1;
	   int count = 0;
       int temp = value;
          while(true){
	      if(temp == 0)
	      break;
	      temp = temp >> 1;
	      count++;
	      }
	return count;
  }
  
  /** la plus petite proche puissance de 2 **/
  public static int min2pow(int value){
  int bitCount = bitCount(value);
  return ( 1 << (bitCount - 1));
  }
  
  /** la plus grande proche puissance de 2 **/
  public static int max2pow(int value){
  int bitCount = bitCount(value);
  return ( 1 << bitCount);
  }
  
  /** la plus petite proche puissance de 2 **/
  public static long min2pow(long value){
  int bitCount = bitCount(value);
  return ( 1 << (bitCount - 1));
  }
  
  /** la plus grande proche puissance de 2 **/
  public static long max2pow(long value){
  int bitCount = bitCount(value);
  return ( 1 << bitCount);
  }
  
  /**  Inversion veritable au niveau des bits et non la negation comme avec l'operateur '~'*/
  public static int inverse(int value){
      int bitCount = bitCount(value);
      int mask_inverseur = (1 << bitCount) - 1;
      return (value ^ mask_inverseur);
  }
  
  public static long inverse(long value){
      int bitCount = bitCount(value);
      long mask_inverseur = (1 << bitCount) - 1;
	  return (value ^ mask_inverseur);
  }
  
    public static void main(String[]args){
	long nombre = Long.parseLong(args[0]);
	System.out.println(nombre + " possede " + bitCount(nombre) + " bits");
	System.out.println(" l'inverse de  " + nombre + " est " + inverse(nombre));
	System.out.println(" la plus petite proche puissance de 2 de " + nombre + " est " + min2pow(nombre));
	System.out.println(" la plus grande proche puissance de 2 de " + nombre + " est " + max2pow(nombre));
	}
}