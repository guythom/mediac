import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MList<E> extends JPanel{

	public MList(){
		super();
		setOpaque(false);
		enableEvents(AWTEvent.FOCUS_EVENT_MASK);
		enableEvents(AWTEvent.MOUSE_EVENT_MASK);
		enableEvents(AWTEvent.KEY_EVENT_MASK);
		setFocusable(true);
		setRequestFocusEnabled(true);
		
	}
	
	public void setFont(Font font){
	
	}
	
	public void setListData(Object [] e){
	
	}
	
	public void setForeground(Color foreground){
	
	}
	
	public void setBackground(Color background){
	
	}
	public int locationToIndex(Point point){
		return 0;
	}
	public void setSelectedIndex(int index){
	
	}
	public int [] getSelectedIndices(){
		return null;
	}

}