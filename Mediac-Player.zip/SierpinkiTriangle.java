

import java.awt.*;


public class SierpinkiTriangle {

	//Repr�sente le nombre de fois que l'on rep�te les formules de Sierpinki
	int iteration;
	//Tableau de couleurs
    Color colorWheel[];
    //Indice du tableau de couleur
    int colorIdx;
     
    
    public SierpinkiTriangle () {
    	//Instancie le tableau de 400 couleurs et instancie l'indice � 0
        colorWheel = new Color[400];
        colorIdx = 0; 
    }

    public void gasket(Graphics g, int iteration, int j, int haut, int larg, int haut2)
    {
        if(iteration == 1)
        {
        	//D�finition de la couleur fix�e par le tableau de couleur et son indice
        	g.setColor(colorWheel[colorIdx]);
            Polygon polygon = new Polygon();
            polygon.addPoint(j, haut);
            polygon.addPoint(j + larg, haut);
            polygon.addPoint(j + larg / 2, haut - haut2);
            //Dessine un polygone de 3 sommets d�finis auparavant donc un triangle 
            // avec une couleur d�finie auparavant
            g.fillPolygon(polygon);
            
            //Permet de d�finir l'indice du tableau de couleur pour cr�er un d�grad� de couleur
            if(++colorIdx >= 400)
              colorIdx = 0;
        } 
        else
        {
        	//On divise par 3 la hauteur et la largeur pour pouvoir dessiner 3 triangles
        	int largDiv = larg / 2;
            int hautDiv = haut2 / 2;
            //Permet de dessiner 3 triangles dans le triangle pr�c�demment dessin�
            gasket(g, (iteration - 1), j, haut, largDiv, hautDiv);
            gasket(g, (iteration - 1), j + largDiv / 2, haut - hautDiv, largDiv, hautDiv);
            gasket(g, (iteration - 1), j + largDiv, haut, largDiv, hautDiv);
          
        }
      
    }
    
    //Permet de modifier l'attribut it�ration
    public void setIteration(int it)
    {
    	this.iteration = it;
    }

}
