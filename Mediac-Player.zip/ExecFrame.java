import mediac.gui.NFrame;

public class ExecFrame{

	public static void main(String[]args){
	NFrame frame = new NFrame(" Hello ");
	frame.setVisible(true);
	
	
	
	}






}