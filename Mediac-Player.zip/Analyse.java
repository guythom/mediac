import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

public class Analyse extends JComponent{

protected byte[] samples = null;
protected short[] amp = new short[256];
protected float[] frames = null;
Complex[]c1 = new Complex[256];
SourceDataLine line;

protected String srcPath = "";
Color color = Color.WHITE;

    public Analyse(String srcPath){
    setBackground(Color.BLACK);
    this.srcPath = srcPath;
    loadSamples();
    }

static int j = 0;
public byte[] getSamples(){
  File src = new File(srcPath);
  long length = src.length();
  if(!src.exists() || length == 0) return null;
  byte[] samp = new byte[(int)length];
  try{
  BufferedInputStream buff = new BufferedInputStream(new FileInputStream(src));
  buff.read(samp,0,samp.length);
  buff.close();
  }
    catch(IOException e){
	System.out.println("Erreur lors du chargement des echantillons");
	}
    return samp;
}

public byte[] getSamples(String srcPath){
  File src = new File(srcPath);
  long length = src.length();
  if(!src.exists() || length == 0) return null;
  byte[] samp = new byte[(int)length];
  try{
  BufferedInputStream buff = new BufferedInputStream(new FileInputStream(src));
  buff.read(samp,0,samp.length);
  buff.close();
  }
    catch(IOException e){
	System.out.println("Erreur lors du chargement des echantillons");
	}
    return samp;
}

public static void saveSamples(byte[] samples,int index){
 if(samples.length <= 512){
 save(samples,"samples\\sample"+j+".samp");
 j++;
 }
  else{
  int col = 0;
  int total = samples.length;
  int last_length = total % 512;
  int dif = total - last_length;
  byte[] datas = new byte[512];
  
  if(dif == total){
   col = total / 512;
     for(int i = 0; i < col; i++){
     System.arraycopy(samples,i*512,datas,0,512);
     save(datas,"samples\\sample"+j+".samp");
	 j++;
     }
   }
     else{
     col = (dif / 512) + 1;
        for(int i = 0; i < col; i++){
		  if(i == (col - 1)){
		   datas = new byte[last_length];
		   System.arraycopy(samples,i*512,datas,0,last_length);
		   save(datas,"samples\\sample"+j+".samp");
		   j++;
		   }
		    else{
		    System.arraycopy(samples,i*512,datas,0,512);
			save(datas,"samples\\sample"+j+".samp");
			j++;
			}
		}
		
	 }
		
  //byte[][] datas = new byte[512][col];
  //"samples\\sample"+sc+".samp";

  }
}

public static void save(byte[] samples,String fileName){
try{
  BufferedOutputStream buff = new BufferedOutputStream(new FileOutputStream(fileName));
  buff.write(samples,0,samples.length);
  buff.flush();
  buff.close();
  }
   catch(IOException e){
   System.out.println("Erreur lors de la sauvegarde du fichier");
   }
}

    public void paintComponent(Graphics g){
     int width = getWidth();
	 int height = getHeight();
	 int x = (width - 512)/2;//10;//10 pixels en allant vers la droite
	 int yn = 0;
	 int y0 = height/2;// commencer le dessin 10 pixels apres la base en montant;
	 int ic = 0;
	 int ic2 = 0;
	      Graphics2D g2d = (Graphics2D)g;
		  g2d.setColor(Color.BLACK);
		  g2d.fillRect(0,0,width,height);
	      for(int i = 0; i < 256; i++){
		  x = (x >= width)?(width - 512)/2:x;
	      ic = 20;
		  ic2 = 255;
		  color = new Color(10,ic2,ic);
	      g2d.setColor(color);
		  yn = (int)(y0 - (frames[i] * height*50));
		  g2d.drawLine(x,y0,x,yn);
		  x += 2;
	      }

    }
	 
	public void loadSamples(){
	byte[] sm = getSamples();
    samples = (sm == null)?new byte[]{(byte)255,(byte)255}:sm;
	calculs();
	sm = null;
    }
	
    public void setSampleSource(String srcPath){
    this.srcPath = srcPath;
    loadSamples();
    calculs();
	repaint();
    }
    
	public void showTotal(final int count){
	Thread player = new Thread(new Runnable(){
	public void run(){
	//line = makeLine(44100,16,2,false);
	for(int i = 0; i < count; i++)//{
	//byte [] datas = getSamples("samples\\sample"+i+".samp");
	   //line.write(datas, 0, datas.length);
	   setSampleSource("samples\\sample"+i+".samp");
	//}
	  //wt();
	}});
	player.start();
	}
	public void wt(){
	try{
	  Thread.sleep(1000);
	  }catch(Exception e){}
	}
	
	public void calculs(){
	int z,t,j = 0;
	int echantillon = 0;
	     for(int i = 2; i < samples.length; i += 2){
	     z = samples[i-2];
	     t = samples[i-1];
		 echantillon = (((t & 0xFF) << 8)| ((z & 0xFF) << 0));	 
	     amp[j] = (short)(echantillon);//entier de 16 bits(taille des echantillons) avec signe
	     j++;
	     }
		 
		 for(int i = 0; i < 256; i++)
		 c1[i] = new Complex(amp[i],0.0);
		 
		 Complex[] spectre = FFT.fft(c1);
		 int N = spectre.length;
		 //int max = (int)(32767 * Math.cos(2*Math.PI*N)*N);//la plus grande valeur possible d'un echantillon
		 int max = 32767 * N;// on prend Math.cos(2*Math.PI*N) = 1 pour le max;
		 frames = new float[N];
		 for(int i = 0; i < N;i++)
		 frames[i] = (float)(spectre[i].re()/max);
		 
	}
	
	
	public void playSamples(final int count){
	Thread player = new Thread(new Runnable(){
	public void run(){
	   line = makeLine(44100,16,2,false);
	   for(int i = 0; i < count; i++){
	   byte [] datas = getSamples("samples\\sample"+i+".samp");
	   line.write(datas, 0, datas.length);
	   samples = datas;
	   repaint();
	  }}});
	player.start();
	}
	
    public static void main(String[]args){
    JFrame frame = new JFrame("Outil d'analyse de Fourier - NKOT YOGO");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setSize(700,400);
	frame.setLocationRelativeTo(null);
	    final String param = args[0];
	    final Analyse analyse = new Analyse("");
	    JPanel panel = new JPanel();
	    panel.setLayout(new BorderLayout());
		
	    final JTextField text = new JTextField(30);
	    JButton loadSource = new JButton("Charger cette source");
	    JButton playSamp = new JButton("Jouer la liste des echantillons");
	loadSource.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	analyse.setSampleSource(text.getText());
	}});
	playSamp.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	analyse.playSamples(Integer.parseInt(text.getText()));
	}});
	
	    JPanel ps = new JPanel();
	    ps.add(text);
	    ps.add(loadSource);
		ps.add(playSamp);

		panel.add("Center",analyse);
	    panel.add("South",ps);
	    
	
    frame.getContentPane().add(panel);
	frame.setVisible(true);
	SwingUtilities.invokeLater(new Runnable(){
	public void run(){
	analyse.setSampleSource(param);
	}});
	
    }
	
	public SourceDataLine makeLine(float RATE,int SAMPLE_BITS,int CHANNELS,boolean BIGENDIAN){
	SourceDataLine newLine = null;
	 try{
	  AudioFormat format = new AudioFormat(RATE,SAMPLE_BITS,CHANNELS,true,BIGENDIAN);
	  newLine = AudioSystem.getSourceDataLine(format);
	  newLine.open(format);
	  newLine.start();
	  }
	    catch(Exception e){
		newLine = line;
		}

	    return newLine;
	}



}