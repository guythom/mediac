/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.Point;
import java.awt.Component;
import java.io.IOException;
import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.TransferHandler;

@SuppressWarnings("serial")
public class PlayListTransferHandler extends TransferHandler {

    private Player player;
    private int removeIndex = -1;
    private final long ID;
	private Point tp = null;
	FileExtensionFilter mediacFilter; 
	
    public PlayListTransferHandler(Player player,long ID) {
        this.player = player;
        this.ID = ID;
		mediacFilter = new FileExtensionFilter(MediaUtil.allExtensions());
    }

    @Override
    public int getSourceActions(JComponent c) {
        return COPY_OR_MOVE;
    }
    
    @Override
    protected Transferable createTransferable(JComponent c) {
		if(!(c instanceof JList)) return null;
        JList list = (JList)c;
        int index = list.getSelectedIndex();
        if (index == -1) return null;
        String name = player.playerNameList.get(index);
		String path = player.playerPathList.get(index);
        removeIndex = index;
        return new ListItemSelection(name,path,ID);
    }
    
    @Override
    protected void exportDone(JComponent source,Transferable data, int action) {
        if (action == MOVE) {
            player.playerNameList.remove(removeIndex);
			player.playerPathList.remove(removeIndex);
			player.playList.setListData(player.playerNameList.toArray());
            removeIndex = -1;
			player.listPane.updateUI();
        }
    }
    
    @Override
    public boolean canImport(JComponent comp, DataFlavor[] transferFlavors) {
        List<DataFlavor> list=Arrays.asList(transferFlavors);
        return list.contains(ListItemSelection.listItemFlavor) ||
        list.contains(DataFlavor.javaFileListFlavor);
    }
    
	@Override
	public boolean importData(TransferSupport support){
	DropLocation location = support.getDropLocation();
	tp = location.getDropPoint();
	return imp((JComponent) support.getComponent(), support.getTransferable());
	}
    
    public boolean imp(JComponent comp, Transferable t) {
        int index = player.playList.getSelectedIndex();
        if (index == -1) {
            index = player.playerNameList.size() - 1;
        }
		
        if (t.isDataFlavorSupported(ListItemSelection.listItemFlavor)) {
            ListItem item;
			String oldPath = "";
			if(player.playerPathList.size() > player.index)
				oldPath = player.playerPathList.get(player.index);
            try {
                item = (ListItem) t.getTransferData(ListItemSelection.listItemFlavor);
            } catch (UnsupportedFlavorException e) {
                throw new AssertionError(e);
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
			
			if(!(comp instanceof JList)){
				if(player.multiPlayerMode){
					for(int i = 0; i < player.playerList.length;i++){
						if(player.playerList[i].getCanvas().containsPoint(tp.x,tp.y)){
							player.playerList[i].play(item.path);
						}
					}
				}
				return false;
			}
			
			else{
				//if (item.ID == this.ID && index <= removeIndex)
					//removeIndex++;
				player.playerNameList.remove(removeIndex);
				player.playerPathList.remove(removeIndex);
				
				player.playerNameList.add(index, item.name);
				player.playerPathList.add(index, item.path);
				
				player.playList.setListData(player.playerNameList.toArray());
				player.listPane.updateUI();
				player.index = player.getNewPlayingIndex(oldPath);
				player.playList.setSelectedIndex(player.index);
				return true;
			}
        }
		
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
		int size = player.playerNameList.size();
            if (removeIndex != -1) {
                throw new IllegalStateException("Operation en cours");
            }
			String oldPath = "";
			if(player.playerPathList.size() > player.index)
				oldPath = player.playerNameList.get(player.index);
				
            try {
				List fileList = (List)t.getTransferData(DataFlavor.javaFileListFlavor);
				for(Iterator i = fileList.iterator();i.hasNext();){
					File file = (File)i.next();
					if(file.isDirectory()){
						addDir(file);
					}
					else{
						player.playerNameList.add(file.getName());
						player.playerPathList.add(player.getWinEncodedPath(file));
					}
				}
				player.playList.setListData(player.playerNameList.toArray());
				player.listPane.updateUI();
				if(size != 0){
					player.index = player.getNewPlayingIndex(oldPath);
					player.playList.setSelectedIndex(player.index);
				}
				else{
					player.index = 0;
					player.play();
				}
				
            } catch (UnsupportedFlavorException e) {
                throw new AssertionError(e);
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
			return true;
        }
        return false;
    }
	
	public void addDir(File file){
	File[] list = file.listFiles(mediacFilter);
	if(list != null){
		for(int i = 0; i < list.length; i++){
			
			if(list[i].isDirectory()){
				addDir(list[i]);
			}
			else{
				player.playerNameList.add(list[i].getName());
				player.playerPathList.add(player.getWinEncodedPath(list[i]));
			}
		}
	}
	}
	
}
