/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

public class ListItemSelection implements Transferable {

    public static DataFlavor listItemFlavor=new DataFlavor(ListItem.class,"listItemFlavor");
	
    private final static DataFlavor[] supportedFlavors = new DataFlavor[] {listItemFlavor,DataFlavor.javaFileListFlavor};
    
    private ListItem item;
    
    public ListItemSelection(String name,String path,long ID) {
        this.item = new ListItem(name,path,ID);
    }
    
    @Override
    public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
        if (listItemFlavor.equals(flavor)) {
            return item;
        }
        if (DataFlavor.javaFileListFlavor.equals(flavor)) {
            return item;
        }
        throw new UnsupportedFlavorException(flavor);
    }

    @Override
    public DataFlavor[] getTransferDataFlavors() {
        return supportedFlavors;
    }

    @Override
    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return listItemFlavor.equals(flavor) || DataFlavor.javaFileListFlavor.equals(flavor);
    }
}
