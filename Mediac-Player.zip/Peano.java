
import java.awt.Color;
import java.awt.Graphics;

public class Peano {
	//Repr�sente le nombre de fois que l'on rep�te les formules d' Hilbert
	int iteration;
    //Angle 1
    double x;
    //Angle 2
    double y;
    //Tableau de couleurs
    Color colorWheel[];
    //Indice du tableau de couleur
    int colorIdx;
 
	
	public Peano (){
		//Instancie le tableau de 1024 couleurs et instancie l'indice � 0
		colorWheel = new Color[600];
		colorIdx = 0;
		
	}
	public void peano(Graphics g, int iteration, double larg, int j)
    {
        if(iteration == 1)
        {
        	//Angle temp 1
        	double d1 = x;
        	//Angle temp 2
            double d3 = y;
            //D�finition de la couleur fix�e par le tableau de couleur et son indice
            g.setColor(colorWheel[colorIdx]);
            //Suivant la valeur de j
            switch(j)
            {
            //On enl�ve � l'angle temp 2 la largeur
            case 0: 
                d3 -= larg;
                break;
             //On enl�ve � l'angle temp 1 la largeur
            case 1: 
                d1 += larg;
                break;
            //On enl�ve � l'angle temp 2 la largeur
            case 2: 
                d3 += larg;
                break;
            //On enl�ve � l'angle temp 1 la largeur
            case 3: 
                d1 -= larg;
                break;
            }
            //Dessine une ligne avec 2 points d�finis par les coordonn�es (x,y) et (d1,d3)
            g.drawLine((int)x, (int)y, (int)d1, (int)d3);
            //On red�finit x et y
            x = d1;
            y = d3;
            
          //Permet de d�finir l'indice du tableau de couleur pour cr�er un d�grad� de couleur
            if(++colorIdx >= 600)
            {
                colorIdx = 0;
            }
        } 
        else
        {
        	//On divise la largeur par 3 car il y a toujours un multiple de 3 segments 
        	double largDiv = larg / 3;
        	//Permet de dessiner le motif de Peano sur chaque segment en fonction 
        	// de l'angle de segment et du nombre d'it�ration
            peano(g, iteration - 1, largDiv, j);
            peano(g, iteration - 1, largDiv, (j + 3) % 4);
            peano(g, iteration - 1, largDiv, j);
            peano(g, iteration - 1, largDiv, (j + 1) % 4);
            peano(g, iteration - 1, largDiv, (j + 2) % 4);
            peano(g, iteration - 1, largDiv, (j + 1) % 4);
            peano(g, iteration - 1, largDiv, j);
            peano(g, iteration - 1, largDiv, (j + 3) % 4);
            peano(g, iteration - 1, largDiv, j);
            return;
        }
    }
	
	//Permet de modifier l'attribut it�ration
	public void setIteration(int it)
    {
    	this.iteration = it;
    }
}
