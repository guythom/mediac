 import java.awt.image.BufferedImage;
 import java.awt.Color;
 import java.awt.Font;
 import java.awt.RenderingHints;
 import java.awt.Graphics2D;
 import java.awt.Graphics;
 import java.awt.AlphaComposite;
 import java.util.Arrays;
 
 import java.awt.*;
 import javax.swing.*;
 
 import javax.swing.JComponent;
 
 public class MPanelPlayer extends JPanel{

   protected DirectPlayer player;
   
        
    public MPanelPlayer(String media,String [] args){
	
    player = new DirectPlayer(media,args,MPanelPlayer.this);
	}

          @Override
          public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D)g;
            g2.drawImage(player.image, 0, 0, getWidth(), getHeight(), null);
			Font font = new Font("Sansserif", Font.BOLD, 36);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
            g2.setColor(Color.red);
            g2.setComposite(AlphaComposite.SrcOver.derive(0.3f));
            g2.fillRoundRect(100, 100, 100, 80, 32, 32);
            g2.setComposite(AlphaComposite.SrcOver);
            g2.setColor(Color.white);
            g2.setFont(font);
            g2.drawString("Manipulation de la librairie vlc en java", 130, 150);
         }
		 
	public static void main(String[] args){
        if(args.length < 1) {
            System.out.println("Specifiez une ressource");
            System.exit(1);
        }
        final String[] arg = args;
        final String[] vlcArgs = (args.length == 1) ? new String[] {} : Arrays.copyOfRange(args, 1, args.length);
    
	    SwingUtilities.invokeLater(new Runnable() {

            @Override
             public void run() {
                JFrame frame = new JFrame("Manipulation de vlc en java");
                frame.setIconImage(new ImageIcon(getClass().getResource("/mediac/src/img/i32.png")).getImage());
                MPanelPlayer imagePane = new MPanelPlayer(arg[0], vlcArgs);
                imagePane.setSize(imagePane.player.width,imagePane.player.height);
                //imagePane.setMinimumSize(new Dimension(imagePane.player.width,imagePane.player.height));
                //imagePane.setPreferredSize(new Dimension(imagePane.player.width,imagePane.player.height));
                frame.getContentPane().setLayout(new BorderLayout());
                frame.getContentPane().add(imagePane, BorderLayout.CENTER);
                frame.setLocation(10,10);
				//frame.setSize(imagePane.player.width+1,imagePane.player.height+1);
				frame.setSize(imagePane.player.width,imagePane.player.height);
                frame.setVisible(true);
                imagePane.player.play();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
        });
	
    }
}