
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import java.awt.Font;

public class FrameButton extends javax.swing.JButton{

ImageIcon icone1 = null;
ImageIcon icone2 = null;
ImageIcon icone3 = null;
ImageIcon icone4 = null;
protected boolean active = false;

public FrameButton(String text){
	super(text);
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setFont(new Font("arial",Font.BOLD,16));
	setFocusable(false);
    setRequestFocusEnabled(false);
 }
 
 public FrameButton(ImageIcon i1,ImageIcon i2,String toolTip){
	super(i1);
	icone1 = i1;
	icone2 = i2;
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setToolTipText(toolTip);
	//setFocusable(false);
    //setRequestFocusEnabled(false);
		addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e1){
			setIcon(icone2);
			}
			public void mouseExited(MouseEvent e2){
			setIcon(icone1);
			}
			
			public void mousePressed(MouseEvent e3){
				click();
			}
		});
 }
 
	public FrameButton(ImageIcon i1,ImageIcon i2,ImageIcon i3,ImageIcon i4,final String toolTip1,final String toolTip2){
	super(i1);
	icone1 = i1;
	icone2 = i2;
	icone3 = i3;
	icone4 = i4;
	setUI(new javax.swing.plaf.basic.BasicButtonUI());
	setBorder(null);
	this.setContentAreaFilled(false);
	setToolTipText(toolTip1);
		addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e1){
				if(active){
					setIcon(icone4);
				}
				else{
					setIcon(icone2);
				}
			
			}
			public void mouseExited(MouseEvent e2){
				if(active){
					setIcon(icone3);
				}
				else{
					setIcon(icone1);
				}
			}
			
			public void mousePressed(MouseEvent e3){
				active = (active)?false:true;
				if(active){
					setToolTipText(toolTip2);
					setIcon(icone3);
				}
				else{
					setToolTipText(toolTip1);
					setIcon(icone1);
				}
				click();
			}
		});
	}
	
	public FrameButton(ImageIcon i1,ImageIcon i2,final String toolTip,int v){
	super(i1);
	icone1 = i1;
	icone2 = i2;
	setToolTipText(toolTip);
		addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e1){
					setIcon(icone2);
			}
			public void mouseExited(MouseEvent e2){
					setIcon(icone1);
			}
			
			public void mousePressed(MouseEvent e3){
				click();
			}
		});
	}
 
	public void click(){
 
	}
 
 
}