/**
/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS 
Un panel non opaque : qui laisse transparaitre
le background de son parent s'il n'en pas lui meme.
**/
public class MPanel extends javax.swing.JPanel{
	public MPanel(){
		super();
		setOpaque(false);
	}
}