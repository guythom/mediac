/**
 * Internal trivial logger implementation for the vlcj log.
 */
package uk.co.caprica.vlcj.logger;
