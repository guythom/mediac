/**
 * Provides the classes necessary to create and control native media lists.
 */
package uk.co.caprica.vlcj.medialist;
