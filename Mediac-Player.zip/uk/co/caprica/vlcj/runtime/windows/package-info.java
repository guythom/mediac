/**
 * Provides various utility classes for applications running in an MS-Windows
 * environment.
 */
package uk.co.caprica.vlcj.runtime.windows;
