/**
 * A mechanism to encapsulate native media player events and dispatch
 * notifications to event listeners.
 */
package uk.co.caprica.vlcj.player.events;
