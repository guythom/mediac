/**
 * Provides Mac-specific support for user interface components that render
 * native video.
 */
package uk.co.caprica.vlcj.player.embedded.videosurface.mac;
