/**
 * Provides the classes necessary to support direct access to the native video
 * frame buffer.
 */
package uk.co.caprica.vlcj.player.direct;
