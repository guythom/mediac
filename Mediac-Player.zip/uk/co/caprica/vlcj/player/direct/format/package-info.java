/**
 * Provides implementations of buffer formats for the direct video rendering
 * media player.
 */
package uk.co.caprica.vlcj.player.direct.format;
