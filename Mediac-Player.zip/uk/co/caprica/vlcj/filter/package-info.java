/**
 * Implementations of various media file filters supported by vlc.
 */
package uk.co.caprica.vlcj.filter;
