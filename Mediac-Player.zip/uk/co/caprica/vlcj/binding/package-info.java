/**
 * Provides the JNA bindings, and related classes, to use the libvlc native
 * library.
 */
package uk.co.caprica.vlcj.binding;
