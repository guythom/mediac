/**
Calcul de la transforme de fourier Rapide(Transforme de fourier discrete)
**/
public class FFT {

    // calcul de la transformee de fourrier rapide en admettant que le tableau de complexe est d'une taille puissance de 2
    public static Complex[] fft(Complex[] x) {
        int N = x.length;

        
        if (N == 1) return new Complex[] { x[0] };

        // radix 2 Cooley-Tukey FFT
        if (N % 2 != 0) { throw new RuntimeException("N n'est pas puissance de 2"); }

        
        Complex[] even = new Complex[N/2];
        for (int k = 0; k < N/2; k++) {
            even[k] = x[2*k];
        }
        Complex[] q = fft(even);

      
        Complex[] odd  = even;  // reuse the array
        for (int k = 0; k < N/2; k++) {
            odd[k] = x[2*k + 1];
        }
        Complex[] r = fft(odd);

        // combine
        Complex[] y = new Complex[N];
        for (int k = 0; k < N/2; k++) {
            double kth = -2 * k * Math.PI / N;
            Complex wk = new Complex(Math.cos(kth), Math.sin(kth));
            y[k]       = q[k].plus(wk.times(r[k]));
            y[k + N/2] = q[k].minus(wk.times(r[k]));
        }
        return y;
    }


    //inverse de la fft
    public static Complex[] ifft(Complex[] x) {
        int N = x.length;
        Complex[] y = new Complex[N];

        // prendre le conjugue
        for (int i = 0; i < N; i++) {
            y[i] = x[i].conjugate();
        }

        //  forward FFT
        y = fft(y);

        // le conjugue
        for (int i = 0; i < N; i++) {
            y[i] = y[i].conjugate();
        }

        // diviser par N
        for (int i = 0; i < N; i++) {
            y[i] = y[i].times(1.0 / N);
        }

        return y;

    }

    // CONVOLUTION CIRCULAIRE
    public static Complex[] cconvolve(Complex[] x, Complex[] y) {

        
        if (x.length != y.length) { throw new RuntimeException("Dimensions don't agree"); }

        int N = x.length;

        //
        Complex[] a = fft(x);
        Complex[] b = fft(y);

        // on multiplie les deux transformes de fourier (produit de fonction et non produit de convolution)
        Complex[] c = new Complex[N];
        for (int i = 0; i < N; i++) {
            c[i] = a[i].times(b[i]);
        }

        // la convolution de deux fonctions est la transformee de fourier  inverse du produit des tranformees de fourriers des deux fonctionss
        return ifft(c);
    }


    // convolution lineaire
    public static Complex[] convolve(Complex[] x, Complex[] y) {
        Complex ZERO = new Complex(0, 0);

        Complex[] a = new Complex[2*x.length];
        for (int i = 0;        i <   x.length; i++) a[i] = x[i];
        for (int i = x.length; i < 2*x.length; i++) a[i] = ZERO;

        Complex[] b = new Complex[2*y.length];
        for (int i = 0;        i <   y.length; i++) b[i] = y[i];
        for (int i = y.length; i < 2*y.length; i++) b[i] = ZERO;

        return cconvolve(a, b);
    }

    
    public static void print(Complex[] x, String title) {
        System.out.println(title);
        System.out.println("-------------------");
        for (int i = 0; i < x.length; i++) {
            System.out.println(x[i]);
        }
        System.out.println();
    }

    public static void main(String[] args) { 
        int N = Integer.parseInt(args[0]);
        Complex[] x = new Complex[N];

        // original data
        for (int i = 0; i < N; i++) {
            x[i] = new Complex(i, 0);
            x[i] = new Complex(-2*Math.random() + 1, 0);
        }
        print(x, "x");

        
        Complex[] y = fft(x);
        print(y, "y = fft(x)");

        
        Complex[] z = ifft(y);
        print(z, "z = ifft(y)");

        
        Complex[] c = cconvolve(x, x);
        print(c, "c = cconvolve(x, x)");

        
        Complex[] d = convolve(x, x);
        print(d, "d = convolve(x, x)");
    }

}

