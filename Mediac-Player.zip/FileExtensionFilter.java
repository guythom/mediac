import java.util.*;
import java.io.*;


public class FileExtensionFilter implements FileFilter{
	ArrayList<String> acceptedExtensions = new ArrayList<String>();
		
		public FileExtensionFilter(String [] accepted){
		for(int i = 0; i < accepted.length;i++)
			acceptedExtensions.add(accepted[i]);
		}
		
		public boolean accept(File inFile){
		if(inFile.isDirectory())
			return true;
		int i = inFile.getName().lastIndexOf('.') + 1;
		if(i == 0)
			return false;
		int j = inFile.getName().length();
		return acceptedExtensions.contains
				(inFile.getName().substring(i,j).toLowerCase());
		}
	
	}