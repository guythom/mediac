import javax.swing.Timer;
import javax.swing.JComponent;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.RenderingHints;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ViewM extends JComponent{
AudioPlayer player = null;
boolean isPlaying = false;
protected boolean stop = true;
protected boolean pause = false;
protected Timer timer;

	public ViewM(AudioPlayer in){
	player = in;
	initTimer();
	}
	
	public void initTimer(){
	timer = new Timer(10,new ActionListener(){
	       @Override
	       public void actionPerformed(ActionEvent e){
		   if(!pause){
	       repaint();}
	       }});
	timer.setRepeats(true);
	}
	
	public void start(){
	isPlaying = true;
	 timer.start();
	 stop = false;
	 }
	 
	public void stop(){
	isPlaying = false;
	 stop = true;
	 repaint();
	 pause = false;
	 timer.stop();
	 timer = null;
	 initTimer();
	 }
	
	public boolean isPlaying(){
	return isPlaying;
	}
	public synchronized void pause(boolean st){
	 pause = st;
	 }
	 
	 public boolean isRunning(){
	 if(!stop) 
	   return true;
	     else return false;
	 }
	 
	public void paintComponent(Graphics g){
	
	int width = getWidth();
	int height = getHeight();
	Graphics2D g2d = (Graphics2D)g;
	//g2d.setColor(new Color(0,102,102,255));
	//g2d.drawRect(10,0,300,50);
	
		if(isPlaying){
		GradientPaint gradient = new GradientPaint(0, getHeight(),Color.GREEN, 250, 50,Color.RED);
		g2d.setPaint(gradient);
		int l = (int)(400.0f * player.getLevelCountL());
		int r = (int)(400.0f * player.getLevelCountR());
		g2d.fillRect(10,0,r,24);
		g2d.fillRect(10,25,l,24);
		}
	
	}



}