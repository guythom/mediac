

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.GraphicsEnvironment;
import java.lang.reflect.InvocationTargetException;
import java.awt.Toolkit;
import java.awt.Dimension;
import uk.co.caprica.vlcj.player.MediaPlayer;
import uk.co.caprica.vlcj.player.MediaPlayerEventAdapter;
import uk.co.caprica.vlcj.player.direct.BufferFormatCallback;
import uk.co.caprica.vlcj.player.direct.BufferFormat;
import uk.co.caprica.vlcj.player.MediaPlayerFactory;
import uk.co.caprica.vlcj.player.direct.DirectMediaPlayer;
import uk.co.caprica.vlcj.player.direct.RenderCallbackAdapter;
import uk.co.caprica.vlcj.player.direct.RenderCallbackAdapter;
import uk.co.caprica.vlcj.player.direct.format.RV32BufferFormat;

public class DirectPlayer extends LibLoader{

public BufferedImage image;
private MediaPlayerFactory factory;
private DirectMediaPlayer mediaPlayer;
public int width = 300;//1 200 000 vs 630 000 vs ...
public int height = 300;
private String media;
MPanelPlayer panel;
protected GifMaker gifMaker = new GifMaker();
protected int count = 0;
protected int delay = 25;
protected boolean isSaving = true;

 public DirectPlayer(String media, String[] args,MPanelPlayer panel){
    gifMaker.start("gif_sort.gif");
	gifMaker.setDelay(delay);
	//gifMaker.setQuality(1);
	gifMaker.setSize(300,300);
  try{
    this.panel = panel;
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	//width = screen.width;
	//height = screen.height;
    image = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration().createCompatibleImage(width, height);
   image.setAccelerationPriority(1.0f);
    this.media = media;
        factory = new MediaPlayerFactory(args);
        mediaPlayer = factory.newDirectMediaPlayer(new TestBufferFormatCallback(), new TestRenderCallback());
		mediaPlayer.addMediaPlayerEventListener(new MediaPlayerEventAdapter(){
		@Override
        public void playing(MediaPlayer player){
		delay =(int)(1000.0f/player.getFps());
		delay = (delay <= 0)?25:delay;
		gifMaker.setDelay(delay);
		System.out.println("delay : " + delay);
		}
		
		
		
		});
    }
	 catch(Exception e){
	  System.out.println("Erreur lors de l'initialisation de la lecture...");
	  }
  }
     
	 /** Jour le media courant **/
	 public void play(){
	  try{
	   Thread.sleep(5000);
	  }
	    catch(Exception e){
		System.out.println("Thread courant interrompu dans son attente");
		}
	   mediaPlayer.playMedia(media);
       mediaPlayer.nextChapter();
	   
	  }
	  
	  public void play(String media){
	  try{
	   Thread.sleep(2000);
	  }
	    catch(Exception e){
		System.out.println("Thread courant interrompu dans son attente");
		}
	   mediaPlayer.playMedia(media);
       mediaPlayer.nextChapter();
	   
	  }
	  
	  
    /** public static void main(String[] args){
        if(args.length < 1) {
            System.out.println("Specifiez une ressource");
            System.exit(1);
        }

        String[] vlcArgs = (args.length == 1) ? new String[] {} : Arrays.copyOfRange(args, 1, args.length);

        new DirectPlayer(args[0], vlcArgs).play();
    }**/
  
  
    private final class TestRenderCallback extends RenderCallbackAdapter {

        public TestRenderCallback() {
            super(((DataBufferInt) image.getRaster().getDataBuffer()).getData());
        }

        @Override
        public void onDisplay(DirectMediaPlayer mediaPlayer, int[] data) {
            /** C'est ici que se font les manipulations sur les donnees videos brutes stockees dans data **/
			if(panel != null)
			panel.repaint();
			
			if(isSaving){
			if(count < 100)
				gifMaker.addFrameToBuffer(image);
			else{
				gifMaker.finalize();
				isSaving = false;
				}
			count++;
			}
			
				
            //System.out.println("Le buffer compte " + data.length + " pixels ");
        }
		
		
    }
	
	private final class TestBufferFormatCallback implements BufferFormatCallback {

        @Override
        public BufferFormat getBufferFormat(int sourceWidth, int sourceHeight) {
            return new RV32BufferFormat(width, height);
        }

    }

}