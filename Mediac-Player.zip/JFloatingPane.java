import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class OverPanel{

protected JFrame binder = null;
protected MPanel panel = null;
protected Player iplayer = null;
protected AudioPlayer player = null;
protected MVolumeComponent volumeComponent;
protected int x = 0;
protected int y = 0;
protected JPanel glassPane;
protected boolean visible = false;
protected Dimension size = new Dimension(400,200);
	
	public OverPanel(Player player){
		this.binder = player.frame;
		glassPane = (JPanel)binder.getGlassPane();
		glassPane.setLayout(null);
		this.player = player.player;
		this.iplayer = player;
		binder.addComponentListener(new ComponentAdapter(){
			public void componentMoved(ComponentEvent e){
			close();
			}
			public void componentHidden(ComponentEvent e){
			close();
			}
		});
	
		binder.addWindowFocusListener(new WindowFocusAdapter());
		initPanel();
		panel.setFocusable(true);
		panel.setRequestFocusEnabled(true);
		
	}
	
	public void setVisible(boolean v){
		if(v & !visible){
			glassPane.add(panel);
			glassPane.setVisible(true);
			visible = true;
		}
		else if(!v & visible){
			glassPane.remove(panel);
			glassPane.setVisible(false);
			visible = false;
		}
	}
	
	protected void updateBounds(){
		panel.setBounds(x,y,size.width,size.height);
	}
	
	public void setPopupSize(Dimension size){
	this.size = size;
	updateBounds();
	}
	
	public void setLocation(int x,int y){
		this.x = x;
		this.y = y;
		updateBounds();
	}
	
	boolean alwaysOnTop() {
        return false;
    }
	
	public void close(){
	setVisible(false);
	}
	
	public void open(){
	setVisible(true);
	panel.requestFocus();
	}
	
	/**public void paintComponent(Graphics g){
	Graphics2D g2d = (Graphics2D)g;
	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	//g2d.setComposite(AlphaComposite.SrcOver.derive(0.4f));
	g2d.setColor(Color.BLACK);
	g2d.fillRect(0,0,getWidth(),getHeight());
	
	}**/
	
	public void initPanel(){
	panel = new MPanel();
	panel.setOpaque(false);
	panel.setLayout(new BorderLayout());
	volumeComponent = new MVolumeComponent(player,200);
	
	final FrameButton mute = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("im3.png")),new ImageIcon(MVolumeComponent.class.getResource("im4.png")),new ImageIcon(MVolumeComponent.class.getResource("mu1.png")),new ImageIcon(MVolumeComponent.class.getResource("mu2.png")),"Desactiver le son","Activer le son"){
		public void click(){
		player.muteIf();
		}
	};
	
	final FrameButton repeat = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("re1.png")),new ImageIcon(MVolumeComponent.class.getResource("re2.png")),new ImageIcon(MVolumeComponent.class.getResource("re3.png")),new ImageIcon(MVolumeComponent.class.getResource("re4.png")),"Activer la repetition","Desactiver la repetition"){
		public void click(){
		iplayer.setRepeat();
		}
	};
	
	final FrameButton activeMic = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("smic1.png")),new ImageIcon(MVolumeComponent.class.getResource("smic2.png")),new ImageIcon(MVolumeComponent.class.getResource("smic3.png")),new ImageIcon(MVolumeComponent.class.getResource("smic4.png")),"Activer le Microphone","Desactiver le Microphone"){
		public void click(){
		player.activeMic();
		}
	};
	
	MPanel savePanel = new MPanel();
	savePanel.setOpaque(false);
	savePanel.setLayout(new BoxLayout(savePanel,BoxLayout.X_AXIS));
	//savePanel.setBorder(BorderFactory.createTitledBorder("'"));
	
	final FrameButton save = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("save1.png")),new ImageIcon(MVolumeComponent.class.getResource("save2.png")),"Sauvegarder le fichier",0){
		public void click(){
		
		}
	};
	
	final FrameButton start = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("sta1.png")),new ImageIcon(MVolumeComponent.class.getResource("sta2.png")),"Demarrer l'enregistrement",0){
		public void click(){
		
		}
	};
	
	final FrameButton stop = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("stop1.png")),new ImageIcon(MVolumeComponent.class.getResource("stop2.png")),"Stopper l'enregistrement",0){
		public void click(){
		
		}
	};
	
	final FrameButton control = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("cont1.png")),new ImageIcon(MVolumeComponent.class.getResource("cont2.png")),"Controles d'experts",0){
		public void click(){
		
		}
	};
	
	savePanel.add(start);
	savePanel.add(stop);
	savePanel.add(save);
	
	MPanel mindPane = new MPanel();
	mindPane.setOpaque(false);
	mindPane.setLayout(new BoxLayout(mindPane,BoxLayout.X_AXIS));
	mindPane.add(mute);
	mindPane.add(repeat);
	mindPane.add(activeMic);
	
	mindPane.add(new JLabel("  "));
	mindPane.add(new JLabel("  "));
	mindPane.add(savePanel);
	
	mindPane.add(new JLabel("  "));
	mindPane.add(control);
	
	MPanel northPanel = new MPanel();
	//northPanel.setLayout(new BoxLayout(northPanel,BoxLayout.X_AXIS));
	
	MPanel vPanel = new MPanel();
	
	//vPanel.setLayout(new BoxLayout(vPanel,BoxLayout.X_AXIS));
	//vPanel.setBorder(BorderFactory.createTitledBorder("Visualisations"));
	JRadioButton v0 = new JRadioButton("0");
	JRadioButton v1 = new JRadioButton("1");
	JRadioButton v2 = new JRadioButton("2");
	JRadioButton v3 = new JRadioButton("3");
	
	
	v0.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.animation.setAnimatedType(0);}});
	
	v1.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.animation.setAnimatedType(1);}});
	
	v2.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.animation.setAnimatedType(2);}});
	
	v3.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.animation.setAnimatedType(3);}});
	
	v0.setForeground(Color.WHITE);
	v1.setForeground(Color.WHITE);
	v2.setForeground(Color.WHITE);
	v3.setForeground(Color.WHITE);
	ButtonGroup visualGroup = new ButtonGroup();
	visualGroup.add(v0);
	visualGroup.add(v1);
	visualGroup.add(v2);
	visualGroup.add(v3);
	v0.setSelected(true);
	JLabel vlab = new JLabel("Visualisation");
	vlab.setForeground(Color.WHITE);
	vPanel.add(vlab);
	vPanel.add(v0);
	vPanel.add(v1);
	vPanel.add(v2);
	vPanel.add(v3);
	
	MPanel sPanel = new MPanel();
	JRadioButton s1 = new JRadioButton("1");
	JRadioButton s2 = new JRadioButton("2");
	JRadioButton s3 = new JRadioButton("3");
	JRadioButton s4 = new JRadioButton("4");
	
	s1.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.addPlayer(1);}});
	
	s2.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.addPlayer(2);}});
	
	s3.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.addPlayer(3);}});
	
	s4.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e)
	{iplayer.addPlayer(4);}});
	
	
	s1.setForeground(Color.WHITE);
	s2.setForeground(Color.WHITE);
	s3.setForeground(Color.WHITE);
	s4.setForeground(Color.WHITE);
	ButtonGroup screenGroup = new ButtonGroup();
	screenGroup.add(s1);
	screenGroup.add(s2);
	screenGroup.add(s3);
	screenGroup.add(s4);
	s1.setSelected(true);
	JLabel slab = new JLabel("Ecrans");
	slab.setForeground(Color.WHITE);
	sPanel.add(slab);
	sPanel.add(s1);
	sPanel.add(s2);
	sPanel.add(s3);
	sPanel.add(s4);
	
	
	final FrameButton close = new FrameButton(new ImageIcon(MVolumeComponent.class.getResource("mediac/src/img/clos1.png")),new ImageIcon(MVolumeComponent.class.getResource("mediac/src/img/clos2.png")),"Masquer"){
		public void click(){
		
		}
	};
	close.addMouseListener(new MouseAdapter(){
		public void mousePressed(MouseEvent e){
		close();
		}
	});
	
	sPanel.add(new JLabel(" "));
	sPanel.add(close);
	
	northPanel.setLayout(new FlowLayout(0,1,6));
	northPanel.add(vPanel);
	northPanel.add(sPanel);
	
	//panel.add("North",northPanel);
	panel.add("Center",volumeComponent);
	//panel.add("South",mindPane);
	
	}
	
	public void updateVolume(){
	volumeComponent.updateVolume();
	}
	
	private class WindowFocusAdapter implements WindowFocusListener{
		public void windowGainedFocus(WindowEvent e){
		/** nothing **/
		}
		public void windowLostFocus(WindowEvent e){
		close();
		}
	}

}