
import java.io.Serializable;

@SuppressWarnings("serial")
public class ListItem implements Serializable {
    
    public String name;
	public String path;
    public long ID;
    
    public ListItem(String name,String path,long ID){
        this.name = name;
		this.path = path;
        this.ID = ID;
    }
}
