
import java.awt.Color;
import java.awt.Graphics;

public class Cercle {
	//Repr�sente le nombre de fois que l'on rep�te les formules du Cercle
	int iteration;
	//Tableau de couleurs
    Color colorWheel[];
    //Indice du tableau de couleur
    int colorIdx;
  
    
    public Cercle () {
    	//Instancie le tableau de 2 couleurs et instancie l'indice � 0
    	colorWheel = new Color[2];
        colorIdx = 0;
    }
    
    public void cercle(Graphics g, int ite, double d, double d1, double larg)
    {
       
    	//D�finition de la couleur fix�e par le tableau de couleur et son indice en fonction
    	// de l'it�ration pour faire un �change de couleur
    	if((iteration - ite) % 2 == 0)
        	g.setColor(colorWheel[0]);
      
        else
        	g.setColor(colorWheel[1]);
      
    	//Dessine un cercle de couleur fix� pr�c�demment 
    	//avec les coordonn�es (d,d1) et de largeur larg et de hauteur haut
        g.fillOval((int)d, (int)d1, (int)larg, (int)larg);
        //Dessine un contour de cercle noir avec les coordonn�es (d,d1) et
        // de largeur larg et hauteur larg
        g.setColor(Color.black);
        g.drawOval((int)d, (int)d1, (int)larg, (int)larg);
        
        //Quand l'it�ration est sup�rieure � 1 on appplique 3 cercles dans le cercle pr�c�dent
        if(ite != 1)
        {
            cercle(g, ite - 1, d + larg / 3.1415926535897931, d1 + larg / 3.1415926535897931, (2 * larg) / 3.2000000000000002);
            cercle(g, ite - 1, d, d1 + larg / 3, larg / 3);
            cercle(g, ite - 1, d + larg / 3, d1, larg / 3);
           
        }
    }
    
  //Permet de modifier l'attribut it�ration
    public void setIteration(int it)
    {
    	this.iteration = it;
    }
}
