/**************************************** MEDIAC 1.0 ********************************************
***************************************** DOUALA CAMEROUN  2014 ******************************
****************************** Copyright (c)  NKOT YOGO GUY THOMAS ****************************/

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;

public class MSlider extends JComponent implements MouseListener,MouseMotionListener{

protected int type = 0;
protected int value = 0;
protected long max = 1;
protected long min = 0;
protected Color background;

   public MSlider(){
	  background  = new Color(0,80,120,255);
      setFocusable(true);
      setRequestFocusEnabled(true);
      enableEvents(AWTEvent.FOCUS_EVENT_MASK);
      enableEvents(AWTEvent.KEY_EVENT_MASK);
      enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	  setPreferredSize(new Dimension(getWidth(),8));
	  
   }
   
   public void paint(Graphics g){
   setPreferredSize(new Dimension(getWidth(),8));
   Graphics2D g2d = (Graphics2D)g;
   g2d.setComposite(AlphaComposite.SrcOver.derive(0.3f));
   g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
   if(type == 0)
		g2d.setColor(Color.WHITE);
   else
		g2d.setColor(background);
	
   g2d.drawRoundRect(0, 0, getWidth(), 8,8,8);
   g2d.setColor(background);
   g2d.fillRoundRect(0, 0, value, 8,8,8);
   }
   
   public void setValue(long i){
   long temp_value = i;
	if(temp_value < min)
		temp_value = min;
	if(temp_value > max)
		temp_value = max;
	value = (int)(temp_value*getWidth()/max);
	repaint();
	exec();
   }
   
   public long getValue(){
   if(getWidth() > 0)
		return (int)(value*max/getWidth());
   else
		return 0;
   }
   
   public void setMaximum(long max){
   if(max > 0)
	this.max = max;
		else
			this.max = 1;
   }
   
   public void setMinimum(int min){
   if(min > 0)
	this.min = min;
		else
			this.min = 0;
   }
   
   public long getMaximum(){
   return max;
   }
   
   public long getMinimum(){
   return min;
   }
   
   public void setSlideType(int type){
   this.type = type;
   }

    public void mouseClicked(MouseEvent e){}
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
	public void mouseDragged(MouseEvent e){}
    public void mouseMoved(MouseEvent e){}
	public void exec(){}
}