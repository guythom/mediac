import java.awt.*;

public class AudioVisualiser extends Canvas{
	protected boolean pause = false;
	protected boolean stop = true;
	protected boolean isPlaying = false;
	protected float[] frames = new float[32];
	protected final Thread timer;
	protected MediacPlayer player;
	protected int x,y;
	protected Graphics2D graphics;
	 
	public AudioVisualiser(MediacPlayer player){
		this.player = player;
		x = 50;
		y = 0;
		graphics = null;
		timer = new Thread(new Runnable(){
			public void run(){
				while(true){
					draw();
					try{
						if(pause || stop){
							if(stop) clean();
							timer.wait();
						}
						else{
							timer.sleep(50);
						}
					}catch(Exception e){}
				}
			}
		});
		setPreferredSize(new Dimension(100,50));
		setBackground(Color.BLACK);
	}
	
	public void clean(){
		
	}
	
	public void start(){
		timer.start();
	}
	public synchronized void pause(){
		pause = true;
	}
	
	public void resume(){
		pause = false;
		stop = false;
		timer.notify();
	}
	
	public synchronized void stop(){
		stop = true;
	}
	
	public boolean stoped(){
		return stop;
	}
	
	public void draw(){
		process(player.getAudioDatas());
		repaint();
		update(graphics);
	}
	
	@Override
	public void paint(Graphics g){
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setColor(Color.WHITE);
		g2d.fillRect(x,y,getWidth(), getHeight());
		if(isPlaying){
			
		}
		graphics = g2d;
	}
	
	public void process(int[] samples){
		int mod =  samples.length % 64;
		int len = samples.length - mod;
		int div = len/64;
		float max = (65536.0f * ((float)(div + 1))); 
		float ech = 0.0f;
		int sample = 0;
		int j1 = 0;
		int j2 = 0;
		int i1 = 0;
		int i2 = 0;
		boolean parTest = false;
	
		int [] tL = new int[32];
		int [] tR = new int[32];
		float [] tempL = new float[32];
		float [] tempR = new float[32];
		
		for(int i = 0; i < len; i++){
			sample = samples[i] + 32768;
			parTest = (i%2 == 0)?true:false;
			
			if(parTest){
				if(j1 == div){
					ech = (float)tL[i1];
					tempL[i1] = ech/max ;
					i1++;
					j1 = 0;
				}
				else{
					tL[i1] += sample;
					j1++;
				}
			}	
			else{
				if(j2 == div){
					ech = (float)tR[i2];
					tempR[i2] = ech/max ;
					i2++;
					j2 = 0;
				}
				else{
					tR[i2] += sample;
					j2++;
				}	
			}
			
		}
		for(int i = 0; i < 32; i++)
		frames[i] = (tempL[i] + tempR[i])/2.0f;
	}
	
	
	
	
	
}