import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;

public class VMenu extends MPanel implements MouseListener,MouseMotionListener{

int max_srtWidth = 0;
int max_strHeight = 0;
int x_start = 0;
int y_start = 0;
int px = 0;
int py = 0;
public boolean hover = false;
protected boolean onpopup = false;
protected boolean onpopup_item = false;
protected String label = "";

JPopup popup;
MPanel rootPanel = new MPanel();
ArrayList<VMenuItem> itemList = new ArrayList<VMenuItem>();
GeneralItemMouseListener generalItemMouseListener;

protected Color textColor = new Color(255,255,255);
protected Color backColor = new Color(50,50,50,255);
protected Font font = new Font("Agency FB",Font.PLAIN,22);
    
    public int getStringWidth(){
	return max_srtWidth;
	}
     
	public int getStringHeight(){
	return max_strHeight;
	}
	
	public VMenu(String label,MBar mbar){
	super();
	popup = new JPopup(mbar.getFrame(),this);
	setOpaque(false);
	rootPanel.setBorder(BorderFactory.createLineBorder(new Color(200,200,200),1));
	popup.add(rootPanel);
	this.label = label;
	updateSize();
	setPreferredSize(new Dimension(max_srtWidth,max_strHeight));
	generalItemMouseListener = new GeneralItemMouseListener();
    enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	addMouseListener(this);
    setFocusable(false);
    setRequestFocusEnabled(false);
    repaint();
	}
	
	public void addItem(VMenuItem item){
	item.addMouseListener(generalItemMouseListener);
	itemList.add(item);
	rootPanel.removeAll();
	rootPanel.setLayout(new GridLayout(itemList.size(),1));
	
	for(Iterator i = itemList.iterator();i.hasNext();)
	rootPanel.add((VMenuItem)i.next());
	   
	}
	
	private class GeneralItemMouseListener extends MouseAdapter{
     public void mousePressed(MouseEvent e){
     popup.setVisible(false);
     }
	 public void mouseClicked(MouseEvent e){
	 popup.setVisible(false);
	 }
	}
	
	public String getText(){
	return label;
	}
	
	public void setText(String newLabel){
	label = newLabel;
	updateSize();
	repaint();
	}
	
	public void updateSize(){
	
	 AffineTransform trans = font.getTransform();
     FontRenderContext render = new FontRenderContext(trans,true,true);
	 if(render == null)
	 System.exit(0);
     Rectangle2D rect = font.getStringBounds(label,render);
	 
	 max_srtWidth = (int)rect.getWidth() + 20;
	 max_strHeight = font.getSize()+ (font.getSize()/20)+5;
	 
	 x_start = (max_srtWidth - (int)rect.getWidth())/2;
	 y_start = ((int)rect.getHeight() - max_strHeight )/2;
	 
	 y_start = max_strHeight - (2*((int)rect.getHeight() - max_strHeight)) + y_start - 5;
	 max_strHeight = max_strHeight - ((int)rect.getHeight() - max_strHeight);
	 
	}
    
	public Font getFont(){
	return font;
	}
	
	public void setForeground(Color textColor){
	this.textColor = textColor;
	repaint();
	}
	
	public void setBackground(Color backColor){
	this.backColor = backColor;
	repaint();
	}
	
	public void paintComponent(Graphics g){
		setPreferredSize(new Dimension(max_srtWidth,max_strHeight));
		Graphics2D g2d = (Graphics2D)g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	
		if(hover){
			g2d.setColor(backColor);
			g2d.fillRect(5,0,max_srtWidth,max_strHeight);
			g2d.setColor(textColor);
			g2d.drawString(label,x_start,y_start);
		}
		else{
			g2d.setColor(textColor);
			g2d.drawString(label,x_start,y_start);
		}
	   
	}
	
	public void mouseClicked(MouseEvent e){}
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){
		hover = true;
		repaint();
		int xmouse = e.getXOnScreen();
		int ymouse = e.getYOnScreen();
		int xloc = e.getX();
		int yloc = e.getY();
		px = xmouse - xloc + 5;
		py = ymouse - yloc + max_strHeight - 1;
		popup.setLocation(px,py);
		popup.setVisible(true);
	}

    public void mouseExited(MouseEvent e){}
	public void mouseDragged(MouseEvent e){}
    public void mouseMoved(MouseEvent e){}
	public void closePopupMenu(){
		popup.setVisible(false);
	}
}
