
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.util.Random;

public class FractalePanel extends JPanel{
	Random random = new Random();
	private static final String[] FRATACLES = {
	"SierpinkiTriangle",
	"SierpinkiTapis",
	"Koch",
	"Hilbert",
	"Peano",
	"Koch2",
	"TriangleOrigami",
	"Cercle"
	};
	private static final String[] COLORATION = {"deg",
	                                            "arc",
												"deg2"};
	private static final String[] FRATACLES2 = {"Julia",
	"Mandelbrot"};
	private int iteration = 1; 
	
	private Dessin dessin = new Dessin(); 
	
	private double ymax;
	private double ymin;
	private double xmax; 
	private double xmin; 
	//Largeur et hauteur de la fen�tre
	private int lwin = 710; 
	private int hwin= 710; 
	//Coordonn�es pour le nombre complexe de Julia
	private double ca,cb;
	private int icoloration = 0;
	private boolean dessinRect = false;
	
	public FractalePanel(){	
	    xmin = -2;
		xmax = 2;
		ymin = -2;
		ymax = 2;
		setLayout(new BorderLayout());
		add(dessin, BorderLayout.CENTER);
	}
	
	public void paintFract() {
	int randInt = random.nextInt(8)& 0x7;
	int randIntx = randInt >> 2;
	int colorMap = 11290001;
	System.out.println( "" +colorMap);
	if(icoloration > 2)
	  icoloration = 0;
	
	switch(randInt){
	      case 7: 
		  iteration = 13;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  case 6: 
		  iteration = 13;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  case 5: 
		  iteration = 8;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  case 4: 
		  iteration = 8;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  case 3: 
		  iteration = 12;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  case 2: 
		  iteration = 10;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
	      case 1: 
		  iteration = 6;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  case 0: 
		  iteration = 9;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES[randInt]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
		  default:
		  iteration = 100;
		  dessin.setIteration(iteration);
		  dessin.setCoord(xmin,xmax,ymin,ymax);
		  dessin.setDessinRect(false);
		  dessin.setForme(FRATACLES2[randIntx]);
		  dessin.setColoration(COLORATION[icoloration]);
		  dessin.setRouge((colorMap >> 16)&0xFF);
		  dessin.setVert(((colorMap >> 8) & 0xFFFF )&0xFF);
		  dessin.setBleu(colorMap & 0xFF);
		  dessin.repaint();
		  break;
	}
	    icoloration++;
}
	
	//M�thode appel�e quand la souris est utilis�e
	
	//M�thode appel�e quand la souris est utilis�e
	
	public void juliaRepaint() {
		
		ca = 4*(double)100/getWidth()-2;
		cb = -4*(double)100/getHeight()+2;
			dessin.setCaCb(ca,cb);
			dessin.setForme("Julia");
		    dessin.repaint();
	}
	
	public static void main(String[]args){
	JFrame frame = new JFrame("fract");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	final FractalePanel fract = new FractalePanel();
	frame.setSize(700,800);
	frame.getContentPane().add(fract);
	frame.setVisible(true);
	
	Timer timer = new Timer(500,new ActionListener(){
	     public void actionPerformed(ActionEvent e){
	     fract.paintFract();
	     }
	     });
	timer.setRepeats(true);
	timer.start();
	}

}
