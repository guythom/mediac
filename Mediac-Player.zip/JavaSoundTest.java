
import java.util.concurrent.Semaphore;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.SourceDataLine;

//import uk.co.caprica.vlcj.component.DirectAudioPlayerComponent;
import uk.co.caprica.vlcj.logger.Logger;
import uk.co.caprica.vlcj.player.MediaPlayer;
import uk.co.caprica.vlcj.player.directaudio.DirectAudioPlayer;
import com.sun.jna.Pointer;

import java.awt.Canvas;

/**
 * Test showing how to use the direct audio player to play through the JavaSound API.
 * <p>
 * The native decoded audio samples from vlc are simply played via Javasound.
 */
public class JavaSoundTest{

    private static final String FORMAT = "S16N";
    public final Canvas canvas;
    private static final int RATE = 44100;

    private static final int CHANNELS = 2;

    private final Semaphore sync = new Semaphore(0);

    final JavaSoundDirectAudioPlayerComponent audioPlayerComponent;

    public static void main(String[] args) throws Exception {
        if(args.length != 1) {
            System.out.println("Specify an MRL");
            System.exit(1);
        }

        JavaSoundTest test = new JavaSoundTest();
		javax.swing.JFrame frame = new javax.swing.JFrame("..");
		java.awt.Panel pane = new java.awt.Panel();
		pane.setLayout(new java.awt.BorderLayout());
		pane.add(java.awt.BorderLayout.CENTER,test.canvas);
		frame.getContentPane().add(pane);
		frame.setSize(900,700);
		frame.setVisible(true);
		test.audioPlayerComponent.attach();
		test.play(args[0]);
        System.out.println("Exit normally");
    }

    public JavaSoundTest() throws Exception {
        audioPlayerComponent = new JavaSoundDirectAudioPlayerComponent(FORMAT, RATE, CHANNELS);
		canvas = audioPlayerComponent.getCanvas();
    }

    private void play(String mrl) throws Exception {
        audioPlayerComponent.start();
        audioPlayerComponent.getMediaPlayer().playMedia(mrl);
        try {
            sync.acquire(); // Potential race if the media has already finished, but very unlikely, and good enough for a test
        }
        catch(InterruptedException e) {
            e.printStackTrace();
        }
        audioPlayerComponent.stop();

        // audioPlayerComponent.release(true); // FIXME right now this causes a fatal JVM crash just before the JVM terminates, I am not sure why (the other direct audio player example does NOT crash)
        System.exit(0); // so instead do this...
    }

    /**
     *
     */
    private class JavaSoundDirectAudioPlayerComponent extends MediacPlayer {

        private static final int BLOCK_SIZE = 4;

        private static final int SAMPLE_BITS = 16; // BLOCK_SIZE * 8 / channels ???

        private final AudioFormat audioFormat;

        private final Info info;

        private final SourceDataLine dataLine;

        public JavaSoundDirectAudioPlayerComponent(String format, int rate, int channels) throws Exception {
            super(format, rate, channels);
            this.audioFormat = new AudioFormat(rate, SAMPLE_BITS, channels, true, false);
            this.info = new Info(SourceDataLine.class, audioFormat);
            this.dataLine = (SourceDataLine)AudioSystem.getLine(info);
        }

        private void start() throws Exception {
            Logger.info("start()");
            dataLine.open(audioFormat);
            dataLine.start();
        }

        private void stop() {
            Logger.info("stop()");
            dataLine.close();
        }

        @Override
        public void play(DirectAudioPlayer mediaPlayer, Pointer samples, int sampleCount, long pts) {
            // There may be more efficient ways to do this...
            int bufferSize = sampleCount * BLOCK_SIZE;
            // You could process these samples in some way before playing them...
            byte[] data = samples.getByteArray(0, bufferSize);
            dataLine.write(data, 0, bufferSize);
        }

        @Override
        public void drain(DirectAudioPlayer mediaPlayer) {
            Logger.info("drain()");
            dataLine.drain();
        }

        @Override
        public void finished(MediaPlayer mediaPlayer) {
            Logger.info("finished()");
            sync.release();
        }
    }
}
