
public class Com{

      public static void main(String[]args){
	  /**
	    Pour l'algorithme j'utilise un pas de 1 ainsi il faut incrementer 18446744073709551616 de fois 
	   pour couvrir tous les nombres de 64 bits
	  **/
	  float pas_inc =  0.0000001f;
	  float max_val =  18446744073709551616f;
	  float z = 0f;
	  long c = 0;
	  System.out.println("max  = " + max_val);
	      while(true){
	        z = z + pas_inc;
	        if(z == max_val)
	            break;
	            else c++;
	      }
	      
	  }

}