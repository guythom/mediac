
import java.awt.Color;
import java.awt.Graphics;


public class SierpinkiTapis {
	//Repr�sente le nombre de fois que l'on rep�te les formules de Sierpinki
	int iteration;
	//Tableau de couleurs
    Color colorWheel[];
    //Indice du tableau de couleur
    int colorIdx;
       
    
    public SierpinkiTapis(){
    	//Instancie le tableau de 400 couleurs et instancie l'indice � 0
    	colorWheel = new Color[400];
        colorIdx = 0;

    }

    public void tapis(Graphics g, int iteration, int j, int k, int larg, int haut)
    {
        if(iteration == 1)
        {
            g.setColor(colorWheel[colorIdx]);
            //Dessine un carr� de sommet j, k, largeur, hauteur avec une couleur d�finie auparavant
            g.fillRect(j, k, larg, haut);
            
            //Permet de d�finir l'indice du tableau de couleur pour cr�er un d�grad� de couleur
            if(++colorIdx >= 400)
            	colorIdx = 0;
        
            g.setColor(Color.black);
            //Dessine un carr� de sommet j, k, largeur, hauteur en noir
            g.drawRect(j, k, larg, haut);
        } 
        else
        {
            //On divise par 3 la hauteur et la largeur pour pouvoir dessiner 9 carr�s
        	int largDiv = larg / 3;
            int hautDiv = haut / 3;
            //Permet de dessiner 8 carr�s dans le carr� pr�c�demment dessin�
            tapis(g, iteration - 1, j, k, largDiv, hautDiv);
            tapis(g, iteration - 1, j + largDiv, k, largDiv, hautDiv);
            tapis(g, iteration - 1, j + 2 * largDiv, k, largDiv, hautDiv);
            tapis(g, iteration - 1, j, k + hautDiv, largDiv, hautDiv);
            tapis(g, iteration - 1, j + 2 * largDiv, k + hautDiv, largDiv, hautDiv);
            tapis(g, iteration - 1, j, k + 2 * hautDiv, largDiv, hautDiv);
            tapis(g, iteration - 1, j + largDiv, k + 2 * hautDiv, largDiv, hautDiv);
            tapis(g, iteration - 1, j + 2 * largDiv, k + 2 * hautDiv, largDiv, hautDiv);
        }
    }
    
    //Permet de modifier l'attribut it�ration
    public void setIteration(int it)
    {
    	this.iteration = it;
    }
   
}

